/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_62;

/**
 *
 * @author Nemesis
 */
public class metodo_62 {
    private String nombre;
    private double codigo ; 
    private double promedio ;

    public metodo_62(String nombre, double codigo, double promedio) {
        this.nombre = nombre;
        this.codigo = codigo;
        this.promedio = promedio;
    }
    
    public String aprueba (){
        if (promedio < 10   || promedio > 60  ) {
            return " el rango del promedio esta fuera de los limites asi que esta mal";
            
        }
        if ( promedio >= 3.0 ) {
            return " el estudiante "+nombre + "  aprobo , asi q saquese a la vrg";    
        }else
            return " el estudiante "+nombre + "no aprobo , no ruegue por nota que aqui solo se sube es de peso ";    
    }

    @Override
    public String toString() {
        return "metodo_62 {" + "nombre=" + nombre + ", codigo=" + codigo + ", promedio=" + promedio +"estado :"+aprueba() +'}';
    }
    
    
    
    
}
