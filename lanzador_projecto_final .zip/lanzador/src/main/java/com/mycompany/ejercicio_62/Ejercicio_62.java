/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio_62;

import java.util.Scanner;

/**
 *
 * @author Nemesis
 */
public class Ejercicio_62 {
    static Scanner entrada = new Scanner(System.in);
    
    public static void main(String[] args) {
        
        try {
            System.out.println("===============");
            
            String dato1 = texto("Ingrese nombre del estudiante ");
            double codigo = numeros("ingrese el codigo del estudiante ");
            double dato2 = numeros("Ingrese el promedio del estudiante ");
            
            metodo_62 obj = new metodo_62(dato1, codigo, dato2);
            
            System.out.println(obj);
            
        } catch (Exception e) {
            System.out.println("El dato está mal.");
        }
    }
    
    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }
    
    public static double numeros(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                double numero = entrada.nextDouble();
                entrada.nextLine();
                return numero;
            } catch (Exception e) {
                System.out.println("Ingrese un número válido");
                entrada.nextLine();
            }
        }
    }
}
