package com.mycompany.ejercicio_130;

public abstract class Dispositivo {

    protected String nombre;

    public Dispositivo(String nombre) {
        this.nombre = nombre;
    }

    public String MostrarInfo() {
        return "Dispositivo: " + nombre;
    }
}