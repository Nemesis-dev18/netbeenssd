package com.mycompany.ejercicio_130;

public class Televisor extends Dispositivo implements Encender, Apagar {

    public Televisor(String nombre) {
        super(nombre);
    }

    @Override
    public String encender() {
        return nombre + " se ha encendido (TV)";
    }

    @Override
    public String apagar() {
        return nombre + " se ha apagado (TV)";
    }
}