package com.mycompany.ejercicio_130;

public interface Apagar {
    public String apagar();
}