package com.mycompany.ejercicio_130;

public interface Encender {
    public String encender();
}