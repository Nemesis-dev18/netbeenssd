package com.mycompany.ejercicio_130;

public class Radio extends Dispositivo implements Encender, Apagar {

    public Radio(String nombre) {
        super(nombre);
    }

    @Override
    public String encender() {
        return nombre + " se ha encendido (Radio)";
    }

    @Override
    public String apagar() {
        return nombre + " se ha apagado (Radio)";
    }
}