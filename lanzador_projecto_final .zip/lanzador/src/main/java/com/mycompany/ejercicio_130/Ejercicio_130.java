package com.mycompany.ejercicio_130;

public class Ejercicio_130 {

    public static void main(String[] args) {

        Dispositivo d1 = new Televisor("Samsung");
        Dispositivo d2 = new Radio("Sony");

        System.out.println(d1.MostrarInfo());
        System.out.println(((Televisor)d1).encender());
        System.out.println(((Televisor)d1).apagar());

        System.out.println("----------------");

        System.out.println(d2.MostrarInfo());
        System.out.println(((Radio)d2).encender());
        System.out.println(((Radio)d2).apagar());
    }
}