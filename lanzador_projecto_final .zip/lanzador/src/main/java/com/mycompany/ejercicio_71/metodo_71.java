/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_71;

/**
 *
 * @author Nemesis
 */
public class metodo_71 {
    private  int numero_libros;
    private  int cantidad_usuarios;

    public metodo_71(int numero_libros, int cantidad_usuarios) {
        this.numero_libros = numero_libros;
        this.cantidad_usuarios = cantidad_usuarios;
    }
    public int nuevo (int user){
        return cantidad_usuarios += user ;
        
    }

    @Override
    public String toString() {
        return "metodo_71{" + "numero_libros=" + numero_libros + ", cantidad_usuarios=" + cantidad_usuarios + '}';
    }
    
    
    
}
