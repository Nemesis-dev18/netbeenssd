/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio_71;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Nemesis
 */
public class Ejercicio_71 {

    static Scanner entrada = new Scanner(System.in);
    static ArrayList<metodo_71> lista = new ArrayList<>();
    
    public static void main(String[] args) {
        
        String respuesta = "si";
        String respuesta1 = "si";
        
        do {
            try {
                System.out.println("===============");
                
                int libros = numeros(" ingrese la cantida de libros digitales ");
                int user = numeros("ingrese la cantidad de usuarios registrados");
                metodo_71 obj = new metodo_71(libros, user);
                lista.add(obj);
                
                
                for (metodo_71 string : lista) {
                    System.out.println(string);
                    
                }
                
                
                do {
                    System.out.println(" desea editar la cantidad de usuarios? ");
                    respuesta1 = texto("¿Desea agregar otro? (si/no)");
                    int nueevo = numeros("ingrese nuevo numero usuario ");
                    obj.nuevo(nueevo);
                    
                    for (metodo_71 string : lista) {
                        System.out.println(string);
                    }
                } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
                
                do {
                    respuesta = texto("¿Desea agregar otro? (si/no)");
                } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
                
            } catch (Exception e) {
                System.out.println("El dato está mal.");
                entrada.nextLine();                
            }
            
        } while (respuesta.equalsIgnoreCase("si"));
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }
    
    public static int numeros(String mensaje) {
        System.out.println(mensaje + " :");
        int numero = entrada.nextInt();
        entrada.nextLine();
        return numero;
    }
}
