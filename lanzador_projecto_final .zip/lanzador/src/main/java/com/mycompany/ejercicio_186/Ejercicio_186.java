
package com.mycompany.ejercicio_186;

public class Ejercicio_186 {
    public static void main(String[] args) {
        Usuario u = new Usuario();
        u.setPassword("123456");
        u.login("111");
        u.login("123456");
        System.out.println(u.getIntentos());
    }
}
