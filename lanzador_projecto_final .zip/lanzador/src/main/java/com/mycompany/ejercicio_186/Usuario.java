
package com.mycompany.ejercicio_186;

public class Usuario {
    private String password;
    private int intentos;

    public void setPassword(String password){
        if(password != null && password.length() >= 6){
            this.password = password;
        }
    }

    public boolean login(String intento){
        if(password != null && password.equals(intento)){
            intentos = 0;
            return true;
        }else{
            intentos++;
            return false;
        }
    }

    public int getIntentos(){ return intentos; }
}
