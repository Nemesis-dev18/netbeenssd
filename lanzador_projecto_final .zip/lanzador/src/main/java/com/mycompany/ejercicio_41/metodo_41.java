/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_41;

/**
 *
 * @author Nemesis
 */
public class metodo_41 {
    private String nombre ;
    private int num_facultades; 

    public metodo_41(String nombre, int num_facultades) {
        this.nombre = nombre;
        this.num_facultades = num_facultades;
    }

    @Override
    public String toString() {
        return "metodo_41{" + "nombre=" + nombre + ", num_facultades=" + num_facultades + '}';
    }
    
    
    
    
}
