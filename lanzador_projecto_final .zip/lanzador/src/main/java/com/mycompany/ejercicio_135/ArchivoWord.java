package com.mycompany.ejercicio_135;
public class ArchivoWord extends Archivo{
 @Override public String abrir(){ return "Word abierto"; }
}