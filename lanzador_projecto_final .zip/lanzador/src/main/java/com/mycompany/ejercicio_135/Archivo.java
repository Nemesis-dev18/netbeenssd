package com.mycompany.ejercicio_135;
public class Archivo{
 public String abrir(){ return "Abriendo archivo"; }
}