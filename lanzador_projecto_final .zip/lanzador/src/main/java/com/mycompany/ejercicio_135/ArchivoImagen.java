package com.mycompany.ejercicio_135;
public class ArchivoImagen extends Archivo{
 @Override public String abrir(){ return "Imagen abierta"; }
}