package com.mycompany.ejercicio_135;
public class Ejercicio_135{
 public static void main(String[] args){
  Archivo a1=new ArchivoPDF();
  Archivo a2=new ArchivoWord();
  Archivo a3=new ArchivoImagen();
  System.out.println(a1.abrir());
  System.out.println(a2.abrir());
  System.out.println(a3.abrir());
 }
}