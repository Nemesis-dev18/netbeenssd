package com.mycompany.ejercicio_135;
public class ArchivoPDF extends Archivo{
 @Override public String abrir(){ return "PDF abierto"; }
}