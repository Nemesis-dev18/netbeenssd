
package com.mycompany.ejercicio_160;

public class Gerente extends Empleado {

    public Gerente(double salario) {
        super(salario);
    }

    @Override
    public double calcularPago() {
        return salario + 1000;
    }
}
