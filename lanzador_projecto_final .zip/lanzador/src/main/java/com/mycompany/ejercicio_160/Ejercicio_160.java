
package com.mycompany.ejercicio_160;

public class Ejercicio_160 {
    public static void main(String[] args) {
        Empleado e1 = new Gerente(3000);
        Empleado e2 = new Operario(3000);
        Empleado e3 = new Freelancer(3000);

        System.out.println("Gerente: " + e1.calcularPago());
        System.out.println("Operario: " + e2.calcularPago());
        System.out.println("Freelancer: " + e3.calcularPago());
    }
}
