
package com.mycompany.ejercicio_160;

public class Operario extends Empleado {

    public Operario(double salario) {
        super(salario);
    }

    @Override
    public double calcularPago() {
        return salario;
    }
}
