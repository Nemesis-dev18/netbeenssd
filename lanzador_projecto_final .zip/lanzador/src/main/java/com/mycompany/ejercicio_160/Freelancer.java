
package com.mycompany.ejercicio_160;

public class Freelancer extends Empleado {

    public Freelancer(double salario) {
        super(salario);
    }

    @Override
    public double calcularPago() {
        return salario * 0.9;
    }
}
