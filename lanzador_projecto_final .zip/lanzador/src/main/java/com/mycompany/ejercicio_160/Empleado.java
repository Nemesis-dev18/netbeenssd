
package com.mycompany.ejercicio_160;

public abstract class Empleado {
    protected double salario;

    public Empleado(double salario) {
        this.salario = salario;
    }

    public abstract double calcularPago();
}
