package com.mycompany.ejercicio_143;
public class Figura{
 public double area(double r){
  return Math.PI*r*r;
 }
 public double area(double b,double h){
  return b*h;
 }
}