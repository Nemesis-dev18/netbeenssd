package com.mycompany.ejercicio_143;
public class Ejercicio_143{
 public static void main(String[] args){
  Figura f=new Figura();
  System.out.println(f.area(5));
  System.out.println(f.area(4,3));
 }
}