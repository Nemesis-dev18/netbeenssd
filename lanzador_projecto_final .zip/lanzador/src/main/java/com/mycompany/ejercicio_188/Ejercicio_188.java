
package com.mycompany.ejercicio_188;

public class Ejercicio_188 {
    public static void main(String[] args) {
        CursoVirtual c1 = new CursoVirtual();
        c1.agregarEstudiante();
        c1.agregarEstudiante();
        System.out.println(c1);
    }
}
