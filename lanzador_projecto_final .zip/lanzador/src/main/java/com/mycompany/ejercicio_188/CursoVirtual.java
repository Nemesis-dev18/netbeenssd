
package com.mycompany.ejercicio_188;

public class CursoVirtual {
    private String nombre;
    private int estudiantes;

    public void agregarEstudiante() {
        estudiantes++;
    }

    @Override
    public String toString() {
        return "CursoVirtual{" + "nombre=" + nombre + ", estudiantes=" + estudiantes + '}';
    }
}
