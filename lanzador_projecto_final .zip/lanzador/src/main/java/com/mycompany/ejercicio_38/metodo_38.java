/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_38;

/**
 *
 * @author Nemesis
 */
public class metodo_38 {
    private String nombre;
    private int num_mesas;

    public metodo_38(String nombre, int num_mesas) {
        this.nombre = nombre;
        this.num_mesas = num_mesas;
    }

    @Override
    public String toString() {
        return "metodo_38{" + "nombre=" + nombre + ", num_mesas=" + num_mesas + '}';
    }
    
    
    
}
