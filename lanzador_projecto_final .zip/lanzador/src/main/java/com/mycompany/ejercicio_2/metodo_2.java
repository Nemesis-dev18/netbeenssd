package com.mycompany.ejercicio_2;

public class metodo_2 {
    private String nombre;
    private double valor;

    public metodo_2(String nombre, double valor) {
        this.nombre = nombre;
        this.valor = valor;
    }

    public String MostrarInfo() {
        return "Nombre: " + nombre + ", Valor: " + valor;
    }
}
