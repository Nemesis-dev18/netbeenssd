package com.mycompany.ejercicio_119;

public class metodo_119 implements RegistrarUsuario, AsignarCurso {

    private String usuario;
    private String curso;

    public metodo_119(String usuario) {

        if (usuario == null || usuario.trim().isEmpty()) {
            this.usuario = "Usuario";
        } else {
            this.usuario = usuario;
        }
    }

    @Override
    public String registrar(String nombre) {
        this.usuario = nombre;
        return "Usuario registrado: " + usuario;
    }

    @Override
    public String asignar(String curso) {

        if (curso == null || curso.trim().isEmpty()) {
            this.curso = "Sin curso";
        } else {
            this.curso = curso;
        }

        return "Curso asignado a " + usuario + ": " + this.curso;
    }

    public String MostrarInfo() {
        return "PlataformaEducativa{" +
                "usuario=" + usuario +
                ", curso=" + curso +
                '}';
    }
}