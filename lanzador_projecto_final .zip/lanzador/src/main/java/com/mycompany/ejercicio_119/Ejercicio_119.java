package com.mycompany.ejercicio_119;

import java.util.Scanner;

public class Ejercicio_119 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String nombre = textoValido("Ingrese nombre del usuario");
        String curso = textoValido("Ingrese nombre del curso");

        metodo_119 p1 = new metodo_119(nombre);

        System.out.println(p1.registrar(nombre));
        System.out.println(p1.asignar(curso));
        System.out.println(p1.MostrarInfo());
    }

    public static String textoValido(String mensaje) {
        while (true) {
            System.out.println(mensaje + ":");
            String dato = entrada.nextLine();

            if (!dato.trim().isEmpty()) return dato;
            else System.out.println("No puede estar vacío");
        }
    }
}