package com.mycompany.ejercicio_119;

public interface RegistrarUsuario {
    public String registrar(String nombre);
}