package com.mycompany.ejercicio_119;

public interface AsignarCurso {
    public String asignar(String curso);
}