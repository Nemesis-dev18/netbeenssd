
package com.mycompany.ejercicio_87;

import java.util.Scanner;

public class Ejercicio_87 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String nombre = texto("Ingrese nombre");
        int edad = entero("Ingrese edad");

        Profesor p = new Profesor(nombre, edad, "Matematicas");
        Estudiante e = new Estudiante(nombre, edad, "Ingenieria");

        p.MostrarInfo();
        e.MostrarInfo();
    }

    public static String texto(String m) {
        System.out.println(m + ":");
        return entrada.nextLine();
    }

    public static int entero(String m) {
        while (true) {
            try {
                System.out.println(m + ":");
                int n = entrada.nextInt();
                entrada.nextLine();
                return n;
            } catch (Exception e) {
                entrada.nextLine();
            }
        }
    }
}
