
package com.mycompany.ejercicio_87;

public class Estudiante extends Persona {

    private String carrera;

    public Estudiante(String nombre, int edad, String carrera) {
        super(nombre, edad);
        this.carrera = carrera;
    }

    @Override
    public void MostrarInfo() {
        super.MostrarInfo();
        System.out.println("Carrera: " + carrera);
    }
}
