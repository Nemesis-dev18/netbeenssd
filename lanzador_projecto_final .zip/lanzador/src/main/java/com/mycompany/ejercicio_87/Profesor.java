
package com.mycompany.ejercicio_87;

public class Profesor extends Persona {

    private String materia;

    public Profesor(String nombre, int edad, String materia) {
        super(nombre, edad);
        this.materia = materia;
    }

    @Override
    public void MostrarInfo() {
        super.MostrarInfo();
        System.out.println("Materia: " + materia);
    }
}
