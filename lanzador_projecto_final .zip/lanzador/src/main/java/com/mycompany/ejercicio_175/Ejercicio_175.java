
package com.mycompany.ejercicio_175;

public class Ejercicio_175 {
    public static void main(String[] args) {
        Libro l = new Libro();
        l.prestar();
        System.out.println(l.isPrestado());
    }
}
