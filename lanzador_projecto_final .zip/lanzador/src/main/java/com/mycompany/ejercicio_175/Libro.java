
package com.mycompany.ejercicio_175;

public class Libro {
    private boolean prestado;

    public void prestar(){
        if(!prestado){
            prestado = true;
        }
    }

    public void devolver(){
        prestado = false;
    }

    public boolean isPrestado(){
        return prestado;
    }
}
