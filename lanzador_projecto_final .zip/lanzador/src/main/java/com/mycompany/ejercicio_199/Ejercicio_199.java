package com.mycompany.ejercicio_199;

import java.util.Scanner;

public class Ejercicio_199 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        int productos = enteroNoNegativo("Ingrese número de productos");
        double valor = decimalNoNegativo("Ingrese valor total");

        metodo_199 i1 = new metodo_199(productos, valor);

        System.out.println(i1.MostrarInfo());

        int nuevosProductos = enteroNoNegativo("Ingrese nueva cantidad de productos");
        i1.setProductos(nuevosProductos);

        double nuevoValor = decimalNoNegativo("Ingrese nuevo valor total");
        i1.setValorTotal(nuevoValor);

        System.out.println("Datos actualizados:");
        System.out.println(i1.MostrarInfo());
    }

    public static int enteroNoNegativo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                int num = entrada.nextInt();
                entrada.nextLine();

                if (num >= 0) return num;
                else System.out.println("No puede ser negativo");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }

    public static double decimalNoNegativo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                double num = entrada.nextDouble();
                entrada.nextLine();

                if (num >= 0) return num;
                else System.out.println("No puede ser negativo");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }
}