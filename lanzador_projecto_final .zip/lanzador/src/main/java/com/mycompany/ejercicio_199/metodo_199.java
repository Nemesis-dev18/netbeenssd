package com.mycompany.ejercicio_199;

public class metodo_199 {
    private int productos;
    private double valorTotal;

    public metodo_199(int productos, double valorTotal) {

        if (productos >= 0) {
            this.productos = productos;
        } else {
            this.productos = 0;
        }

        if (valorTotal >= 0) {
            this.valorTotal = valorTotal;
        } else {
            this.valorTotal = 0;
        }
    }

    public void setProductos(int productos) {
        if (productos >= 0) {
            this.productos = productos;
        } else {
            System.out.println("Cantidad inválida");
        }
    }

    public void setValorTotal(double valorTotal) {
        if (valorTotal >= 0) {
            this.valorTotal = valorTotal;
        } else {
            System.out.println("Valor inválido");
        }
    }

    public int getProductos() {
        return productos;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public String MostrarInfo() {
        return "InventarioTienda{" +
                "productos=" + productos +
                ", valorTotal=" + valorTotal +
                '}';
    }
}