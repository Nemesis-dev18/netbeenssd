package com.mycompany.ejercicio_149;
public class Ejercicio_149{
 public static void main(String[] args){
  Conversion c=new Conversion();
  System.out.println(c.convertir(1000));
  System.out.println(c.convertir(10,true));
 }
}