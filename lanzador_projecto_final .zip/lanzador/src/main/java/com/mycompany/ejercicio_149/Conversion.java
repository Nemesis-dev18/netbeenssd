package com.mycompany.ejercicio_149;
public class Conversion{
 public double convertir(double metros){
  return metros/1000;
 }
 public double convertir(double metros,boolean aCentimetros){
  if(aCentimetros) return metros*100;
  return metros/1000;
 }
}