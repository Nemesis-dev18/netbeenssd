
package com.mycompany.ejercicio_176;

public class Usuario {
    private String password;

    public void setPassword(String password){
        if(password != null && password.length() >= 6){
            this.password = password;
        }
    }

    public boolean validarPassword(String intento){
        return password != null && password.equals(intento);
    }
}
