
package com.mycompany.ejercicio_176;

public class Ejercicio_176 {
    public static void main(String[] args) {
        Usuario u = new Usuario();
        u.setPassword("123456");
        System.out.println(u.validarPassword("123456"));
    }
}
