
package com.mycompany.ejercicio_78;

public class metodo_78 {

    private int buses;
    private int rutas;

    public metodo_78(int buses, int rutas) {
        this.buses = buses;
        this.rutas = rutas;
    }

    public void MostrarInfo() {
        System.out.println("Buses: " + buses + ", Rutas: " + rutas);
    }
}
