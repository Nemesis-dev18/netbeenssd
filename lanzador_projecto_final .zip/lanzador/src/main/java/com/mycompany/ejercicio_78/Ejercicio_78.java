
package com.mycompany.ejercicio_78;

import java.util.Scanner;

public class Ejercicio_78 {
    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        int buses = entero("Ingrese número de buses");
        int rutas = entero("Ingrese número de rutas");

        metodo_78 obj = new metodo_78(buses, rutas);
        obj.MostrarInfo();
    }

    public static int entero(String m) {
        while (true) {
            try {
                System.out.println(m + ":");
                int n = entrada.nextInt();
                entrada.nextLine();
                return n;
            } catch (Exception e) {
                entrada.nextLine();
            }
        }
    }
}
