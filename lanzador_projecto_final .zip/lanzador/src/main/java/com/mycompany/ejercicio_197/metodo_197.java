package com.mycompany.ejercicio_197;

public class metodo_197 {
    private int buses;
    private int rutas;

    public metodo_197(int buses, int rutas) {

        if (buses > 0) {
            this.buses = buses;
        } else {
            this.buses = 1;
        }

        if (rutas > 0) {
            this.rutas = rutas;
        } else {
            this.rutas = 1;
        }
    }

    public void setBuses(int buses) {
        if (buses > 0) {
            this.buses = buses;
        } else {
            System.out.println("Valor inválido para buses");
        }
    }

    public void setRutas(int rutas) {
        if (rutas > 0) {
            this.rutas = rutas;
        } else {
            System.out.println("Valor inválido para rutas");
        }
    }

    public int getBuses() {
        return buses;
    }

    public int getRutas() {
        return rutas;
    }

    public String MostrarInfo() {
        return "SistemaTransporte{" +
                "buses=" + buses +
                ", rutas=" + rutas +
                '}';
    }
}