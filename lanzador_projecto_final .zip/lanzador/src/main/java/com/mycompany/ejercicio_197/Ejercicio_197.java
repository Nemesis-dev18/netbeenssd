package com.mycompany.ejercicio_197;

import java.util.Scanner;

public class Ejercicio_197 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        int buses = enteroPositivo("Ingrese número de buses");
        int rutas = enteroPositivo("Ingrese número de rutas");

        metodo_197 s1 = new metodo_197(buses, rutas);

        System.out.println(s1.MostrarInfo());

        int nuevosBuses = enteroPositivo("Ingrese nuevo número de buses");
        s1.setBuses(nuevosBuses);

        int nuevasRutas = enteroPositivo("Ingrese nuevo número de rutas");
        s1.setRutas(nuevasRutas);

        System.out.println("Datos actualizados:");
        System.out.println(s1.MostrarInfo());
    }

    public static int enteroPositivo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                int num = entrada.nextInt();
                entrada.nextLine();

                if (num > 0) return num;
                else System.out.println("Debe ser mayor a 0");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }
}