package com.mycompany.ejercicio_147;
public class Tiempo{
 public int convertir(int horas){
  return horas*60;
 }
 public int convertir(int horas,int minutos){
  return horas*60+minutos;
 }
}