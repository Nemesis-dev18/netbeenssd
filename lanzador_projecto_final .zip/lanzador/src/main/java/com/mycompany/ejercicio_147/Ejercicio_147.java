package com.mycompany.ejercicio_147;
public class Ejercicio_147{
 public static void main(String[] args){
  Tiempo t=new Tiempo();
  System.out.println(t.convertir(2));
  System.out.println(t.convertir(2,30));
 }
}