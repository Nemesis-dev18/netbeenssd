package com.mycompany.ejercicio_11;

public class metodo_11 {
    private String nombre;
    private double valor;

    public metodo_11(String nombre, double valor) {
        this.nombre = nombre;
        this.valor = valor;
    }

    public String MostrarInfo() {
        return "Nombre: " + nombre + ", Valor: " + valor;
    }
}
