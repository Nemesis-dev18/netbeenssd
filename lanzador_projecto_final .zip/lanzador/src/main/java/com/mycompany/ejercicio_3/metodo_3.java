package com.mycompany.ejercicio_3;

public class metodo_3 {
    private String nombre;
    private double valor;

    public metodo_3(String nombre, double valor) {
        this.nombre = nombre;
        this.valor = valor;
    }

    public String MostrarInfo() {
        return "Nombre: " + nombre + ", Valor: " + valor;
    }
}
