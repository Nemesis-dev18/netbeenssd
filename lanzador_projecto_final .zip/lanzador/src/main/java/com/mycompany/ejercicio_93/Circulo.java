
package com.mycompany.ejercicio_93;

public class Circulo extends Figura{

    private double radio;

    public Circulo(String color, double radio){
        super(color);
        this.radio = radio;
    }

    @Override
    public void MostrarInfo(){
        super.MostrarInfo();
        System.out.println("Radio: " + radio);
    }
}
