
package com.mycompany.ejercicio_93;

public class Figura {
    protected String color;

    public Figura(String color){
        this.color = color;
    }

    public void MostrarInfo(){
        System.out.println("Color: " + color);
    }
}
