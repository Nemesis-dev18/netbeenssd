
package com.mycompany.ejercicio_93;

public class Ejercicio_93 {
    public static void main(String[] args){
        Circulo c = new Circulo("Rojo", 5);
        Rectangulo r = new Rectangulo("Azul", 4, 6);

        c.MostrarInfo();
        r.MostrarInfo();
    }
}
