
package com.mycompany.ejercicio_93;

public class Rectangulo extends Figura{

    private double base;
    private double altura;

    public Rectangulo(String color, double base, double altura){
        super(color);
        this.base = base;
        this.altura = altura;
    }

    @Override
    public void MostrarInfo(){
        super.MostrarInfo();
        System.out.println("Base: " + base + ", Altura: " + altura);
    }
}
