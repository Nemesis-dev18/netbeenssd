
package com.mycompany.ejercicio_76;

public class metodo_76 {

    private int productos;
    private double valor;

    public metodo_76(int productos, double valor) {
        this.productos = productos;
        this.valor = valor;
    }

    public void MostrarInfo() {
        System.out.println("Productos: " + productos +
                ", Valor total: " + valor);
    }

    public void agregarProductos(int cantidad) {
        productos += cantidad;
    }
}
