
package com.mycompany.ejercicio_76;

import java.util.Scanner;

public class Ejercicio_76 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        int productos = entero("Ingrese numero de productos");
        double valor = numero("Ingrese valor total");

        metodo_76 obj = new metodo_76(productos, valor);

        obj.MostrarInfo();
        obj.agregarProductos(3);
        obj.MostrarInfo();
    }

    public static int entero(String m) {
        while (true) {
            try {
                System.out.println(m + ":");
                int n = entrada.nextInt();
                entrada.nextLine();
                return n;
            } catch (Exception e) {
                entrada.nextLine();
            }
        }
    }

    public static double numero(String m) {
        while (true) {
            try {
                System.out.println(m + ":");
                double n = entrada.nextDouble();
                entrada.nextLine();
                return n;
            } catch (Exception e) {
                entrada.nextLine();
            }
        }
    }
}
