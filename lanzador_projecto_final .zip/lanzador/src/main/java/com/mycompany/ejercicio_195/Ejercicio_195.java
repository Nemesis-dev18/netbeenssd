package com.mycompany.ejercicio_195;

import java.util.Scanner;

public class Ejercicio_195 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String placa = textoValido("Ingrese placa");
        String conductor = textoValido("Ingrese nombre del conductor");
        double tarifa = decimalPositivo("Ingrese tarifa base");

        metodo_195 t1 = new metodo_195(placa, conductor, tarifa);

        System.out.println(t1.MostrarInfo());

        double nuevaTarifa = decimalPositivo("Ingrese nueva tarifa");
        t1.setTarifa(nuevaTarifa);

        System.out.println("Datos actualizados:");
        System.out.println(t1.MostrarInfo());
    }

    public static String textoValido(String mensaje) {
        while (true) {
            System.out.println(mensaje + ":");
            String dato = entrada.nextLine();

            if (!dato.trim().isEmpty()) return dato;
            else System.out.println("No puede estar vacío");
        }
    }

    public static double decimalPositivo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                double num = entrada.nextDouble();
                entrada.nextLine();

                if (num > 0) return num;
                else System.out.println("Debe ser mayor a 0");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }
}