package com.mycompany.ejercicio_195;

public class metodo_195 {
    private String placa;
    private String conductor;
    private double tarifa;

    public metodo_195(String placa, String conductor, double tarifa) {

        if (placa == null || placa.trim().isEmpty()) {
            this.placa = "Sin placa";
        } else {
            this.placa = placa;
        }

        if (conductor == null || conductor.trim().isEmpty()) {
            this.conductor = "Sin conductor";
        } else {
            this.conductor = conductor;
        }

        if (tarifa > 0) {
            this.tarifa = tarifa;
        } else {
            this.tarifa = 1;
        }
    }

    public void setTarifa(double tarifa) {
        if (tarifa > 0) {
            this.tarifa = tarifa;
        } else {
            System.out.println("Tarifa inválida");
        }
    }

    public String getPlaca() {
        return placa;
    }

    public String getConductor() {
        return conductor;
    }

    public double getTarifa() {
        return tarifa;
    }

    public String MostrarInfo() {
        return "Taxi{" +
                "placa=" + placa +
                ", conductor=" + conductor +
                ", tarifa=" + tarifa +
                '}';
    }
}