
package com.mycompany.ejercicio_35;

public class metodo_35 {
    
    private String nombre_del_curos;
    private String intructo;
    private int duracion ;

    public metodo_35(String nombre_del_curos, String intructo, int duracion) {
        this.nombre_del_curos = nombre_del_curos;
        this.intructo = intructo;
        this.duracion = duracion;
    }

    public String getNombre_del_curos() {
        return nombre_del_curos;
    }

    public String getIntructo() {
        return intructo;
    }

    public int getDuracion() {
        return duracion;
    }

    @Override
    public String toString() {
        return "metodo_35{" + "nombre_del_curos=" + nombre_del_curos + ", intructo=" + intructo + ", duracion=" + duracion + '}';
    }
    
    
    
}
