package com.mycompany.ejercicio_35;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Ejercicio_35 {
    static Scanner  entrada = new Scanner(System.in);
    static ArrayList<metodo_35> lista = new ArrayList<>();
    
    public static void main(String[] args) {
        
        String respuesta = "si";
        
        do {
            try {
                System.out.println("===============");
                String curso = texto(" ingrese el nombre del curso  ");
                String intructore = texto("ingrese el nombre del instructor ");
                int duracion  = numeros("ingrese la cantidad de horas del curso");
                metodo_35 nomb = new metodo_35(curso, intructore, duracion);
                lista.add(nomb);
                
                
                do {
                    respuesta = texto("¿Desea agregar otro? (si/no)");
                } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
                
            } catch (InputMismatchException e) {
                System.out.println("El dato está mal.");
                entrada.nextLine();                
            }
            
        } while (respuesta.equalsIgnoreCase("si"));
        for (metodo_35 string : lista) {
            System.out.println( string);
            
        }
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }
    
    public static int numeros(String mensaje) {
        System.out.println(mensaje + " :");
        int numero = entrada.nextInt();
        entrada.nextLine();
        return numero;
    }
}
