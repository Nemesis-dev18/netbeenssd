
package com.mycompany.ejercicio_91;

public class Guitarra extends InstrumentoMusical{

    public Guitarra(String nombre, String tipo){
        super(nombre, tipo);
    }
}
