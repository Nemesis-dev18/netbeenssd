
package com.mycompany.ejercicio_91;

public class Piano extends InstrumentoMusical{

    public Piano(String nombre, String tipo){
        super(nombre, tipo);
    }
}
