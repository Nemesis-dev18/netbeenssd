
package com.mycompany.ejercicio_91;

public class Ejercicio_91 {
    public static void main(String[] args){
        Guitarra g = new Guitarra("Guitarra", "Cuerda");
        Piano p = new Piano("Piano", "Teclado");

        g.MostrarInfo();
        p.MostrarInfo();
    }
}
