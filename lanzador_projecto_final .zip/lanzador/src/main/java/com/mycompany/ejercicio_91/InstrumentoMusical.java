
package com.mycompany.ejercicio_91;

public class InstrumentoMusical {
    protected String nombre;
    protected String tipo;

    public InstrumentoMusical(String nombre, String tipo){
        this.nombre = nombre;
        this.tipo = tipo;
    }

    public void MostrarInfo(){
        System.out.println("Nombre: " + nombre + ", Tipo: " + tipo);
    }
}
