package com.mycompany.ejercicio_153;

import java.util.Scanner;

public class Ejercicio_153 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        metodo_153 s1 = new metodo_153();

        String nombre = texto("Ingrese nombre del cliente");

        int opcion = enteroPositivo("Seleccione tipo de reserva:\n1. Hotel\n2. Vuelo\n3. Evento");

        switch (opcion) {

            case 1:
                int noches = enteroPositivo("Ingrese número de noches");
                System.out.println(s1.reservar(nombre, noches));
                break;

            case 2:
                String destino = texto("Ingrese destino");
                System.out.println(s1.reservar(nombre, destino));
                break;

            case 3:
                String evento = texto("Ingrese nombre del evento");
                int cantidad = enteroPositivo("Ingrese cantidad de entradas");
                System.out.println(s1.reservar(nombre, evento, cantidad));
                break;

            default:
                System.out.println("Opción inválida");
        }
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }

    public static int enteroPositivo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                int num = entrada.nextInt();
                entrada.nextLine();

                if (num > 0) return num;
                else System.out.println("Debe ser mayor a 0");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }
}