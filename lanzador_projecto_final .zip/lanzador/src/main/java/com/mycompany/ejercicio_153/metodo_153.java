package com.mycompany.ejercicio_153;

public class metodo_153 {

    // Reserva hotel
    public String reservar(String nombre, int noches) {
        return "Reserva Hotel -> Cliente: " + nombre + ", noches: " + noches;
    }

    // Reserva vuelo
    public String reservar(String nombre, String destino) {
        return "Reserva Vuelo -> Cliente: " + nombre + ", destino: " + destino;
    }

    // Reserva evento
    public String reservar(String nombre, String evento, int cantidad) {
        return "Reserva Evento -> Cliente: " + nombre + ", evento: " + evento + ", entradas: " + cantidad;
    }
}