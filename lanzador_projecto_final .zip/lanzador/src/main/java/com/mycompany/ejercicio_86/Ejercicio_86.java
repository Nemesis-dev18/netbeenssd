
package com.mycompany.ejercicio_86;

import java.util.Scanner;

public class Ejercicio_86 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String numero = texto("Ingrese numero de cuenta");
        double saldo = numeroD("Ingrese saldo");
        double tasa = numeroD("Ingrese tasa");

        CuentaAhorros c = new CuentaAhorros(numero, saldo, tasa);
        c.MostrarInfo();
    }

    public static String texto(String m) {
        System.out.println(m + ":");
        return entrada.nextLine();
    }

    public static double numeroD(String m) {
        while (true) {
            try {
                System.out.println(m + ":");
                double n = entrada.nextDouble();
                entrada.nextLine();
                return n;
            } catch (Exception e) {
                entrada.nextLine();
            }
        }
    }
}
