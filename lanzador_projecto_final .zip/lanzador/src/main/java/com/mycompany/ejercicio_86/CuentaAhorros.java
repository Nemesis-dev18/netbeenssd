
package com.mycompany.ejercicio_86;

public class CuentaAhorros extends CuentaBancaria {

    private double tasa;

    public CuentaAhorros(String numero, double saldo, double tasa) {
        super(numero, saldo);
        this.tasa = tasa;
    }

    @Override
    public void MostrarInfo() {
        super.MostrarInfo();
        System.out.println("Tasa: " + tasa);
    }
}
