
package com.mycompany.ejercicio_86;

public class CuentaBancaria {
    protected String numero;
    protected double saldo;

    public CuentaBancaria(String numero, double saldo) {
        this.numero = numero;
        this.saldo = saldo;
    }

    public void MostrarInfo() {
        System.out.println("Cuenta: " + numero + ", Saldo: " + saldo);
    }
}
