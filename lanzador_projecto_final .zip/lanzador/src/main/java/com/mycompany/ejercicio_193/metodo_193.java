package com.mycompany.ejercicio_193;

public class metodo_193 {
    private int numeroPedido;
    private double valor;

    public metodo_193(int numeroPedido, double valor) {

        if (numeroPedido > 0) {
            this.numeroPedido = numeroPedido;
        } else {
            this.numeroPedido = 1;
        }

        if (valor >= 0) {
            this.valor = valor;
        } else {
            this.valor = 0;
        }
    }

    public void setValor(double valor) {
        if (valor >= 0) {
            this.valor = valor;
        } else {
            System.out.println("Valor inválido");
        }
    }

    public int getNumeroPedido() {
        return numeroPedido;
    }

    public double getValor() {
        return valor;
    }

    public String MostrarInfo() {
        return "Pedido{" +
                "numeroPedido=" + numeroPedido +
                ", valor=" + valor +
                '}';
    }
}