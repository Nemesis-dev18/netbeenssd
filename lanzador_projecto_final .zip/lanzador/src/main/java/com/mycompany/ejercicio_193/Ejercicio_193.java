package com.mycompany.ejercicio_193;

import java.util.Scanner;

public class Ejercicio_193 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        int numero = enteroPositivo("Ingrese número de pedido");
        double valor = decimalNoNegativo("Ingrese valor inicial");

        metodo_193 p1 = new metodo_193(numero, valor);

        System.out.println(p1.MostrarInfo());

        double nuevoValor = decimalNoNegativo("Ingrese nuevo valor del pedido");
        p1.setValor(nuevoValor);

        System.out.println("Datos actualizados:");
        System.out.println(p1.MostrarInfo());
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }

    public static int enteroPositivo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                int num = entrada.nextInt();
                entrada.nextLine();

                if (num > 0) return num;
                else System.out.println("Debe ser mayor a 0");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }

    public static double decimalNoNegativo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                double num = entrada.nextDouble();
                entrada.nextLine();

                if (num >= 0) return num;
                else System.out.println("No puede ser negativo");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }
}