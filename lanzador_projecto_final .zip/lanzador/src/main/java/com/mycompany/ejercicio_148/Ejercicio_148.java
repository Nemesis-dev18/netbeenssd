package com.mycompany.ejercicio_148;
public class Ejercicio_148{
 public static void main(String[] args){
  Promedio p=new Promedio();
  System.out.println(p.calcular(4,6));
  System.out.println(p.calcular(4,6,8));
 }
}