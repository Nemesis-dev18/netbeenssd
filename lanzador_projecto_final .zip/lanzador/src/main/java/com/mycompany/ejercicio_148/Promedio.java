package com.mycompany.ejercicio_148;
public class Promedio{
 public double calcular(double a,double b){
  return (a+b)/2;
 }
 public double calcular(double a,double b,double c){
  return (a+b+c)/3;
 }
}