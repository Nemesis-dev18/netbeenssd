/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_115;

/**
 *
 * @author Nemesis
 */
public class empleado implements reporte,trabajaronline{
    private String nombre ;

    public empleado(String nombre) {
        this.nombre = nombre;
    }
    
    @Override
    public void trabajaronline (){
        System.out.println(" 'el trabajador' " + nombre + "va a trabajar online");
    }
    @Override
    public void reporte (){
        System.out.println(" 'el trabajador' " + nombre + "esta enviando el reporte");
    }
    
}
