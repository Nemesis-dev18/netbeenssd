/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio_115;

/**
 *
 * @author Nemesis
 */
public class Ejercicio_115 {

    public static void main(String[] args) {
       empleado persona = new empleado("esclavo_1 ");
       persona.trabajaronline();
       persona.reporte();
    }
}
