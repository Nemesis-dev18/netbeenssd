package com.mycompany.ejercicio_140;
public class Ejercicio_140{
 public static void main(String[] args){
  ConversorTemperatura c=new ConversorTemperatura();
  System.out.println(c.convertir(0));
  System.out.println(c.convertir(32,true));
 }
}