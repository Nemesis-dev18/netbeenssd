package com.mycompany.ejercicio_140;
public class ConversorTemperatura{
 public double convertir(double c){ return c*9/5+32; }
 public double convertir(double f,boolean aKelvin){
  if(aKelvin) return (f-32)*5/9+273;
  return f;
 }
}