
package com.mycompany.ejercicio_169;

public class Ejercicio_169 {
    public static void main(String[] args) {
        Producto p = new Producto();
        p.setPrecio(150);
        System.out.println(p.getPrecio());
    }
}
