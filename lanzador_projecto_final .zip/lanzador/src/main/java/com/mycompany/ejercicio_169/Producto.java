
package com.mycompany.ejercicio_169;

public class Producto {
    private double precio;

    public void setPrecio(double precio){
        if(precio > 0){
            this.precio = precio;
        }
    }

    public double getPrecio(){
        return precio;
    }
}
