/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_57;

/**
 *
 * @author Nemesis
 */
public class metodo_57 {
    private String nombre;
    private int cant_creditos ;

    public metodo_57(String nombre, int cant_creditos) {
        this.nombre = nombre;
        this.cant_creditos = cant_creditos;
    }

    @Override
    public String toString() {
        return "metodo_57{" + "nombre=" + nombre + ", cant_creditos=" + cant_creditos + '}';
    }
    
    
    
}
