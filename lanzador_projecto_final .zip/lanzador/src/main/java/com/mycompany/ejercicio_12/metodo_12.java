package com.mycompany.ejercicio_12;

public class metodo_12 {
    private String nombre;
    private double valor;

    public metodo_12(String nombre, double valor) {
        this.nombre = nombre;
        this.valor = valor;
    }

    public String MostrarInfo() {
        return "Nombre: " + nombre + ", Valor: " + valor;
    }
}
