/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejericico_54;

/**
 *
 * @author Nemesis
 */
public class metodo_54 {
    private int num_espacios;
    private int carros_parqueados ;

    public metodo_54(int num_espacios, int carros_parqueados) {
        this.num_espacios = num_espacios;
        this.carros_parqueados = carros_parqueados;
    }
    public String disponibilidad (){
        if (num_espacios < carros_parqueados ) {
            return " hay sobre cupo y no se pueden meter los carros ";
        }
        return "quedan en cupos disponibles del parqueadero :"+(num_espacios-carros_parqueados);
    }

    @Override
    public String toString() {
        return "metodo_54{" + "num_espacios=" + num_espacios + ", carros_parqueados=" + carros_parqueados +"| "+ disponibilidad()+ '}';
    }
    
    
    
    
    
}
