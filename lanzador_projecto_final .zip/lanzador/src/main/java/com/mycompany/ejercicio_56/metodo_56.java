
package com.mycompany.ejercicio_56;

public class metodo_56 {
    private int num_libros ;
    private int registros ; 

    public metodo_56(int num_libros, int registros) {
        this.num_libros = num_libros;
        this.registros = registros;
    }

    @Override
    public String toString() {
        return "metodo_56{" + "num_libros=" + num_libros + ", registros=" + registros + '}';
    }
    
    
}
