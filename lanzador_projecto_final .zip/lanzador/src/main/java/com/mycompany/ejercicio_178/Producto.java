
package com.mycompany.ejercicio_178;

public class Producto {
    private int stock;

    public void setStock(int stock){
        if(stock >= 0) this.stock = stock;
    }

    public boolean vender(int cantidad){
        if(cantidad > 0 && cantidad <= stock){
            stock -= cantidad;
            return true;
        }
        return false;
    }

    public int getStock(){ return stock; }
}
