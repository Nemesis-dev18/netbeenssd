
package com.mycompany.ejercicio_178;

public class Ejercicio_178 {
    public static void main(String[] args) {
        Producto p = new Producto();
        p.setStock(10);
        p.vender(4);
        System.out.println(p.getStock());
    }
}
