
package com.mycompany.ejercicio_189;

public class Ejercicio_189 {
    public static void main(String[] args) {
        Universidad u1 = new Universidad();
        u1.setNombre("UNAL");
        u1.setFacultades(5);
        System.out.println(u1);
    }
}
