
package com.mycompany.ejercicio_189;

public class Universidad {
    private String nombre;
    private int facultades;

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public int getFacultades() { return facultades; }
    public void setFacultades(int facultades) { this.facultades = facultades; }

    @Override
    public String toString() {
        return "Universidad{" + "nombre=" + nombre + ", facultades=" + facultades + '}';
    }
}
