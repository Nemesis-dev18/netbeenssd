
package com.mycompany.ejercicio_162;

public class Ejercicio_162 {
    public static void main(String[] args) {
        Estudiante e = new Estudiante();
        e.setNombre("Ana");
        e.setCodigo("123");
        e.setPromedio(4.5);
        System.out.println(e.getNombre()+" "+e.getCodigo()+" "+e.getPromedio());
    }
}
