
package com.mycompany.ejercicio_162;

public class Estudiante {
    private String nombre;
    private String codigo;
    private double promedio;

    public String getNombre(){ return nombre; }
    public void setNombre(String nombre){ this.nombre = nombre; }

    public String getCodigo(){ return codigo; }
    public void setCodigo(String codigo){ this.codigo = codigo; }

    public double getPromedio(){ return promedio; }
    public void setPromedio(double promedio){ this.promedio = promedio; }
}
