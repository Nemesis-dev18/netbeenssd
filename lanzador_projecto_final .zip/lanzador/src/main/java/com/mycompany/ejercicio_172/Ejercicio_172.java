
package com.mycompany.ejercicio_172;

public class Ejercicio_172 {
    public static void main(String[] args) {
        Cuenta c = new Cuenta();
        c.depositar(1000);
        if(c.retirar(300)){
            System.out.println("Retiro exitoso");
        }
        System.out.println(c.getSaldo());
    }
}
