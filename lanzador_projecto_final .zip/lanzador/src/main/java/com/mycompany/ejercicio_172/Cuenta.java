
package com.mycompany.ejercicio_172;

public class Cuenta {
    private double saldo;

    public void depositar(double monto){
        if(monto > 0){
            saldo += monto;
        }
    }

    public boolean retirar(double monto){
        if(monto > 0 && monto <= saldo){
            saldo -= monto;
            return true;
        }
        return false;
    }

    public double getSaldo(){
        return saldo;
    }
}
