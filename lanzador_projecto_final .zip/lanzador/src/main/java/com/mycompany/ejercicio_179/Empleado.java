
package com.mycompany.ejercicio_179;

public class Empleado {
    private double salario;

    public void setSalario(double salario){
        if(salario > 0) this.salario = salario;
    }

    public void aplicarBono(double bono){
        if(bono > 0) salario += bono;
    }

    public double getSalario(){ return salario; }
}
