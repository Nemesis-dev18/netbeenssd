
package com.mycompany.ejercicio_179;

public class Ejercicio_179 {
    public static void main(String[] args) {
        Empleado e = new Empleado();
        e.setSalario(2000);
        e.aplicarBono(500);
        System.out.println(e.getSalario());
    }
}
