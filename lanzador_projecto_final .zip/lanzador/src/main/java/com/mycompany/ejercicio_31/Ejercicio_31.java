package com.mycompany.ejercicio_31;

import java.util.ArrayList;
import java.util.Scanner;



public class Ejercicio_31 {
    static Scanner entrada = new Scanner(System.in);
    static ArrayList<metodo_31> lista = new ArrayList<>();

    
    public static void main(String[] args) {
        try {
          String nombre_p = texto("ingrese el nombre del producto ");
                int cantidad = numeros("ingrese cantidad de productos ");
                
                metodo_31 producto = new metodo_31(nombre_p, cantidad);
                lista.add(producto);
               
      String respuesta;

    do {
       int opcion = numeros(
    "---------------\n" +
    "MENU\n\n" +
    "1. Agregar\n" +
    "2. Mostrar cantidad de producto"
);

        int valor = 0;

        if (opcion == 1 ) {
            System.out.println("Ingrese la cantidad :");
            valor = entrada.nextInt();
            entrada.nextLine();
             String resultado = producto.opciones(opcion,valor);
             System.out.println(resultado);
        }
        if (opcion == 2) {
            String datos = producto.opciones(opcion, 0);
            System.out.println(datos);         
        }
       do {
       respuesta = texto("¿Desea hacer  otro? (si/no)");
        } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
                
    } while (respuesta.equalsIgnoreCase("si"));
    
        } catch (Exception e) {
            System.out.println("los datos estan mal ");
        }
}
    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();}
    public static int numeros(String mensaje) {
        System.out.println(mensaje + " :");
        int numero = entrada.nextInt();
        entrada.nextLine();
        return numero;
    }
}


