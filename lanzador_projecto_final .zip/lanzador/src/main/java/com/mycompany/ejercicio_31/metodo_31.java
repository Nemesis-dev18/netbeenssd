/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_31;

/**
 *
 * @author Nemesis
 */
public class metodo_31 {
    private String nombre ;
    private  int num_producto ;

    public metodo_31(String nombre, int num_prodcuto) {
        this.nombre = nombre;
        this.num_producto = num_prodcuto;
    }

    public String getNombre() {
        return nombre;
    }

    public int getNum_producto() {
        return num_producto;
        
        
    }

    
 public int agregar ( int valor){
        if (valor <= 0) {
    System.out.println("cantidad invalida");
    return num_producto; 
             }
         num_producto+= valor ;
        return num_producto ;
                  }
public String opciones(int opcion, int cantidad) {

    switch (opcion) {

        case 1:
            if (cantidad <= 0) {
                return "Cantidad inválida";
            }
            agregar(cantidad);
            return "Añadiendo producto. Total: " + num_producto;

        case 2:
            return "Producto: " + nombre + " | Cantidad: " + num_producto;

        default:
            return "Opción inválida";
    }
}

}
