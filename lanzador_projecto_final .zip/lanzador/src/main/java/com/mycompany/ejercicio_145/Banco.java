package com.mycompany.ejercicio_145;
public class Banco{
 public double interes(double monto){
  return monto*0.02;
 }
 public double interes(double monto,int anios){
  return monto*0.02*anios;
 }
}