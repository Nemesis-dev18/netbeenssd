package com.mycompany.ejercicio_145;
public class Ejercicio_145{
 public static void main(String[] args){
  Banco b=new Banco();
  System.out.println(b.interes(1000));
  System.out.println(b.interes(1000,2));
 }
}