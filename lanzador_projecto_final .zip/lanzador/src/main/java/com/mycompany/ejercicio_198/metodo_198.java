package com.mycompany.ejercicio_198;

public class metodo_198 {
    private String nombre;
    private String nivel;

    public metodo_198(String nombre, String nivel) {

        if (nombre == null || nombre.trim().isEmpty()) {
            this.nombre = "Sin nombre";
        } else {
            this.nombre = nombre;
        }

        if (nivel == null || nivel.trim().isEmpty()) {
            this.nivel = "Básico";
        } else {
            this.nivel = nivel;
        }
    }

    public void setNivel(String nivel) {
        if (nivel != null && !nivel.trim().isEmpty()) {
            this.nivel = nivel;
        } else {
            System.out.println("Nivel inválido");
        }
    }

    public String getNombre() {
        return nombre;
    }

    public String getNivel() {
        return nivel;
    }

    public String MostrarInfo() {
        return "CursoProgramacion{" +
                "nombre=" + nombre +
                ", nivel=" + nivel +
                '}';
    }
}