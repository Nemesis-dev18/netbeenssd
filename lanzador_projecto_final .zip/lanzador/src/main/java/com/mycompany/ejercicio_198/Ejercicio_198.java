package com.mycompany.ejercicio_198;

import java.util.Scanner;

public class Ejercicio_198 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String nombre = textoValido("Ingrese nombre del curso");
        String nivel = textoValido("Ingrese nivel (básico/intermedio/avanzado)");

        metodo_198 c1 = new metodo_198(nombre, nivel);

        System.out.println(c1.MostrarInfo());

        String nuevoNivel = textoValido("Ingrese nuevo nivel");
        c1.setNivel(nuevoNivel);

        System.out.println("Datos actualizados:");
        System.out.println(c1.MostrarInfo());
    }

    public static String textoValido(String mensaje) {
        while (true) {
            System.out.println(mensaje + ":");
            String dato = entrada.nextLine();

            if (!dato.trim().isEmpty()) return dato;
            else System.out.println("No puede estar vacío");
        }
    }
}