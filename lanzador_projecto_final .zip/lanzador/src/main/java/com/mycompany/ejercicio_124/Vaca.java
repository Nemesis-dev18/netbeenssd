package com.mycompany.ejercicio_124;

public class Vaca extends Animal {

    @Override
    public String hacerSonido() {
        return "La vaca hace muu";
    }
}