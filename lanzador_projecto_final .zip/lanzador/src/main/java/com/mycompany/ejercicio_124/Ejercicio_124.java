package com.mycompany.ejercicio_124;

public class Ejercicio_124 {

    public static void main(String[] args) {

        Animal a1 = new Perro();
        Animal a2 = new Gato();
        Animal a3 = new Vaca();

        System.out.println(a1.hacerSonido());
        System.out.println(a2.hacerSonido());
        System.out.println(a3.hacerSonido());
    }
}