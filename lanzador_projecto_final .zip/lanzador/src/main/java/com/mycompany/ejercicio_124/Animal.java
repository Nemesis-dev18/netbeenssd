package com.mycompany.ejercicio_124;

public class Animal {

    public String hacerSonido() {
        return "El animal hace un sonido";
    }
}