package com.mycompany.ejercicio_124;

public class Perro extends Animal {

    @Override
    public String hacerSonido() {
        return "El perro ladra";
    }
}