package com.mycompany.ejercicio_124;

public class Gato extends Animal {

    @Override
    public String hacerSonido() {
        return "El gato maúlla";
    }
}