package com.mycompany.ejercicio_116;

public interface Moverse {
    public String moverse();
}