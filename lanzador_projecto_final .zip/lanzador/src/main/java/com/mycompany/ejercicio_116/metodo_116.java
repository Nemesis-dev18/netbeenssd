package com.mycompany.ejercicio_116;

public class metodo_116 implements Moverse, Hablar {

    private String nombre;

    public metodo_116(String nombre) {

        if (nombre == null || nombre.trim().isEmpty()) {
            this.nombre = "Robot";
        } else {
            this.nombre = nombre;
        }
    }

    @Override
    public String moverse() {
        return nombre + " se está moviendo...";
    }

    @Override
    public String hablar() {
        return nombre + " dice: Hola humano";
    }

    public String MostrarInfo() {
        return "Robot{" + "nombre=" + nombre + '}';
    }
}