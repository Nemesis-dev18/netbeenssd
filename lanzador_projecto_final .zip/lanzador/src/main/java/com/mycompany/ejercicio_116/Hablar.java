package com.mycompany.ejercicio_116;

public interface Hablar {
    public String hablar();
}