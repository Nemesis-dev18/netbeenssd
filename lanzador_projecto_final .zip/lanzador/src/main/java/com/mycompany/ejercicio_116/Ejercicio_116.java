package com.mycompany.ejercicio_116;

import java.util.Scanner;

public class Ejercicio_116 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String nombre = textoValido("Ingrese nombre del robot");

        metodo_116 r1 = new metodo_116(nombre);

        System.out.println(r1.MostrarInfo());
        System.out.println(r1.moverse());
        System.out.println(r1.hablar());
    }

    public static String textoValido(String mensaje) {
        while (true) {
            System.out.println(mensaje + ":");
            String dato = entrada.nextLine();

            if (!dato.trim().isEmpty()) return dato;
            else System.out.println("No puede estar vacío");
        }
    }
}