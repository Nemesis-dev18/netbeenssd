
package com.mycompany.ejercicio_201;

import java.util.Scanner;

public class Ejercicio_201 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        while (true) {

            System.out.print("\nIngrese número de ejercicio (0 salir): ");
            int numero = entrada.nextInt();
            entrada.nextLine();

            if (numero == 0) break;

            String clase = "com.mycompany.ejercicio_" + numero + ".Ejercicio_" + numero;

            try {
                Class<?> cls = Class.forName(clase);
                cls.getMethod("main", String[].class)
                   .invoke(null, (Object) new String[]{});
            } catch (Exception e) {
                System.out.println("No existe o error.");
            }
        }
    }
}
