package com.mycompany.ejercicio_133;
public class UsuarioSistema{
 public String accederSistema(){ return "Acceso básico"; }
}