package com.mycompany.ejercicio_133;
public class Ejercicio_133{
 public static void main(String[] args){
  UsuarioSistema u1=new Administrador();
  UsuarioSistema u2=new Cliente();
  System.out.println(u1.accederSistema());
  System.out.println(u2.accederSistema());
 }
}