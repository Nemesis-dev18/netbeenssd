package com.mycompany.ejercicio_133;
public class Cliente extends UsuarioSistema{
 @Override public String accederSistema(){ return "Acceso limitado"; }
}