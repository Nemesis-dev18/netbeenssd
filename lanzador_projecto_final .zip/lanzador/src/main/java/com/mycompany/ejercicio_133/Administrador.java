package com.mycompany.ejercicio_133;
public class Administrador extends UsuarioSistema{
 @Override public String accederSistema(){ return "Acceso total"; }
}