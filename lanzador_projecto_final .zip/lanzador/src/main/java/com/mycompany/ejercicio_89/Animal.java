
package com.mycompany.ejercicio_89;

public class Animal {
    protected String nombre;

    public Animal(String nombre){
        this.nombre = nombre;
    }

    public void MostrarInfo(){
        System.out.println("Nombre: " + nombre);
    }
}
