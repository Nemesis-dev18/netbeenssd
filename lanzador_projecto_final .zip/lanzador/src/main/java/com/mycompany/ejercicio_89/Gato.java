
package com.mycompany.ejercicio_89;

public class Gato extends Animal{

    public Gato(String nombre){
        super(nombre);
    }
}
