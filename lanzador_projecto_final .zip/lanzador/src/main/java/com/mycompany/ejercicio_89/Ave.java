
package com.mycompany.ejercicio_89;

public class Ave extends Animal{

    public Ave(String nombre){
        super(nombre);
    }
}
