
package com.mycompany.ejercicio_89;

public class Ejercicio_89 {
    public static void main(String[] args){
        Gato g = new Gato("Michi");
        Ave a = new Ave("Loro");

        g.MostrarInfo();
        a.MostrarInfo();
    }
}
