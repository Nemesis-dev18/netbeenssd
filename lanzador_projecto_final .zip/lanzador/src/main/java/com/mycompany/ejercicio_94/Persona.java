
package com.mycompany.ejercicio_94;

public class Persona {
    protected String nombre;

    public Persona(String nombre){
        this.nombre = nombre;
    }

    public void MostrarInfo(){
        System.out.println("Nombre: " + nombre);
    }
}
