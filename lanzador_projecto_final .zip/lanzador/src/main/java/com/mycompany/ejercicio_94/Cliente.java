
package com.mycompany.ejercicio_94;

public class Cliente extends Persona{

    private int numeroCliente;

    public Cliente(String nombre, int numeroCliente){
        super(nombre);
        this.numeroCliente = numeroCliente;
    }

    @Override
    public void MostrarInfo(){
        super.MostrarInfo();
        System.out.println("Numero cliente: " + numeroCliente);
    }
}
