
package com.mycompany.ejercicio_94;

public class Ejercicio_94 {
    public static void main(String[] args){
        Cliente c = new Cliente("Juan", 101);
        c.MostrarInfo();
    }
}
