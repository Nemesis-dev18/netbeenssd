package com.mycompany.ejercio_48;
public class metodo_48 {
    private int num_ruta;
    private String destino;

    public metodo_48(int num_ruta, String destino) {
        this.num_ruta = num_ruta;
        this.destino = destino;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("metodo_48{");
        sb.append("num_ruta=").append(num_ruta);
        sb.append(", destino=").append(destino);
        sb.append('}');
        return sb.toString();
    }

    
    
    
}
