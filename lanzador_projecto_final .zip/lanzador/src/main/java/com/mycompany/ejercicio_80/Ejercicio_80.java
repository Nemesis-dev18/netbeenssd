
package com.mycompany.ejercicio_80;

import java.util.Scanner;

public class Ejercicio_80 {
    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        int ventas = entero("Ingrese número de ventas");
        double total = numero("Ingrese valor total");

        metodo_80 obj = new metodo_80(ventas, total);

        obj.MostrarInfo();
        obj.registrarVenta(100);
        obj.MostrarInfo();
    }

    public static int entero(String m) {
        while (true) {
            try {
                System.out.println(m + ":");
                int n = entrada.nextInt();
                entrada.nextLine();
                return n;
            } catch (Exception e) {
                entrada.nextLine();
            }
        }
    }

    public static double numero(String m) {
        while (true) {
            try {
                System.out.println(m + ":");
                double n = entrada.nextDouble();
                entrada.nextLine();
                return n;
            } catch (Exception e) {
                entrada.nextLine();
            }
        }
    }
}
