
package com.mycompany.ejercicio_80;

public class metodo_80 {

    private int ventas;
    private double total;

    public metodo_80(int ventas, double total) {
        this.ventas = ventas;
        this.total = total;
    }

    public void MostrarInfo() {
        System.out.println("Ventas: " + ventas + ", Total: " + total);
    }

    public void registrarVenta(double valor) {
        ventas++;
        total += valor;
    }
}
