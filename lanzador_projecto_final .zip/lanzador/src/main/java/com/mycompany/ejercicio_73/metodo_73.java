
package com.mycompany.ejercicio_73;

public class metodo_73 {

    private String nombre;
    private String genero;
    private int puntaje;

    public metodo_73(String nombre, String genero, int puntaje) {
        this.nombre = nombre;
        this.genero = genero;
        this.puntaje = puntaje;
    }

    public void MostrarInfo() {
        System.out.println("Juego: " + nombre +
                ", Genero: " + genero +
                ", Puntaje: " + puntaje);
    }

    public void actualizarPuntaje(int nuevo) {
        puntaje = nuevo;
    }
}
