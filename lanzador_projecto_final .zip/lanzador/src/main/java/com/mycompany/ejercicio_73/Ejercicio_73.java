
package com.mycompany.ejercicio_73;

import java.util.Scanner;

public class Ejercicio_73 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String nombre = texto("Ingrese el nombre del juego");
        String genero = texto("Ingrese el genero");
        int puntaje = entero("Ingrese el puntaje");

        metodo_73 obj = new metodo_73(nombre, genero, puntaje);

        obj.MostrarInfo();
        obj.actualizarPuntaje(100);
        obj.MostrarInfo();
    }

    public static String texto(String m) {
        System.out.println(m + ":");
        return entrada.nextLine();
    }

    public static int entero(String m) {
        while (true) {
            try {
                System.out.println(m + ":");
                int n = entrada.nextInt();
                entrada.nextLine();
                return n;
            } catch (Exception e) {
                entrada.nextLine();
            }
        }
    }
}
