package com.mycompany.ejercicio_1;

public class metodo_1 {
    private String nombre;
    private double valor;

    public metodo_1(String nombre, double valor) {
        this.nombre = nombre;
        this.valor = valor;
    }

    public String MostrarInfo() {
        return "Nombre: " + nombre + ", Valor: " + valor;
    }
}
