package com.mycompany.ejercicio_8;

public class metodo_8 {
    private String nombre;
    private double valor;

    public metodo_8(String nombre, double valor) {
        this.nombre = nombre;
        this.valor = valor;
    }

    public String MostrarInfo() {
        return "Nombre: " + nombre + ", Valor: " + valor;
    }
}
