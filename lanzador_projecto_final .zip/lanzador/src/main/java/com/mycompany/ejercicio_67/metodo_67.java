package com.mycompany.ejercicio_67;

public class metodo_67 {
    private String nombre;
    private int estudiantes;
    private int duracion;

    public metodo_67(String nombre, int estudiantes, int duracion) {

        if (nombre == null || nombre.trim().isEmpty()) {
            this.nombre = "Sin nombre";
        } else {
            this.nombre = nombre;
        }

        if (estudiantes >= 0) {
            this.estudiantes = estudiantes;
        } else {
            this.estudiantes = 0;
        }

        if (duracion > 0) {
            this.duracion = duracion;
        } else {
            this.duracion = 1;
        }
    }

    public void agregarEstudiantes(int cantidad) {
        if (cantidad > 0) {
            estudiantes += cantidad;
        } else {
            System.out.println("Cantidad inválida");
        }
    }

    public String MostrarInfo() {
        return "CursoVirtual{" +
                "nombre=" + nombre +
                ", estudiantes=" + estudiantes +
                ", duracion=" + duracion + " horas" +
                '}';
    }
}