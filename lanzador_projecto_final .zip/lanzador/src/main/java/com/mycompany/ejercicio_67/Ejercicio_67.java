package com.mycompany.ejercicio_67;

import java.util.Scanner;

public class Ejercicio_67 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String nombre = texto("Ingrese el nombre del curso");
        int estudiantes = enteroNoNegativo("Ingrese número de estudiantes");
        int duracion = enteroPositivo("Ingrese duración en horas");

        metodo_67 c1 = new metodo_67(nombre, estudiantes, duracion);

        int nuevos = enteroPositivo("Ingrese cantidad de estudiantes a agregar");
        c1.agregarEstudiantes(nuevos);

        System.out.println(c1.MostrarInfo());
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }

    public static int enteroPositivo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                int num = entrada.nextInt();
                entrada.nextLine();

                if (num > 0) return num;
                else System.out.println("Debe ser mayor a 0");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }

    public static int enteroNoNegativo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                int num = entrada.nextInt();
                entrada.nextLine();

                if (num >= 0) return num;
                else System.out.println("No puede ser negativo");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }
}