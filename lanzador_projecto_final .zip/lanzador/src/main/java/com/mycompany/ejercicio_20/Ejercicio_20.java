package com.mycompany.ejercicio_20;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio_20 {
static Scanner entrada = new Scanner(System.in);
static ArrayList<metodo_20> paciente = new ArrayList<>();
    public static void main(String[] args) {
        String respuesta ;
        do {          
            String  nombre = texto("ingrese su nombre ");
            int     edad = numeros("ingrese su edad");
            String  enfermedad = texto("ingrese su enfermedad ");
            metodo_20 info = new metodo_20(nombre, edad, enfermedad);
            paciente.add(info);
            do {
                respuesta = texto("¿Desea agregar otro ? (si/no)");
            } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
            
        } while (respuesta.equalsIgnoreCase("si"));
        for (metodo_20 a : paciente) {
            System.out.println(a);
            
        }
    }
    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();}
    
    public static int numeros(String mensaje) {
        System.out.println(mensaje + " :");
        int numero = entrada.nextInt();
        entrada.nextLine();
        return numero;
    }
}
