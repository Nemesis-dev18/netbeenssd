
package com.mycompany.ejercicio_20;

public class metodo_20 {
    private String nombre;
    private int edad ;
    private String enfermedad;

    public metodo_20(String nombre, int años, String enfermedad) {
        this.nombre = nombre;
        this.edad = años;
        this.enfermedad = enfermedad;
    }

    public String getNombre() {
        return nombre;
    }

    public int getEdad() {
        return edad;
    }

    public String getEnfermedad() {
        return enfermedad;
    }
    public String mayor (){
        return (edad >=18) ? "si" : "no";
   
        
    }

    @Override
    public String toString() {
        return "PACIENTE |" + "nombre:" + nombre + "| años: " + edad + "   |  enfermedad: " + enfermedad + "| mayoria de edad :"+mayor()+" |" ;
    }


    
}
