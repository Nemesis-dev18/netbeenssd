package com.mycompany.ejercicio_132;
public class Celular extends Dispositivo{
 @Override public String encender(){ return "Celular encendido"; }
}