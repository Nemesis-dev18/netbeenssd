package com.mycompany.ejercicio_132;
public class Televisor extends Dispositivo{
 @Override public String encender(){ return "TV encendida"; }
}