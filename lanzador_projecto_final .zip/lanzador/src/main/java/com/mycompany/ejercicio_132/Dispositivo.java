package com.mycompany.ejercicio_132;
public class Dispositivo{
 public String encender(){ return "Encendiendo"; }
}