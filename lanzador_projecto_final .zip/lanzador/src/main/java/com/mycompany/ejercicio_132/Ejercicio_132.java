package com.mycompany.ejercicio_132;
public class Ejercicio_132{
 public static void main(String[] args){
  Dispositivo d1=new Televisor();
  Dispositivo d2=new Computador();
  Dispositivo d3=new Celular();
  System.out.println(d1.encender());
  System.out.println(d2.encender());
  System.out.println(d3.encender());
 }
}