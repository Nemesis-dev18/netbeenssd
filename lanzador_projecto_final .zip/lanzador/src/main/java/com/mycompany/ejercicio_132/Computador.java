package com.mycompany.ejercicio_132;
public class Computador extends Dispositivo{
 @Override public String encender(){ return "PC encendido"; }
}