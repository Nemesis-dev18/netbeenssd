/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_47;

/**
 *
 * @author Nemesis
 */
public class metodo_47 {
    private     String nombre ;
private double version ;

    public metodo_47(String nombre, double version) {
        this.nombre = nombre;
        this.version = version;
    }


    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("metodo_47{");
        sb.append("nombre=").append(nombre);
        sb.append(", version=").append(version);
        sb.append('}');
        return sb.toString();
    }
    
    
    
    
}
