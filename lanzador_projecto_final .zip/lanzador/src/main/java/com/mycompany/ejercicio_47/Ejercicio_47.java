/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio_47;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Nemesis
 */
public class Ejercicio_47 {
    static Scanner entrada = new Scanner(System.in);
    static ArrayList<metodo_47> lista = new ArrayList<>();
    
    public static void main(String[] args) {
        
        String respuesta = "si";
        
        do {
            try {
                System.out.println("===============");
                String nombre = texto("ingrese el nombre de la app"); 
                double version = numeros("ingrese la version de la app  ");
                
                lista.add(new  metodo_47(nombre, version));
                do {
                    respuesta = texto("¿Desea agregar otro? (si/no)");
                } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
                
            } catch (Exception e) {
                System.out.println("El dato está mal.");
                entrada.nextLine();                
            }
            
        } while (respuesta.equalsIgnoreCase("si"));
        for (metodo_47 string : lista) {
            System.out.println(string);
            
        }
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }
    
    public static double numeros(String mensaje) {
        System.out.println(mensaje + " :");
        double numero = entrada.nextDouble();
        entrada.nextLine();
        return numero;
    }
}
