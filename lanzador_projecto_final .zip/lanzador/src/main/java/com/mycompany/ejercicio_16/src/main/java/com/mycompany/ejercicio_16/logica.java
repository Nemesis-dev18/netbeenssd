package com.mycompany.ejercicio_16;
public class logica {
    public static String val (String aereolinea , String modelo , String capacidad ){
        if (modelo.trim().isEmpty() || aereolinea.trim().isEmpty()  || capacidad.trim().isEmpty()) {
            return"error" ;
        
            
        }try {
            Double.parseDouble(capacidad);
            return "OK";
        } catch (Exception e) {
        return "ERRORN";
        }
    }
 public static String categoria(double capacidad) {

    if (capacidad < 70000) {
        return "Ligero";
    } else if (capacidad < 136000) {
        return "Mediano";
    } else if (capacidad < 200000) {
        return "Pesado";
    } else {
        return "Super pesado";
    }
}
    
}
