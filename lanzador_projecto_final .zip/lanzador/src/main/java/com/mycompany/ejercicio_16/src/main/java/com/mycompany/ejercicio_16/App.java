package com.mycompany.ejercicio_16;


import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class App extends Application {

    ObservableList<metodo_16> lista = FXCollections.observableArrayList();

    @Override
    public void start(Stage ventana) {

        //  CAMPOS
        TextField aereolinea = new TextField();
        TextField modelo = new TextField();
        TextField capacidad = new TextField();

        aereolinea.setPromptText("AEROLÍNEA");
        modelo.setPromptText("MODELO");
        capacidad.setPromptText("CAPACIDAD (KG)");

        aereolinea.setMaxWidth(200);
        modelo.setMaxWidth(200);
        capacidad.setMaxWidth(200);

        //  ERRORES
        Label errorAereo = new Label();
        Label errorModelo = new Label();
        Label errorCapacidad = new Label();
        


        errorAereo.setStyle("-fx-text-fill: red;");
        errorModelo.setStyle("-fx-text-fill: red;");
        errorCapacidad.setStyle("-fx-text-fill: red;");
   

        //  HBOX (lado a lado)
        HBox filaAereo = new HBox(10, aereolinea, errorAereo);
        HBox filaModelo = new HBox(10, modelo, errorModelo);
        HBox filaCapacidad = new HBox(10, capacidad, errorCapacidad);
        

        //  VALIDACIÓN EN TIEMPO REAL

        // AEROLÍNEA
        aereolinea.textProperty().addListener((obs, viejo, nuevo) -> {
            if (nuevo.trim().isEmpty()) {
                errorAereo.setText("Vacío");
                aereolinea.setStyle("-fx-border-color: red;");
            } else {
                errorAereo.setText("");
                aereolinea.setStyle("-fx-border-color: green;");
            }
        });

        // MODELO
        modelo.textProperty().addListener((obs, viejo, nuevo) -> {
            if (nuevo.trim().isEmpty()) {
                errorModelo.setText("Vacío");
                modelo.setStyle("-fx-border-color: red;");
            } else {
                errorModelo.setText("");
                modelo.setStyle("-fx-border-color: green;");
            }
        });

        // CAPACIDAD
        capacidad.textProperty().addListener((obs, viejo, nuevo) -> {
            if (nuevo.trim().isEmpty()) {
                errorCapacidad.setText("Vacío");
                capacidad.setStyle("-fx-border-color: red;");
                return;
            }

            try {
                Double.parseDouble(nuevo);
                errorCapacidad.setText("");
                capacidad.setStyle("-fx-border-color: green;");
            } catch (Exception e) {
                errorCapacidad.setText("Solo números");
                capacidad.setStyle("-fx-border-color: red;");
            }
        });

        //  BOTÓN
        Button boton = new Button("GUARDAR");

        //  LISTA
        ListView<metodo_16> vista = new ListView<>(lista);
        vista.setPrefHeight(200);
        
        //error guardar 
        Label errorGeneral = new Label();
        HBox zonaBoton = new HBox(10, boton, errorGeneral);
        zonaBoton.setAlignment(Pos.CENTER);
        errorGeneral.setStyle("-fx-text-fill: red;");


        // ACCIÓN DEL BOTÓN (VALIDACIÓN FINAL)
        boton.setOnAction(e -> {

            String aereo = aereolinea.getText();
            String model = modelo.getText();
            String capa = capacidad.getText();

            String estado = logica.val(aereo, model, capa);

            if (!estado.equals("OK")) {
                errorGeneral.setText("ERROR GUARDAR ");
                return ;
                
            }
            errorGeneral.setText("");

            double cap = Double.parseDouble(capa);
            metodo_16 avion = new metodo_16(aereo, model, cap);

            lista.add(avion);

            // limpiar
            aereolinea.clear();
            modelo.clear();
            capacidad.clear();
        });


        VBox layout = new VBox(15);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));

        Label titulo = new Label("GESTOR DE AVIONES");
        titulo.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");
        Separator linea = new Separator();
        layout.getChildren().addAll(
                titulo,
                filaAereo,
                filaModelo,
                filaCapacidad,
                zonaBoton,
                linea,
                vista
        );

        Scene scene = new Scene(layout, 400, 450);

        ventana.setTitle("Sistema Aeronáutico");
        ventana.setScene(scene);
        ventana.show();
    }
}