package com.mycompany.ejercicio_16;
import javafx.application.Application;
import static javafx.application.Application.launch;

public class main {

    public static void main(String[] args) {
        
   
        Application.launch(App.class,args);
    }
    }
    

