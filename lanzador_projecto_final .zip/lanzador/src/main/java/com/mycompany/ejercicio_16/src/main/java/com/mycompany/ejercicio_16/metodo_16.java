package com.mycompany.ejercicio_16;
public class metodo_16 {
    private String aereolinea; 
private String modelo;    
private double capacidad ;

    public metodo_16(String aereolinea, String modelo, double capacidad) {
        this.aereolinea = aereolinea;
        this.modelo = modelo;
        this.capacidad = capacidad;
    }

    public String getAereolinea() {
        return aereolinea;
    }

    public String getModelo() {
        return modelo;
    }

    public double getCapacidad() {
        return capacidad;
    }

    @Override
    public String toString() {
        return " |" + "aereolinea : " + aereolinea.toUpperCase()
                + "\n| modelo :" + modelo +
                " | capacidad :" + capacidad + 
                "KG  | categoria : "+ logica.categoria(capacidad)   ;
    }



}

