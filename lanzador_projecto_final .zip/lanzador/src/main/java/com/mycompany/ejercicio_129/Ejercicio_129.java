package com.mycompany.ejercicio_129;

public class Ejercicio_129 {

    public static void main(String[] args) {

        Pago p1 = new PagoEfectivo(100000);
        Pago p2 = new PagoTarjeta(100000);

        System.out.println(p1.MostrarInfo());
        System.out.println("Total a pagar: " + p1.calcularTotal());

        System.out.println("----------------");

        System.out.println(p2.MostrarInfo());
        System.out.println("Total a pagar: " + p2.calcularTotal());
    }
}