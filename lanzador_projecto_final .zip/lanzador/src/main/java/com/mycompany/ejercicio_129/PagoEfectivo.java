package com.mycompany.ejercicio_129;

public class PagoEfectivo extends Pago {

    public PagoEfectivo(double monto) {
        super(monto);
    }

    @Override
    public double calcularTotal() {
        double descuento = monto * 0.10;
        return monto - descuento;
    }
}