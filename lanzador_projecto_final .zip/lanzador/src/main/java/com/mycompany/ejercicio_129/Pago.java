package com.mycompany.ejercicio_129;

public abstract class Pago {

    protected double monto;

    public Pago(double monto) {
        this.monto = monto;
    }

    public abstract double calcularTotal();

    public String MostrarInfo() {
        return "Monto base: " + monto;
    }
}