package com.mycompany.ejercicio_129;

public class PagoTarjeta extends Pago {

    public PagoTarjeta(double monto) {
        super(monto);
    }

    @Override
    public double calcularTotal() {
        double recargo = monto * 0.05;
        return monto + recargo;
    }
}