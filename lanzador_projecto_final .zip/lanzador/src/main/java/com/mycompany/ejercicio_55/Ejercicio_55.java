package com.mycompany.ejercicio_55;

import java.util.Scanner;

public class Ejercicio_55 {
    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String respuesta = "si";

        do {
            try {
                System.out.println("===============");

                String cancion = texto("Ingrese la canción para escuchar");
                int volumen = numeros("Ingrese el volumen");

                metodo_55 mp3 = new metodo_55(cancion, volumen);

                System.out.println("Canción: " + cancion);
                System.out.println("Volumen inicial: " + volumen);

               
                int opcion = numeros("1. Subir volumen\n2. Bajar volumen");

                System.out.println(mp3.newvolumen(opcion));

                
                respuesta = texto("¿Desea continuar? (si/no)");

            } catch (Exception e) {
                System.out.println("El dato está mal.");
                entrada.nextLine();
            }

        } while (respuesta.equalsIgnoreCase("si"));
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }

    public static int numeros(String mensaje) {
        System.out.println(mensaje + ":");
        int numero = entrada.nextInt();
        entrada.nextLine();
        return numero;
    }
}