/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_55;

/**
 *
 * @author Nemesis
 */
public class metodo_55 {
    private String cancion ;
    private int volumen ;

    public metodo_55(String cancion, int volumen) {
        this.cancion = cancion;
        this.volumen = volumen;
    }
public String newvolumen(int opcion) {

    switch (opcion) {

        case 1:
            if (volumen < 100) {
                volumen++;
            }
            break;

        case 2:
            if (volumen > 0) {
                volumen--;
            }
            break;

        default:
            return "Opción no válida";
    }

    return "El volumen actual es: " + volumen;
}

    @Override
    public String toString() {
        return "metodo_55{" + "cancion=" + cancion + "| " + newvolumen(volumen) + '}';
    }
    
    
}
