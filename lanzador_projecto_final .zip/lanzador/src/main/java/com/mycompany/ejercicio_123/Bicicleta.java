package com.mycompany.ejercicio_123;

public class Bicicleta extends Vehiculo {

    @Override
    public String mover() {
        return "La bicicleta se mueve con pedales";
    }
}