package com.mycompany.ejercicio_123;

public class Carro extends Vehiculo {

    @Override
    public String mover() {
        return "El carro se mueve por la carretera";
    }
}