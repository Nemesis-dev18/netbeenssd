package com.mycompany.ejercicio_123;

public class Avion extends Vehiculo {

    @Override
    public String mover() {
        return "El avión vuela por el aire";
    }
}