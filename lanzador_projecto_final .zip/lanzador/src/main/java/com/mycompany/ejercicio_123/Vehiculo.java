package com.mycompany.ejercicio_123;

public class Vehiculo {

    public String mover() {
        return "El vehículo se mueve";
    }
}