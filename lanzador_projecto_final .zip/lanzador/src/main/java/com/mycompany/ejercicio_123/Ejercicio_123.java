package com.mycompany.ejercicio_123;

public class Ejercicio_123 {

    public static void main(String[] args) {

        Vehiculo v1 = new Carro();
        Vehiculo v2 = new Bicicleta();
        Vehiculo v3 = new Avion();

        System.out.println(v1.mover());
        System.out.println(v2.mover());
        System.out.println(v3.mover());
    }
}