
package com.mycompany.ejercicio_190;

public class Estadio {
    private String nombre;
    private String ciudad;
    private int capacidad;

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    @Override
    public String toString() {
        return "Estadio{" + "nombre=" + nombre + ", ciudad=" + ciudad + ", capacidad=" + capacidad + '}';
    }
}
