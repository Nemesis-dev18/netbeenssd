
package com.mycompany.ejercicio_190;

public class Ejercicio_190 {
    public static void main(String[] args) {
        Estadio e1 = new Estadio();
        e1.setCapacidad(50000);
        System.out.println(e1);
    }
}
