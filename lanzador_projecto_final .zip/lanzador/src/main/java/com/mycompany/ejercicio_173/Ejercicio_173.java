
package com.mycompany.ejercicio_173;

public class Ejercicio_173 {
    public static void main(String[] args) {
        Producto p = new Producto();
        p.setPrecio(50);
        p.setStock(10);
        p.vender(3);
        System.out.println(p.getStock());
    }
}
