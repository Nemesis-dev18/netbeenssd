
package com.mycompany.ejercicio_173;

public class Producto {
    private double precio;
    private int stock;

    public void setPrecio(double precio){
        if(precio > 0){
            this.precio = precio;
        }
    }

    public void vender(int cantidad){
        if(cantidad > 0 && cantidad <= stock){
            stock -= cantidad;
        }
    }

    public void setStock(int stock){
        if(stock >= 0){
            this.stock = stock;
        }
    }

    public int getStock(){
        return stock;
    }
}
