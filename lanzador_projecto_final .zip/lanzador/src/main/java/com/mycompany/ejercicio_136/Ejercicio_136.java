package com.mycompany.ejercicio_136;
public class Ejercicio_136{
 public static void main(String[] args){
  Vehiculo v=new Vehiculo();
  System.out.println(v.calcularConsumo(100));
  System.out.println(v.calcularConsumo(100,10));
 }
}