package com.mycompany.ejercicio_136;
public class Vehiculo{
 public double calcularConsumo(double km){ return km/10; }
 public double calcularConsumo(double distancia,double combustible){ return distancia/combustible; }
}