package com.mycompany.ejercicio_194;

public class metodo_194 {
    private String usuario;
    private String plan;

    public metodo_194(String usuario, String plan) {

        if (usuario == null || usuario.trim().isEmpty()) {
            this.usuario = "Sin usuario";
        } else {
            this.usuario = usuario;
        }

        if (plan == null || plan.trim().isEmpty()) {
            this.plan = "Básico";
        } else {
            this.plan = plan;
        }
    }

    public void setPlan(String plan) {
        if (plan != null && !plan.trim().isEmpty()) {
            this.plan = plan;
        } else {
            System.out.println("Plan inválido");
        }
    }

    public String getUsuario() {
        return usuario;
    }

    public String getPlan() {
        return plan;
    }

    public String MostrarInfo() {
        return "Suscripcion{" +
                "usuario=" + usuario +
                ", plan=" + plan +
                '}';
    }
}