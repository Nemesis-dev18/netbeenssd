package com.mycompany.ejercicio_194;

import java.util.Scanner;

public class Ejercicio_194 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String usuario = textoValido("Ingrese usuario");
        String plan = textoValido("Ingrese tipo de plan");

        metodo_194 s1 = new metodo_194(usuario, plan);

        System.out.println(s1.MostrarInfo());

        String nuevoPlan = textoValido("Ingrese nuevo plan");
        s1.setPlan(nuevoPlan);

        System.out.println("Datos actualizados:");
        System.out.println(s1.MostrarInfo());
    }

    public static String textoValido(String mensaje) {
        while (true) {
            System.out.println(mensaje + ":");
            String dato = entrada.nextLine();

            if (!dato.trim().isEmpty()) return dato;
            else System.out.println("No puede estar vacío");
        }
    }
}