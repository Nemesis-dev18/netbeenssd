
package com.mycompany.ejercicio_184;

public class Empleado {
    private double salario;

    public void setSalario(double salario){
        if(salario > 0) this.salario = salario;
    }

    public void aumentar(double porcentaje){
        if(porcentaje > 0){
            salario += salario * porcentaje;
        }
    }

    public void descontar(double monto){
        if(monto > 0 && monto <= salario){
            salario -= monto;
        }
    }

    public double getSalario(){ return salario; }
}
