
package com.mycompany.ejercicio_184;

public class Ejercicio_184 {
    public static void main(String[] args) {
        Empleado e = new Empleado();
        e.setSalario(2000);
        e.aumentar(0.1);
        e.descontar(200);
        System.out.println(e.getSalario());
    }
}
