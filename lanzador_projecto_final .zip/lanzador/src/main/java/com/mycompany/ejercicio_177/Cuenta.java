
package com.mycompany.ejercicio_177;

public class Cuenta {
    private double saldo;

    public void depositar(double monto){
        if(monto > 0) saldo += monto;
    }

    public boolean transferir(Cuenta destino, double monto){
        if(monto > 0 && monto <= saldo){
            saldo -= monto;
            destino.depositar(monto);
            return true;
        }
        return false;
    }

    public double getSaldo(){ return saldo; }
}
