
package com.mycompany.ejercicio_177;

public class Ejercicio_177 {
    public static void main(String[] args) {
        Cuenta c1 = new Cuenta();
        Cuenta c2 = new Cuenta();

        c1.depositar(500);
        c1.transferir(c2, 200);

        System.out.println(c1.getSaldo());
        System.out.println(c2.getSaldo());
    }
}
