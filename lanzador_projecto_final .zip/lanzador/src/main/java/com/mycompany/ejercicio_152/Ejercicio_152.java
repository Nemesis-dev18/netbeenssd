package com.mycompany.ejercicio_152;

import java.util.Scanner;

public class Ejercicio_152 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        metodo_152 r1 = new metodo_152();

        String nombre = texto("Ingrese nombre");

        int opcion = enteroPositivo("Seleccione tipo de registro:\n1. Básico\n2. Con correo\n3. Completo\n4. Con teléfono");

        switch (opcion) {

            case 1:
                System.out.println(r1.registrar(nombre));
                break;

            case 2:
                String correo = texto("Ingrese correo");
                System.out.println(r1.registrar(nombre, correo));
                break;

            case 3:
                String correo2 = texto("Ingrese correo");
                int edad = enteroPositivo("Ingrese edad");
                System.out.println(r1.registrar(nombre, correo2, edad));
                break;

            case 4:
                long telefono = telefonoValido("Ingrese teléfono");
                System.out.println(r1.registrar(nombre, telefono));
                break;

            default:
                System.out.println("Opción inválida");
        }
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }

    public static int enteroPositivo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                int num = entrada.nextInt();
                entrada.nextLine();

                if (num > 0) return num;
                else System.out.println("Debe ser mayor a 0");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }

    public static long telefonoValido(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                long num = entrada.nextLong();
                entrada.nextLine();

                if (num > 0 && String.valueOf(num).length() >= 7) return num;
                else System.out.println("Teléfono inválido");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }
}