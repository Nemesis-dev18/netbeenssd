package com.mycompany.ejercicio_152;

public class metodo_152 {

    // Registro básico
    public String registrar(String nombre) {
        return "Usuario registrado: " + nombre;
    }

    // Registro con correo
    public String registrar(String nombre, String correo) {
        return "Usuario: " + nombre + ", correo: " + correo;
    }

    // Registro completo
    public String registrar(String nombre, String correo, int edad) {
        return "Usuario: " + nombre + ", correo: " + correo + ", edad: " + edad;
    }

    // Registro con teléfono
    public String registrar(String nombre, long telefono) {
        return "Usuario: " + nombre + ", teléfono: " + telefono;
    }
}