package com.mycompany.ejercicio_69;

public class metodo_69 {
    private String paciente;
    private String medico;
    private String fecha;

    public metodo_69(String paciente, String medico, String fecha) {

        if (paciente == null || paciente.trim().isEmpty()) {
            this.paciente = "Sin paciente";
        } else {
            this.paciente = paciente;
        }

        if (medico == null || medico.trim().isEmpty()) {
            this.medico = "Sin médico";
        } else {
            this.medico = medico;
        }

        if (fecha == null || fecha.trim().isEmpty()) {
            this.fecha = "Sin fecha";
        } else {
            this.fecha = fecha;
        }
    }

    public String MostrarInfo() {
        return "CitaMedica{" +
                "paciente=" + paciente +
                ", medico=" + medico +
                ", fecha=" + fecha +
                '}';
    }
}