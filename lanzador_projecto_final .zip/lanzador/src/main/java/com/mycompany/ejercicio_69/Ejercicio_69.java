package com.mycompany.ejercicio_69;

import java.util.Scanner;

public class Ejercicio_69 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String paciente = texto("Ingrese nombre del paciente");
        String medico = texto("Ingrese nombre del médico");
        String fecha = texto("Ingrese la fecha");

        metodo_69 c1 = new metodo_69(paciente, medico, fecha);

        System.out.println(c1.MostrarInfo());
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }
}