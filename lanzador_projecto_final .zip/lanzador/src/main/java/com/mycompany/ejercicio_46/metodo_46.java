/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_46;

/**
 *
 * @author Nemesis
 */
public class metodo_46 {
    private String remitente ;
    private String destinatario  ;
    private String contenido   ;

    public metodo_46(String remitente, String destinatario, String contenido) {
        this.remitente = remitente;
        this.destinatario = destinatario;
        this.contenido = contenido;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("metodo_46{");
        sb.append("remitente=").append(remitente);
        sb.append(", destinatario=").append(destinatario);
        sb.append(", contenido=").append(contenido);
        sb.append('}');
        return sb.toString();
    }
    
    
    
}
