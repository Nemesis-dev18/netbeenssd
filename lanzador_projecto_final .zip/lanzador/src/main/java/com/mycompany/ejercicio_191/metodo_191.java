package com.mycompany.ejercicio_191;

public class metodo_191 {
    private String nombre;
    private String ciudad;
    private int pistas;

    public metodo_191(String nombre, String ciudad, int pistas) {

        if (nombre == null || nombre.trim().isEmpty()) {
            this.nombre = "Sin nombre";
        } else {
            this.nombre = nombre;
        }

        if (ciudad == null || ciudad.trim().isEmpty()) {
            this.ciudad = "Sin ciudad";
        } else {
            this.ciudad = ciudad;
        }

        if (pistas > 0) {
            this.pistas = pistas;
        } else {
            this.pistas = 1;
        }
    }

    // GETTERS
    public String getNombre() {
        return nombre;
    }

    public String getCiudad() {
        return ciudad;
    }

    public int getPistas() {
        return pistas;
    }

    // SETTERS
    public void setNombre(String nombre) {
        if (nombre != null && !nombre.trim().isEmpty()) {
            this.nombre = nombre;
        }
    }

    public void setCiudad(String ciudad) {
        if (ciudad != null && !ciudad.trim().isEmpty()) {
            this.ciudad = ciudad;
        }
    }

    public void setPistas(int pistas) {
        if (pistas > 0) {
            this.pistas = pistas;
        }
    }

    public String MostrarInfo() {
        return "Aeropuerto{" +
                "nombre=" + nombre +
                ", ciudad=" + ciudad +
                ", pistas=" + pistas +
                '}';
    }
}