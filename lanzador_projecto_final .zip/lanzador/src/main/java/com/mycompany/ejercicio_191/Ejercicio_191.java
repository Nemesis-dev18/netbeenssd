package com.mycompany.ejercicio_191;

import java.util.Scanner;

public class Ejercicio_191 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String nombre = texto("Ingrese nombre del aeropuerto");
        String ciudad = texto("Ingrese ciudad");
        int pistas = enteroPositivo("Ingrese número de pistas");

        metodo_191 a1 = new metodo_191(nombre, ciudad, pistas);

        System.out.println(a1.MostrarInfo());

        // Modificación usando setters
        String nuevaCiudad = texto("Ingrese nueva ciudad");
        a1.setCiudad(nuevaCiudad);

        System.out.println("Datos actualizados:");
        System.out.println(a1.MostrarInfo());
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }

    public static int enteroPositivo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                int num = entrada.nextInt();
                entrada.nextLine();

                if (num > 0) return num;
                else System.out.println("Debe ser mayor a 0");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }
}