
package com.mycompany.ejercicio_183;

public class Ejercicio_183 {
    public static void main(String[] args) {
        Producto p = new Producto();
        p.setStock(5);
        p.vender(2);
        p.reponer(3);
        System.out.println(p.getStock());
    }
}
