
package com.mycompany.ejercicio_90;

public class Ejercicio_90 {
    public static void main(String[] args){
        Programador p = new Programador("Juan");
        Diseñador d = new Diseñador("Ana");

        p.MostrarInfo();
        p.programar();

        d.MostrarInfo();
        d.diseñar();
    }
}
