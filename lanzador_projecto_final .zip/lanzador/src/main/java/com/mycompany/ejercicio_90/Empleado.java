
package com.mycompany.ejercicio_90;

public class Empleado {
    protected String nombre;

    public Empleado(String nombre){
        this.nombre = nombre;
    }

    public void MostrarInfo(){
        System.out.println("Nombre: " + nombre);
    }
}
