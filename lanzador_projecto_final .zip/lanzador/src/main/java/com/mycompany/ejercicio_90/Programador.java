
package com.mycompany.ejercicio_90;

public class Programador extends Empleado{

    public Programador(String nombre){
        super(nombre);
    }

    public void programar(){
        System.out.println("Programando...");
    }
}
