
package com.mycompany.ejercicio_90;

public class Diseñador extends Empleado{

    public Diseñador(String nombre){
        super(nombre);
    }

    public void diseñar(){
        System.out.println("Diseñando...");
    }
}
