package com.mycompany.ejercicio_49;
public class metodo_49 {
    private String placa ;
    private double tarifa_base =159 ;
    private int cantidad_metros;

    public metodo_49(String placa, int cantidad_metros) {
        this.placa = placa;
        this.cantidad_metros = cantidad_metros;
    }
    
    public double tarifa_total (int cantidad_metros){
        return cantidad_metros * tarifa_base ;
    }

    @Override
    public String toString() {
        return "metodo_49{" + "placa=" + placa + ", tarifa_base=" + tarifa_base + ", cantidad_metros=" + cantidad_metros + "valor total =" +tarifa_total(cantidad_metros)+ '}';
    }
    
    
}
