package com.mycompany.ejercicio_13;

public class metodo_13 {
    private String nombre;
    private double valor;

    public metodo_13(String nombre, double valor) {
        this.nombre = nombre;
        this.valor = valor;
    }

    public String MostrarInfo() {
        return "Nombre: " + nombre + ", Valor: " + valor;
    }
}
