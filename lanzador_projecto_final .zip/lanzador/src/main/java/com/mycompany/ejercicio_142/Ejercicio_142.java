package com.mycompany.ejercicio_142;
public class Ejercicio_142{
 public static void main(String[] args){
  Empleado e=new Empleado();
  System.out.println(e.calcularSalario(1000));
  System.out.println(e.calcularSalario(1000,200));
 }
}