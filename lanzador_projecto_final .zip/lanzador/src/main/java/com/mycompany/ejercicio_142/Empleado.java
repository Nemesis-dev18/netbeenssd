package com.mycompany.ejercicio_142;
public class Empleado{
 public double calcularSalario(double base){
  return base;
 }
 public double calcularSalario(double base,double bono){
  return base+bono;
 }
}