
package com.mycompany.ejercicio_167;

public class Ejercicio_167 {
    public static void main(String[] args) {
        Cuenta c = new Cuenta();
        c.depositar(500);
        c.retirar(200);
        System.out.println(c.getSaldo());
    }
}
