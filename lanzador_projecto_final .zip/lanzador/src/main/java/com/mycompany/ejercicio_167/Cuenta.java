
package com.mycompany.ejercicio_167;

public class Cuenta {
    private double saldo;

    public void depositar(double monto){
        if(monto > 0) saldo += monto;
    }

    public void retirar(double monto){
        if(monto > 0 && monto <= saldo) saldo -= monto;
    }

    public double getSaldo(){
        return saldo;
    }
}
