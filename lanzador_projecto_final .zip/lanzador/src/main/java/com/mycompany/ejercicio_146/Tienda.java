package com.mycompany.ejercicio_146;
public class Tienda{
 public double precioFinal(double precio){
  return precio*0.9;
 }
 public double precioFinal(double precio,double impuesto){
  return precio+(precio*impuesto);
 }
}