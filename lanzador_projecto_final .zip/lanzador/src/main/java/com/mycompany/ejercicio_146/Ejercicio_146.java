package com.mycompany.ejercicio_146;
public class Ejercicio_146{
 public static void main(String[] args){
  Tienda t=new Tienda();
  System.out.println(t.precioFinal(100));
  System.out.println(t.precioFinal(100,0.19));
 }
}