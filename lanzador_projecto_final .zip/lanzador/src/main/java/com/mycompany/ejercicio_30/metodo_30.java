package com.mycompany.ejercicio_30;
public class metodo_30 {
    private String marca;
    private double tamaño_pantalla;
    private double cap_bateria;

    public metodo_30(String marca, double tamaño_pantalla, double cap_bateria) {
        this.marca = marca;
        this.tamaño_pantalla = tamaño_pantalla;
        this.cap_bateria = cap_bateria;
    }

    public String getMarca() {
        return marca;
    }

    public double getTamaño_pantalla() {
        return tamaño_pantalla;
    }

    public double getCap_bateria() {
        return cap_bateria;
    }

    @Override
    public String toString() {
        return "metodo_30{" + "marca=" + marca + ", tam_pantalla=" + tamaño_pantalla + ", cap_bateria=" + cap_bateria + '}';
    }

    
    
    
}
