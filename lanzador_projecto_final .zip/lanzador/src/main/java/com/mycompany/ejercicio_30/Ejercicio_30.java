package com.mycompany.ejercicio_30;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio_30 {
    static Scanner entrada = new Scanner(System.in);
    static ArrayList<metodo_30> lista = new ArrayList<>();
    
    public static void main(String[] args) {
        
        String respuesta = "si";
        
        do {
            try {
                System.out.println("===============");
                
                String marca = texto("ingrese la marca del pc ");
                double pantalla = numeros("ingrese el tamaño de la pantalla");
                double capacidad = numeros("ingrese la capacidad de la bateria ");
                
                metodo_30 info = new metodo_30(marca, pantalla, capacidad);
                lista.add(info);
                
                do {
                    respuesta = texto("¿Desea agregar otro? (si/no)");
                } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
                
            } catch (Exception e) {
                System.out.println("El dato está mal.");
                entrada.nextLine();                
            }
            
        } while (respuesta.equalsIgnoreCase("si"));
        for (metodo_30 string : lista) {
            System.out.println(string);
            
        }
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }
    
    public static double numeros(String mensaje) {
        System.out.println(mensaje + " :");
        double numero = entrada.nextDouble();
        entrada.nextLine();
        return numero;
    }
}
