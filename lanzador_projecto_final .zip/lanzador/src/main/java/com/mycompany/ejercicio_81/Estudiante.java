
package com.mycompany.ejercicio_81;

public class Estudiante extends Persona {

    private String carrera;
    private int semestre;

    public Estudiante(String nombre, int edad, String carrera, int semestre) {
        super(nombre, edad);
        this.carrera = carrera;
        this.semestre = semestre;
    }

    @Override
    public void MostrarInfo() {
        super.MostrarInfo();
        System.out.println("Carrera: " + carrera + ", Semestre: " + semestre);
    }
}
