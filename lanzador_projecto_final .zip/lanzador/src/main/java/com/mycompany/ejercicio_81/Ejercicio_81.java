
package com.mycompany.ejercicio_81;

import java.util.Scanner;

public class Ejercicio_81 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String nombre = texto("Ingrese nombre");
        int edad = entero("Ingrese edad");
        String carrera = texto("Ingrese carrera");
        int semestre = entero("Ingrese semestre");

        Estudiante e1 = new Estudiante(nombre, edad, carrera, semestre);
        e1.MostrarInfo();
    }

    public static String texto(String m) {
        System.out.println(m + ":");
        return entrada.nextLine();
    }

    public static int entero(String m) {
        while (true) {
            try {
                System.out.println(m + ":");
                int n = entrada.nextInt();
                entrada.nextLine();
                return n;
            } catch (Exception e) {
                entrada.nextLine();
            }
        }
    }
}
