
package com.mycompany.ejercicio_81;

public class Persona {
    protected String nombre;
    protected int edad;

    public Persona(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    public void MostrarInfo() {
        System.out.println("Nombre: " + nombre + ", Edad: " + edad);
    }
}
