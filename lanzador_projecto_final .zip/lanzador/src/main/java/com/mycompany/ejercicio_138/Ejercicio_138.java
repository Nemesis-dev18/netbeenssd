package com.mycompany.ejercicio_138;
public class Ejercicio_138{
 public static void main(String[] args){
  Impresora i=new Impresora();
  System.out.println(i.imprimir("hola"));
  System.out.println(i.imprimir(1));
  System.out.println(i.imprimir(1.5));
 }
}