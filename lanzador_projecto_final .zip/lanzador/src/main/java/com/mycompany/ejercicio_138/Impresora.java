package com.mycompany.ejercicio_138;
public class Impresora{
 public String imprimir(String texto){ return "Imprimiendo texto"; }
 public String imprimir(int img){ return "Imprimiendo imagen"; }
 public String imprimir(double doc){ return "Imprimiendo documento"; }
}