/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_45;

/**
 *
 * @author Nemesis
 */
public class metodo_45 {
    private int numero_contacto;

    public metodo_45(int numero_contacto) {
        this.numero_contacto = numero_contacto;
    }


    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("-----------------");
        sb.append("numero de contacto =").append(numero_contacto);
        sb.append("----------------");
        return sb.toString();
    }
    

    
}
