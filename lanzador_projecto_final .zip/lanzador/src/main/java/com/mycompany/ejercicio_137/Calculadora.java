package com.mycompany.ejercicio_137;
public class Calculadora{
 public int sumar(int a,int b){ return a+b; }
 public int sumar(int a,int b,int c){ return a+b+c; }
 public int sumar(int[] nums){
  int s=0;
  for(int n:nums) s+=n;
  return s;
 }
}