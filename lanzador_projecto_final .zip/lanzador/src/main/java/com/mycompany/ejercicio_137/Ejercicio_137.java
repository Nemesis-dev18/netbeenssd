package com.mycompany.ejercicio_137;
public class Ejercicio_137{
 public static void main(String[] args){
  Calculadora c=new Calculadora();
  System.out.println(c.sumar(2,3));
  System.out.println(c.sumar(1,2,3));
  System.out.println(c.sumar(new int[]{1,2,3,4}));
 }
}