package com.mycompany.ejercicio_70;

public class metodo_70 {
    private int numeroFactura;
    private String cliente;
    private double valorCompra;

    public metodo_70(int numeroFactura, String cliente, double valorCompra) {

        if (numeroFactura > 0) {
            this.numeroFactura = numeroFactura;
        } else {
            this.numeroFactura = 1;
        }

        if (cliente == null || cliente.trim().isEmpty()) {
            this.cliente = "Sin nombre";
        } else {
            this.cliente = cliente;
        }

        if (valorCompra > 0) {
            this.valorCompra = valorCompra;
        } else {
            this.valorCompra = 0;
        }
    }

    public double calcularTotal() {
        double impuesto = valorCompra * 0.19; // 19%
        return valorCompra + impuesto;
    }

    public String MostrarInfo() {
        return "FacturaVenta{" +
                "numero=" + numeroFactura +
                ", cliente=" + cliente +
                ", valorCompra=" + valorCompra +
                ", totalConImpuesto=" + calcularTotal() +
                '}';
    }
}