package com.mycompany.ejercicio_70;

import java.util.Scanner;

public class Ejercicio_70 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        int numero = enteroPositivo("Ingrese número de factura");
        String cliente = texto("Ingrese nombre del cliente");
        double valor = decimalNoNegativo("Ingrese valor de la compra");

        metodo_70 f1 = new metodo_70(numero, cliente, valor);

        System.out.println(f1.MostrarInfo());
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }

    public static int enteroPositivo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                int num = entrada.nextInt();
                entrada.nextLine();

                if (num > 0) return num;
                else System.out.println("Debe ser mayor a 0");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }

    public static double decimalNoNegativo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                double num = entrada.nextDouble();
                entrada.nextLine();

                if (num >= 0) return num;
                else System.out.println("No puede ser negativo");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }
}