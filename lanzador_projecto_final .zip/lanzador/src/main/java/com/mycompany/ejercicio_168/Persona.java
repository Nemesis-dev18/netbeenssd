
package com.mycompany.ejercicio_168;

public class Persona {
    private String nombre;

    public void setNombre(String nombre){
        if(nombre != null && !nombre.isEmpty()){
            this.nombre = nombre;
        }
    }

    public String getNombre(){
        return nombre;
    }
}
