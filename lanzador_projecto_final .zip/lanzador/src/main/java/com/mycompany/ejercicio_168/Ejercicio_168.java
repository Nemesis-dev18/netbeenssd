
package com.mycompany.ejercicio_168;

public class Ejercicio_168 {
    public static void main(String[] args) {
        Persona p = new Persona();
        p.setNombre("Carlos");
        System.out.println(p.getNombre());
    }
}
