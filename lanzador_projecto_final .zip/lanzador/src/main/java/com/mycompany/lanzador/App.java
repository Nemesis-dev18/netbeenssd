package com.mycompany.lanzador;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class App extends Application {

    private boolean ejecutando = false;
    private int exitos = 0;
    private int errores = 0;

    @Override
    public void start(Stage origen) {

        TextField ingresar = new TextField();
        ingresar.setPromptText("Ingrese número de ejercicio (1 - 200 )");

        Button boton = new Button("Ejecutar");

        TextArea output = new TextArea();
        output.setEditable(false);
        output.setWrapText(true);

        Label contadorLabel = new Label("Exitos: 0 | Errores: 0");

        boton.setOnAction(e -> {

            if (ejecutando) {
                errores++;
                contadorLabel.setText("Exitos: " + exitos + " | Errores: " + errores);
                output.setText("Ya hay un ejercicio en ejecución...");
                return;
            }

            String texto = ingresar.getText().trim();

            if (!texto.matches("\\d+")) {
                errores++;
                contadorLabel.setText("Exitos: " + exitos + " | Errores: " + errores);
                output.setText("Tiene que ingresar solo números.");
                return;
            }

            int numero = Integer.parseInt(texto);

            ejecutando = true;

            boton.setDisable(true);
            ingresar.setDisable(true);

            output.setText("Ejecutando ejercicio " + numero + "...");

            new Thread(() -> {

                boolean resultado = ejecutarEjercicio(numero, output);

                Platform.runLater(() -> {

                    if (resultado) {
                        exitos++;
                    } else {
                        errores++;
                    }

                    contadorLabel.setText("Exitos: " + exitos + " | Errores: " + errores);

                    ejecutando = false;
                    boton.setDisable(false);
                    ingresar.setDisable(false);
                });

            }).start();
        });

        VBox ventana = new VBox(15, ingresar, boton, contadorLabel, output);
        ventana.setAlignment(Pos.CENTER);

        ventana.setStyle(
                "-fx-background-color: linear-gradient(to bottom, #1e1e2f, #2c2c54);"
                + "-fx-padding: 14;"
        );

        ingresar.setStyle(
                "-fx-background-radius: 7;"
                + "-fx-padding: 7;"
                + "-fx-font-size: 14px;"
        );

        boton.setStyle(
                "-fx-background-color: #6c5ce7;"
                + "-fx-text-fill: white;"
                + "-fx-font-size: 14px;"
                + "-fx-background-radius: 7;"
        );

        contadorLabel.setStyle(
                "-fx-text-fill: white;"
                + "-fx-font-size: 13px;"
        );

        output.setStyle(
                "-fx-background-radius: 8;"
                + "-fx-font-size: 13px;"
        );

        Scene pantalla = new Scene(ventana, 320, 250);

        origen.setTitle("Ejecutor de Ejercicios");
        origen.setScene(pantalla);
        origen.show();
    }

    private boolean ejecutarEjercicio(int numero, TextArea output) {

        String clase = "com.mycompany.ejercicio_" + numero + ".Ejercicio_" + numero;

        try {

            System.out.println("Cargando: " + clase);

            Class<?> clase_ejecutar = Class.forName(clase);

            clase_ejecutar
                    .getMethod("main", String[].class)
                    .invoke(null, (Object) new String[]{});

            actualizarUI(output, "Ejercicio " + numero + " ejecutado correctamente.");
            return true;

        } catch (ClassNotFoundException e) {
            actualizarUI(output, "No existe el ejercicio.");
        } catch (NoSuchMethodException e) {
            actualizarUI(output, "No tiene método main.");
        } catch (Exception e) {
            actualizarUI(output, "Error al ejecutar.");
            e.printStackTrace();
        }

        return false;
    }

    private void actualizarUI(TextArea output, String mensaje) {
        Platform.runLater(() -> {
            output.setText(mensaje);
        });
    }

    public static void main(String[] args) {
        launch();
    }
}