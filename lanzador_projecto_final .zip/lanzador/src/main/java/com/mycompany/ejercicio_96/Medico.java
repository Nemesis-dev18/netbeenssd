
package com.mycompany.ejercicio_96;

public class Medico extends Trabajador{

    private String especialidad;

    public Medico(String nombre, String especialidad){
        super(nombre);
        this.especialidad = especialidad;
    }

    @Override
    public void MostrarInfo(){
        super.MostrarInfo();
        System.out.println("Especialidad: " + especialidad);
    }
}
