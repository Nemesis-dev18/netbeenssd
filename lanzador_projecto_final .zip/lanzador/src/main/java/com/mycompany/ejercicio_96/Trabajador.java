
package com.mycompany.ejercicio_96;

public class Trabajador {
    protected String nombre;

    public Trabajador(String nombre){
        this.nombre = nombre;
    }

    public void MostrarInfo(){
        System.out.println("Nombre: " + nombre);
    }
}
