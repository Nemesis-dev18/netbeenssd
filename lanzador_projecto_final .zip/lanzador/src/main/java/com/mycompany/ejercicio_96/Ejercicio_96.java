
package com.mycompany.ejercicio_96;

public class Ejercicio_96 {
    public static void main(String[] args){
        Medico m = new Medico("Carlos", "Cirugia");
        Enfermero e = new Enfermero("Ana", "Noche");

        m.MostrarInfo();
        e.MostrarInfo();
    }
}
