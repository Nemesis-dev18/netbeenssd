
package com.mycompany.ejercicio_96;

public class Enfermero extends Trabajador{

    private String turno;

    public Enfermero(String nombre, String turno){
        super(nombre);
        this.turno = turno;
    }

    @Override
    public void MostrarInfo(){
        super.MostrarInfo();
        System.out.println("Turno: " + turno);
    }
}
