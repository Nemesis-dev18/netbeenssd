
package com.mycompany.ejercicio_75;

import java.util.Scanner;

public class Ejercicio_75 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String nombre = texto("Ingrese el nombre del curso");
        String nivel = texto("Ingrese el nivel");
        int estudiantes = entero("Ingrese numero de estudiantes");

        metodo_75 obj = new metodo_75(nombre, nivel, estudiantes);

        obj.MostrarInfo();
        System.out.println("Total estudiantes: " + obj.totalEstudiantes());
    }

    public static String texto(String m) {
        System.out.println(m + ":");
        return entrada.nextLine();
    }

    public static int entero(String m) {
        while (true) {
            try {
                System.out.println(m + ":");
                int n = entrada.nextInt();
                entrada.nextLine();
                return n;
            } catch (Exception e) {
                entrada.nextLine();
            }
        }
    }
}
