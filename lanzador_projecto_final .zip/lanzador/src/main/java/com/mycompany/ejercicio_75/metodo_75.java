
package com.mycompany.ejercicio_75;

public class metodo_75 {

    private String nombre;
    private String nivel;
    private int estudiantes;

    public metodo_75(String nombre, String nivel, int estudiantes) {
        this.nombre = nombre;
        this.nivel = nivel;
        this.estudiantes = estudiantes;
    }

    public void MostrarInfo() {
        System.out.println("Curso: " + nombre +
                ", Nivel: " + nivel +
                ", Estudiantes: " + estudiantes);
    }

    public int totalEstudiantes() {
        return estudiantes;
    }
}
