package com.mycompany.ejercicio_61;

public class metodo_61 {
    private String nombre;
    private int libros;

    public metodo_61(String nombre, int libros) {

        if (nombre == null || nombre.trim().isEmpty()) {
            this.nombre = "Sin nombre";
        } else {
            this.nombre = nombre;
        }

        if (libros >= 0) {
            this.libros = libros;
        } else {
            this.libros = 0;
        }
    }

    public void agregarLibros(int cantidad) {
        if (cantidad > 0) {
            libros += cantidad;
        } else {
            System.out.println("Cantidad inválida");
        }
    }

    public String MostrarInfo() {
        return "BibliotecaEscolar{" +
                "nombre=" + nombre +
                ", total_libros=" + libros +
                '}';
    }
}
