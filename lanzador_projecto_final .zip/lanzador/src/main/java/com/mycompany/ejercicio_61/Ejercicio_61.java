package com.mycompany.ejercicio_61;

import java.util.Scanner;

public class Ejercicio_61 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String nombre = texto("Ingrese el nombre de la biblioteca");
        int libros = enteroNoNegativo("Ingrese cantidad inicial de libros");

        metodo_61 b1 = new metodo_61(nombre, libros);

        int nuevos = enteroPositivo("Ingrese cantidad de libros a agregar");
        b1.agregarLibros(nuevos);

        System.out.println(b1.MostrarInfo());
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }

    public static int enteroPositivo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                int num = entrada.nextInt();
                entrada.nextLine();

                if (num > 0) return num;
                else System.out.println("Debe ser mayor a 0");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }

    public static int enteroNoNegativo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                int num = entrada.nextInt();
                entrada.nextLine();

                if (num >= 0) return num;
                else System.out.println("No puede ser negativo");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }
}