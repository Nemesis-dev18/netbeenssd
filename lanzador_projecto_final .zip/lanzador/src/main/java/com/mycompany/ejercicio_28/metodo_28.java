package com.mycompany.ejercicio_28;

public class metodo_28 {

    private String titular;
    private long num_cuenta;
    private double saldo;

    public metodo_28(String titular, long num_cuenta, double saldo) {
        this.titular = titular;
        this.num_cuenta = num_cuenta;
        this.saldo = saldo;
    }

    public String getTitular() {
        return titular;
    }

    public long getNum_cuenta() {
        return num_cuenta;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public String opciones(int opcion, double valor) {

        switch (opcion) {

            case 1:
                retirar(valor);
                return "Retiro realizado. Saldo actual: " + saldo;

            case 2:
                agregar(valor);
                return "Depósito realizado. Saldo actual: " + saldo;

            case 3:
                return "Saldo actual: " + saldo;

            default:
                return "Opción inválida";
        }
    }

    public double retirar(double valor) {

        if (valor <= 0) {
            System.out.println("Valor inválido");
            return saldo;
        }

        if (valor > saldo) {
            System.out.println("Saldo insuficiente");
            return saldo;
        }

        saldo -= valor;
        return saldo;
    }

    public double agregar(double valor) {

        if (valor <= 0) {
            System.out.println("Valor inválido");
            return saldo;
        }

        saldo += valor;
        return saldo;
    }

    @Override
    public String toString() {
        return "Titular: " + titular +
               ", Cuenta: " + num_cuenta +
               ", Saldo: " + saldo;
    }
}