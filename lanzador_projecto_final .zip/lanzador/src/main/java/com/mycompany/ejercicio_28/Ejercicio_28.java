package com.mycompany.ejercicio_28;

import java.util.Scanner;

public class Ejercicio_28 {

    static Scanner entrada = new Scanner(System.in);
    
    public static void main(String[] args) {
        try {
             System.out.println("===============");

    String titular = texto("Ingrese el nombre del titular");

    System.out.println("Ingrese el numero de cuenta:");
    long num_cuenta = entrada.nextLong();

    System.out.println("Ingrese el saldo inicial:");
    double saldo = entrada.nextDouble();
    entrada.nextLine();

    metodo_28 cuenta = new metodo_28(titular, num_cuenta, saldo);
    
      String respuesta;

    do {
        int opcion = numeros("--------------- MENU 1. Retirar 2. Agregar 3. Mostrar saldo ");

        double valor = 0;

        if (opcion == 1 || opcion == 2) {
            System.out.println("Ingrese valor:");
            valor = entrada.nextDouble();
            entrada.nextLine();
             String resultado = cuenta.opciones(opcion, valor);
             System.out.println(resultado);
        }
        if (opcion == 3) {
            String datos = cuenta.opciones(opcion, 0);
            System.out.println(datos);         
        }
        respuesta = texto("¿Desea hacer otra operación? (si/no)");

    } while (respuesta.equalsIgnoreCase("si"));
    
        } catch (Exception e) {
            System.out.println("los datos estan mal ");
        }
}
    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();}
    public static int numeros(String mensaje) {
        System.out.println(mensaje + " :");
        int numero = entrada.nextInt();
        entrada.nextLine();
        return numero;
    }
}
