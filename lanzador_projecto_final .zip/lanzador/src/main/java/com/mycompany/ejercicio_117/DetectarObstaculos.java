package com.mycompany.ejercicio_117;

public interface DetectarObstaculos {
    public String detectar();
}