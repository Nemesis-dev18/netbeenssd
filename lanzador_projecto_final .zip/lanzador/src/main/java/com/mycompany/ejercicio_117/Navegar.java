package com.mycompany.ejercicio_117;

public interface Navegar {
    public String navegar();
}