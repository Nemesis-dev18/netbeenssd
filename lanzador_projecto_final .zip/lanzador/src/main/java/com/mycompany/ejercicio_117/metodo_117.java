package com.mycompany.ejercicio_117;

public class metodo_117 implements Navegar, DetectarObstaculos {

    private String modelo;

    public metodo_117(String modelo) {

        if (modelo == null || modelo.trim().isEmpty()) {
            this.modelo = "Vehículo";
        } else {
            this.modelo = modelo;
        }
    }

    @Override
    public String navegar() {
        return modelo + " está navegando hacia su destino...";
    }

    @Override
    public String detectar() {
        return modelo + " detecta un obstáculo y lo evita.";
    }

    public String MostrarInfo() {
        return "VehiculoAutonomo{" +
                "modelo=" + modelo +
                '}';
    }
}