package com.mycompany.ejercicio_117;

import java.util.Scanner;

public class Ejercicio_117 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String modelo = textoValido("Ingrese modelo del vehículo");

        metodo_117 v1 = new metodo_117(modelo);

        System.out.println(v1.MostrarInfo());
        System.out.println(v1.navegar());
        System.out.println(v1.detectar());
    }

    public static String textoValido(String mensaje) {
        while (true) {
            System.out.println(mensaje + ":");
            String dato = entrada.nextLine();

            if (!dato.trim().isEmpty()) return dato;
            else System.out.println("No puede estar vacío");
        }
    }
}