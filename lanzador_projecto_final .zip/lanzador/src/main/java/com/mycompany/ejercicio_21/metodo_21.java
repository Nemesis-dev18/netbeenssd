
package com.mycompany.ejercicio_21;

public class metodo_21 {
    private String nobre_b;
    private String nombre_ciudad;

    public metodo_21(String nobre_b, String nombre_ciudad) {
        this.nobre_b = nobre_b;
        this.nombre_ciudad = nombre_ciudad;
    }

    public String getNobre_b() {
        return nobre_b;
    }

    public String getNombre_ciudad() {
        return nombre_ciudad;
    }

    @Override
    public String toString() {
        return "metodo_21{" + "nobre_b=" + nobre_b + ", nombre_ciudad=" + nombre_ciudad + '}';
    }
    
    
    
}
