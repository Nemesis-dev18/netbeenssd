package com.mycompany.ejercicio_21;
import java.util.ArrayList;
import java.util.Scanner;
public class Ejercicio_21 {
static Scanner entrada = new Scanner(System.in);
static ArrayList<metodo_21> banco = new ArrayList<>();
    public static void main(String[] args) {
        String respuesta ;
        do {            
            System.out.println("-----------------");
            String nombre_b =texto("ingrese el nombre del banco ");
            String nombre_c =texto("ingrese el nombre del banco ");
            metodo_21 info = new metodo_21(nombre_b, nombre_c);
            banco.add(info);
            do {
                respuesta = texto("¿Desea agregar otro ? (si/no)");
            } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
        } while (respuesta.equalsIgnoreCase("si"));
        for (metodo_21 st : banco) {
            System.out.println(st);  
        }
    }
    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();}
    
}
