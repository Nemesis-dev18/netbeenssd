package com.mycompany.ejercicio_19;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio_19 {
static ArrayList<metodo_19> profesor = new ArrayList<>();
static Scanner entrada = new Scanner(System.in);
    public static void main(String[] args) {
       String respuesta ;
        
        do {            
            System.out.println("==============");
        String nombre =texto("ingrese su nombre");
        String materia =texto("ingrese materia");
        int años_xp =numeros("ingrese años de exp");
        metodo_19 info = new metodo_19(nombre,materia,años_xp);
      profesor.add(info);
            do {
                respuesta = texto("¿Desea agregar otro ? (si/no)");
            } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));  
        } while (respuesta.equalsIgnoreCase("si"));
        for (metodo_19 arg : profesor ) {
            System.out.println(arg);
        }
    }
    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }
    public static int numeros(String mensaje) {
        System.out.println(mensaje + " :");
        int numero = entrada.nextInt();
        entrada.nextLine();
        return numero;
    }
}
