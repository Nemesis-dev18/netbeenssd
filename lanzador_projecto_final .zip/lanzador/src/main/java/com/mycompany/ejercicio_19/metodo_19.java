package com.mycompany.ejercicio_19;
public class metodo_19 {
    private String nombre;
    private String materia;
    private int años_xp;

    public metodo_19(String nombre, String materia, int años_xp) {
        this.nombre = nombre;
        this.materia = materia;
        this.años_xp = años_xp;
    }

    public String getNombre() {
        return nombre;
    }

    public String getMateria() {
        return materia;
    }

    public int getAños_xp() {
        return años_xp;
    }

    @Override
    public String toString() {
        return "PROFESOR |" + "nombre :" + nombre + "| materia :" + materia + "| años_xp:" + años_xp + " | ";
    }
    
    
    
}
