package com.mycompany.ejercicio_131;

public class CuentaAhorros extends CuentaBancaria {

    public CuentaAhorros(double saldo) {
        super(saldo);
    }

    @Override
    public double calcularInteres() {
        return saldo * 0.03; // 3%
    }
}