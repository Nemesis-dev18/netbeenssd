package com.mycompany.ejercicio_131;
public class Ejercicio_131{
 public static void main(String[] args){
  Empleado e1=new Gerente();
  Empleado e2=new Programador();
  System.out.println(e1.mostrarInformacion());
  System.out.println(e2.mostrarInformacion());
 }
}