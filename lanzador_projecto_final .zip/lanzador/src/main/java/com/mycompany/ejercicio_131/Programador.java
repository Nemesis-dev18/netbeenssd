package com.mycompany.ejercicio_131;
public class Programador extends Empleado{
 @Override public String mostrarInformacion(){ return "Programador desarrolla"; }
}