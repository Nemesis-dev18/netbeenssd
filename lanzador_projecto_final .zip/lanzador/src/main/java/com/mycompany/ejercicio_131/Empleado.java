package com.mycompany.ejercicio_131;
public class Empleado {
 public String mostrarInformacion(){ return "Empleado general"; }
}