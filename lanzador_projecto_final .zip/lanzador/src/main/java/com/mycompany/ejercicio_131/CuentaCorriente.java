package com.mycompany.ejercicio_131;

public class CuentaCorriente extends CuentaBancaria {

    public CuentaCorriente(double saldo) {
        super(saldo);
    }

    @Override
    public double calcularInteres() {
        return saldo * 0.01; // 1%
    }
}