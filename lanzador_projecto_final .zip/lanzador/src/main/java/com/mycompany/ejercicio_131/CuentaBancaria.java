package com.mycompany.ejercicio_131;

public abstract class CuentaBancaria {

    protected double saldo;

    public CuentaBancaria(double saldo) {
        this.saldo = saldo;
    }

    public abstract double calcularInteres();

    public String MostrarInfo() {
        return "Saldo: " + saldo;
    }
}