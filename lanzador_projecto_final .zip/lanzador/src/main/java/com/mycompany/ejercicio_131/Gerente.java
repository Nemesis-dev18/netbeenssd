package com.mycompany.ejercicio_131;
public class Gerente extends Empleado{
 @Override public String mostrarInformacion(){ return "Gerente administra"; }
}