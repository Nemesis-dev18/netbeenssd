package com.mycompany.ejercicio_151;

import java.util.Scanner;

public class Ejercicio_151 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        double valor = decimalPositivo("Ingrese valor en USD");
        String moneda = texto("Ingrese moneda destino (COP/EUR/MXN)");

        metodo_151 c1 = new metodo_151();

        double resultado = c1.convertir(valor, moneda, true);

        System.out.println("Resultado: " + resultado);
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }

    public static double decimalPositivo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                double num = entrada.nextDouble();
                entrada.nextLine();

                if (num > 0) return num;
                else System.out.println("Debe ser mayor a 0");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }
}