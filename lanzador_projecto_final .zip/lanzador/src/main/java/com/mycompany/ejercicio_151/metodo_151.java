package com.mycompany.ejercicio_151;

public class metodo_151 {

    // USD a COP
    public double convertir(double valor) {
        return valor * 4000; // tasa aproximada
    }

    // USD a EUR
    public double convertir(double valor, String moneda) {

        if (moneda.equalsIgnoreCase("EUR")) {
            return valor * 0.92;
        }

        return valor;
    }

    // USD a otra moneda (más completo)
public double convertir(double valor, String moneda, boolean mostrar) {

    double resultado;

    switch (moneda.toUpperCase()) {

        case "COP":
            resultado = valor * 4000;
            break;

        case "EUR":
            resultado = valor * 0.92;
            break;

        case "MXN":
            resultado = valor * 17;
            break;

        default:
            resultado = valor;
            break;
    }

    if (mostrar) {
        System.out.println("Resultado: " + resultado + " " + moneda);
    }

    return resultado;
}}