/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_60;

/**
 *
 * @author Nemesis
 */
public class metodo_60 {
    private String placa;
    private String modelo;
    private int dias ;

    public metodo_60(String placa, String modelo, int dias) {
        this.placa = placa;
        this.modelo = modelo;
        this.dias = dias;
    }

    public double total (int dias){
        return dias * 33500;
    }

    @Override
    public String toString() {
        return "metodo_60{" + "placa=" + placa + ", modelo=" + modelo + ", dias=" + dias +"| total :"+ total(dias )+ '}';
    }
    
    
}
