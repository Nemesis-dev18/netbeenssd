package com.mycompany.ejercicio_122;

public class Empleado {

    public double calcularSalario() {
        return 0;
    }
}