package com.mycompany.ejercicio_122;

public class Ejercicio_122 {

    public static void main(String[] args) {

        Empleado e1 = new EmpleadoTiempoCompleto(2000);
        Empleado e2 = new EmpleadoPorHoras(40, 15);

        System.out.println("Salario empleado tiempo completo: " + e1.calcularSalario());
        System.out.println("Salario empleado por horas: " + e2.calcularSalario());
    }
}