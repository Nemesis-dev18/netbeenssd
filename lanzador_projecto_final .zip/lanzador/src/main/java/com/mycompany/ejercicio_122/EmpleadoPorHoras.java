package com.mycompany.ejercicio_122;

public class EmpleadoPorHoras extends Empleado {

    private double horas;
    private double pagoHora;

    public EmpleadoPorHoras(double horas, double pagoHora) {
        this.horas = horas;
        this.pagoHora = pagoHora;
    }

    @Override
    public double calcularSalario() {
        return horas * pagoHora;
    }
}