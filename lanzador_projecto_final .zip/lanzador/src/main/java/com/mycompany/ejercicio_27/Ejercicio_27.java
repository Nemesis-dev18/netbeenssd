/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio_27;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Nemesis
 */
public class Ejercicio_27 {
    static Scanner entrada = new Scanner(System.in);
    static ArrayList<metodo_27> lista = new ArrayList<>();
    
    public static void main(String[] args) {
        
        String respuesta = "si";
        
        do {
            try {
                System.out.println("===============");
                String nombre = texto("ingrese el nombre del hospital ");
                int pacientes = numeros("ingrese el  umero de pacientes");
                metodo_27 nomb = new metodo_27(nombre, pacientes);
                lista.add(nomb);
                do {
                    respuesta = texto("¿Desea agregar otro? (si/no)");
                } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
                
            } catch (Exception e) {
                System.out.println("El dato está mal.");
                entrada.nextLine();                
            }
            
        } while (respuesta.equalsIgnoreCase("si"));
        for (metodo_27 string : lista) {
            System.out.println(string);
            
        }
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }
    
    public static int numeros(String mensaje) {
        System.out.println(mensaje + " :");
        int numero = entrada.nextInt();
        entrada.nextLine();
        return numero;
    }
}
