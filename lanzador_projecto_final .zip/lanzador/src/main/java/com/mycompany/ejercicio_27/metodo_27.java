/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_27;

/**
 *
 * @author Nemesis
 */
public class metodo_27 {
    private String nombre_hospital ;
    private int numero_de_pacientes; 

    public metodo_27(String nombre_hospital, int numero_de_pacientes) {
        this.nombre_hospital = nombre_hospital;
        this.numero_de_pacientes = numero_de_pacientes;
    }

    @Override
    public String toString() {
        return "metodo_37{" + "nombre_hospital=" + nombre_hospital + ", numero_de_pacientes=" + numero_de_pacientes + '}';
    }

    
}
