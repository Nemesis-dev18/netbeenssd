
package com.mycompany.ejercicio_85;

public class Producto {
    protected String nombre;
    protected double precio;

    public Producto(String nombre, double precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    public void MostrarInfo() {
        System.out.println("Nombre: " + nombre + ", Precio: " + precio);
    }
}
