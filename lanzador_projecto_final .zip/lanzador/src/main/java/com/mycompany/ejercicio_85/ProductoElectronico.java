
package com.mycompany.ejercicio_85;

public class ProductoElectronico extends Producto {

    private int garantia;

    public ProductoElectronico(String nombre, double precio, int garantia) {
        super(nombre, precio);
        this.garantia = garantia;
    }

    @Override
    public void MostrarInfo() {
        super.MostrarInfo();
        System.out.println("Garantia: " + garantia + " meses");
    }
}
