
package com.mycompany.ejercicio_85;

import java.util.Scanner;

public class Ejercicio_85 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String nombre = texto("Ingrese nombre");
        double precio = numero("Ingrese precio");
        int garantia = entero("Ingrese garantia");

        ProductoElectronico p = new ProductoElectronico(nombre, precio, garantia);
        p.MostrarInfo();
    }

    public static String texto(String m) {
        System.out.println(m + ":");
        return entrada.nextLine();
    }

    public static int entero(String m) {
        while (true) {
            try {
                System.out.println(m + ":");
                int n = entrada.nextInt();
                entrada.nextLine();
                return n;
            } catch (Exception e) {
                entrada.nextLine();
            }
        }
    }

    public static double numero(String m) {
        while (true) {
            try {
                System.out.println(m + ":");
                double n = entrada.nextDouble();
                entrada.nextLine();
                return n;
            } catch (Exception e) {
                entrada.nextLine();
            }
        }
    }
}
