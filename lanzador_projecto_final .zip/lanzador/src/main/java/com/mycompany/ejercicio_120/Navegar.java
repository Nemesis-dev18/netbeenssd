package com.mycompany.ejercicio_120;

public interface Navegar {
    public String navegar();
}