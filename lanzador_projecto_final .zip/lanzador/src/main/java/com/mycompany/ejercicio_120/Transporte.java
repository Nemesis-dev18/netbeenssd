package com.mycompany.ejercicio_120;

public class Transporte {
    protected String nombre;

    public Transporte(String nombre) {
        this.nombre = nombre;
    }

    public String MostrarInfo() {
        return "Transporte: " + nombre;
    }
}