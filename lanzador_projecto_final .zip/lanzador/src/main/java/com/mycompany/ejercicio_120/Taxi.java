package com.mycompany.ejercicio_120;

public class Taxi extends Transporte implements Navegar, DetectarObstaculos {

    public Taxi(String nombre) {
        super(nombre);
    }

    @Override
    public String navegar() {
        return nombre + " navega usando GPS.";
    }

    @Override
    public String detectar() {
        return nombre + " detecta obstáculos en tiempo real.";
    }
}