package com.mycompany.ejercicio_120;

public class Ejercicio_120 {

    public static void main(String[] args) {

        Bus bs1 = new Bus("Bus Urbano");
        Taxi tx1 = new Taxi("Taxi Amarillo");

        System.out.println(bs1.MostrarInfo());
        System.out.println(bs1.navegar());
        System.out.println(bs1.detectar());

        System.out.println("----------------");

        System.out.println(tx1.MostrarInfo());
        System.out.println(tx1.navegar());
        System.out.println(tx1.detectar());
    }
}