package com.mycompany.ejercicio_120;

public class Bus extends Transporte implements Navegar, DetectarObstaculos {

    public Bus(String nombre) {
        super(nombre);
    }

    @Override
    public String navegar() {
        return nombre + " sigue una ruta fija.";
    }

    @Override
    public String detectar() {
        return nombre + " detecta paradas y tráfico.";
    }
}