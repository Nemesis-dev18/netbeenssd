package com.mycompany.ejercicio_120;

public interface DetectarObstaculos {
    public String detectar();
}