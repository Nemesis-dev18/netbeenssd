package com.mycompany.ejercicio_66;

public class metodo_66 {
    private String nombre;
    private double precio;

    public metodo_66(String nombre, double precio) {

        if (nombre == null || nombre.trim().isEmpty()) {
            this.nombre = "Sin nombre";
        } else {
            this.nombre = nombre;
        }

        if (precio > 0) {
            this.precio = precio;
        } else {
            this.precio = 1;
        }
    }

    public double calcularTotal(double litros) {

        if (litros > 0) {
            return litros * precio;
        } else {
            return 0;
        }
    }

    public String MostrarInfo(double litros) {
        return "Estacion{" +
                "nombre=" + nombre +
                ", precio=" + precio +
                ", litros=" + litros +
                ", total=" + calcularTotal(litros) +
                '}';
    }
}