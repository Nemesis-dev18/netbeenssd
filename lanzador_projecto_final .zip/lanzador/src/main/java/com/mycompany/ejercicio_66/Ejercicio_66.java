package com.mycompany.ejercicio_66;

import java.util.Scanner;

public class Ejercicio_66 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String nombre = texto("Ingrese el nombre de la estación");
        double precio = decimalPositivo("Ingrese el precio del combustible");

        metodo_66 est1 = new metodo_66(nombre, precio);

        double litros = decimalPositivo("Ingrese los litros comprados");

        System.out.println(est1.MostrarInfo(litros));
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }

    public static double decimalPositivo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                double num = entrada.nextDouble();
                entrada.nextLine();

                if (num > 0) {
                    return num;
                } else {
                    System.out.println("Debe ser mayor a 0");
                }

            } catch (Exception e) {
                System.out.println("Ingrese un número válido");
                entrada.nextLine();
            }
        }
    }
}