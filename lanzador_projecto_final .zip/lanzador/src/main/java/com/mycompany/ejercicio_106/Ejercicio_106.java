package com.mycompany.ejercicio_106; 
public class Ejercicio_106{
    public static void main(String[] args){
        Gerente g=new Gerente("Carlos"); 
        g.MostrarInfo();}
}