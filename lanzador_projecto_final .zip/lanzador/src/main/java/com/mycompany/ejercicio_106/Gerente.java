package com.mycompany.ejercicio_106; public class Gerente extends Empleado{ 
    public Gerente(String n){super(n);
    } }