
package com.mycompany.ejercicio_180;

public class Libro {
    private boolean disponible = true;

    public boolean prestar(){
        if(disponible){
            disponible = false;
            return true;
        }
        return false;
    }

    public void devolver(){
        disponible = true;
    }

    public boolean isDisponible(){ return disponible; }
}
