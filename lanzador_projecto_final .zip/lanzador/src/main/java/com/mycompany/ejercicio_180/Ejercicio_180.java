
package com.mycompany.ejercicio_180;

public class Ejercicio_180 {
    public static void main(String[] args) {
        Libro l = new Libro();
        l.prestar();
        System.out.println(l.isDisponible());
    }
}
