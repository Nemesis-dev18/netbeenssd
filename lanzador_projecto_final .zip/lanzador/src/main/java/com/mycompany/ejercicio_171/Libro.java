
package com.mycompany.ejercicio_171;

public class Libro {
    private int paginas;

    public void setPaginas(int paginas){
        if(paginas > 0){
            this.paginas = paginas;
        }
    }

    public int getPaginas(){
        return paginas;
    }
}
