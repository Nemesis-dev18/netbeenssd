
package com.mycompany.ejercicio_171;

public class Ejercicio_171 {
    public static void main(String[] args) {
        Libro l = new Libro();
        l.setPaginas(200);
        System.out.println(l.getPaginas());
    }
}
