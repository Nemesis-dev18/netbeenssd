
package com.mycompany.ejercicio_185;

public class Ejercicio_185 {


    public static void main(String[] args) {

        AgendaContactos ac1 = new AgendaContactos();

        ac1.agregarContacto();
        ac1.agregarContacto();
        ac1.agregarContacto();

        System.out.println("Total de contactos: " + ac1.consultarTotal());
    }
}