
package com.mycompany.ejercicio_185;
public class AgendaContactos {

    private int numeroContactos;

    public void agregarContacto() {
        numeroContactos++;
    }

    public int consultarTotal() {
        return numeroContactos;
    }
}