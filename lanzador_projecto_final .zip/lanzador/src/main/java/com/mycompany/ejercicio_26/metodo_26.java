/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_26;

/**
 *
 * @author Nemesis
 */
public class metodo_26 {
    private String nombre;
    private String lugar_evento;
    private int fecha;

    public metodo_26(String nombre, String lugar_evento, int fecha) {
        this.nombre = nombre;
        this.lugar_evento = lugar_evento;
        this.fecha = fecha;
    }

    public String getNombre() {
        return nombre;
    }

    public String getLugar_evento() {
        return lugar_evento;
    }

    public int getFecha() {
        return fecha;
    }

    @Override
    public String toString() {
        return "metodo_26{" + "nombre=" + nombre + ", lugar_evento=" + lugar_evento + ", fecha=" + fecha + '}';
    }
    
    
}
