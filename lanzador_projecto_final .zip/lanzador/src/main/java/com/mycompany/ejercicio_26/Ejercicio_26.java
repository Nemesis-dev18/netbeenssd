package com.mycompany.ejercicio_26;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio_26 {

    static Scanner entrada = new Scanner(System.in);
    static ArrayList<metodo_26> lista = new ArrayList<>();
    
    public static void main(String[] args) {
        
        String respuesta = "si";
        
        do {
            try {
                System.out.println("===============");
                String evento = texto("ingrese el nombre del evento");
                String lugar = texto("ingrese el lugar del evento ");
                int fecha = numeros("ingrese la fecha del evento");
                metodo_26 nombre = new metodo_26(evento, lugar, fecha);
                lista.add(nombre);
                
                do {
                    respuesta = texto("¿Desea agregar otro? (si/no)");
                } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
                
            } catch (Exception e) {
                System.out.println("El dato está mal.");
                entrada.nextLine();                
            }
            
        } while (respuesta.equalsIgnoreCase("si"));
        for (metodo_26 string : lista) {
            System.out.println(string);
            
        }
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }
    
    public static int numeros(String mensaje) {
        System.out.println(mensaje + " :");
        int numero = entrada.nextInt();
        entrada.nextLine();
        return numero;
    }
}
