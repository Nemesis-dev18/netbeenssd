
package com.mycompany.ejercicio_77;

import java.util.Scanner;

public class Ejercicio_77 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        int contactos = entero("Ingrese numero de contactos");
        String propietario = texto("Ingrese propietario");

        metodo_77 obj = new metodo_77(contactos, propietario);

        obj.MostrarInfo();
        obj.agregarContactos(2);
        obj.MostrarInfo();
    }

    public static String texto(String m) {
        System.out.println(m + ":");
        return entrada.nextLine();
    }

    public static int entero(String m) {
        while (true) {
            try {
                System.out.println(m + ":");
                int n = entrada.nextInt();
                entrada.nextLine();
                return n;
            } catch (Exception e) {
                entrada.nextLine();
            }
        }
    }
}
