
package com.mycompany.ejercicio_77;

public class metodo_77 {

    private int contactos;
    private String propietario;

    public metodo_77(int contactos, String propietario) {
        this.contactos = contactos;
        this.propietario = propietario;
    }

    public void MostrarInfo() {
        System.out.println("Propietario: " + propietario +
                ", Contactos: " + contactos);
    }

    public void agregarContactos(int cantidad) {
        contactos += cantidad;
    }
}
