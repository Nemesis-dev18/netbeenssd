package com.mycompany.ejercicio_126;

public abstract class Empleado {

    protected String nombre;

    public Empleado(String nombre) {
        this.nombre = nombre;
    }

    public abstract double calcularPago();

    public String MostrarInfo() {
        return "Empleado: " + nombre;
    }
}