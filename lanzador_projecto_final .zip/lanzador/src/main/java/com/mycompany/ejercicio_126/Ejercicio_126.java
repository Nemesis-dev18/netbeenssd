package com.mycompany.ejercicio_126;

public class Ejercicio_126 {

    public static void main(String[] args) {

        Empleado e1 = new EmpleadoFijo("Juan", 2000);
        Empleado e2 = new EmpleadoPorHoras("Ana", 40, 15);

        System.out.println(e1.MostrarInfo());
        System.out.println("Pago: " + e1.calcularPago());

        System.out.println("----------------");

        System.out.println(e2.MostrarInfo());
        System.out.println("Pago: " + e2.calcularPago());
    }
}