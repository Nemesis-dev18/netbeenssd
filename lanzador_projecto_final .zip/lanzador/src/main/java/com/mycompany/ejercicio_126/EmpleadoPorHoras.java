package com.mycompany.ejercicio_126;

public class EmpleadoPorHoras extends Empleado {

    private double horas;
    private double pagoHora;

    public EmpleadoPorHoras(String nombre, double horas, double pagoHora) {
        super(nombre);
        this.horas = horas;
        this.pagoHora = pagoHora;
    }

    @Override
    public double calcularPago() {
        return horas * pagoHora;
    }
}