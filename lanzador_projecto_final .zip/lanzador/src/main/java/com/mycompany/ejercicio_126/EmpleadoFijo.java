package com.mycompany.ejercicio_126;

public class EmpleadoFijo extends Empleado {

    private double salario;

    public EmpleadoFijo(String nombre, double salario) {
        super(nombre);
        this.salario = salario;
    }

    @Override
    public double calcularPago() {
        return salario;
    }
}