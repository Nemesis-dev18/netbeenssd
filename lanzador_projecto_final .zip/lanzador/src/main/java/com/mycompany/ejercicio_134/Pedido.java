package com.mycompany.ejercicio_134;
public class Pedido{
 public double calcularTotal(){ return 10000; }
}