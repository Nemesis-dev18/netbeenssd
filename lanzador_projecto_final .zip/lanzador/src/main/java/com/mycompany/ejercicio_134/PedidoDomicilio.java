package com.mycompany.ejercicio_134;
public class PedidoDomicilio extends Pedido{
 @Override public double calcularTotal(){ return 12000; }
}