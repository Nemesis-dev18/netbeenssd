package com.mycompany.ejercicio_134;
public class Ejercicio_134{
 public static void main(String[] args){
  Pedido p1=new PedidoLocal();
  Pedido p2=new PedidoDomicilio();
  System.out.println(p1.calcularTotal());
  System.out.println(p2.calcularTotal());
 }
}