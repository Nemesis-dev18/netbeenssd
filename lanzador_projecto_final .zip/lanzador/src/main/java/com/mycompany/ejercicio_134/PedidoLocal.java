package com.mycompany.ejercicio_134;
public class PedidoLocal extends Pedido{
 @Override public double calcularTotal(){ return 10000; }
}