package com.mycompany.ejercicio_9;

public class metodo_9 {
    private String nombre;
    private double valor;

    public metodo_9(String nombre, double valor) {
        this.nombre = nombre;
        this.valor = valor;
    }

    public String MostrarInfo() {
        return "Nombre: " + nombre + ", Valor: " + valor;
    }
}
