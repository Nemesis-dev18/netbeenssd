
package com.mycompany.ejercicio_157;

public class SmartTV extends DispositivoInteligente {
    @Override
    public String ejecutarAccion() {
        return "Reproduciendo contenido";
    }
}
