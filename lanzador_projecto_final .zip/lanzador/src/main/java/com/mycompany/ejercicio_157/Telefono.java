
package com.mycompany.ejercicio_157;

public class Telefono extends DispositivoInteligente {
    @Override
    public String ejecutarAccion() {
        return "Realizando llamada";
    }
}
