
package com.mycompany.ejercicio_157;

public class Computador extends DispositivoInteligente {
    @Override
    public String ejecutarAccion() {
        return "Procesando información";
    }
}
