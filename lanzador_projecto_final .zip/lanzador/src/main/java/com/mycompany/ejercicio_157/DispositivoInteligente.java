
package com.mycompany.ejercicio_157;

public abstract class DispositivoInteligente {
    public abstract String ejecutarAccion();
}
