
package com.mycompany.ejercicio_157;

public class Ejercicio_157 {
    public static void main(String[] args) {
        DispositivoInteligente d1 = new Telefono();
        DispositivoInteligente d2 = new Computador();
        DispositivoInteligente d3 = new SmartTV();

        System.out.println(d1.ejecutarAccion());
        System.out.println(d2.ejecutarAccion());
        System.out.println(d3.ejecutarAccion());
    }
}
