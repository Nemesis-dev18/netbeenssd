package com.mycompany.ejercicio_6;

public class metodo_6 {
    private String nombre;
    private double valor;

    public metodo_6(String nombre, double valor) {
        this.nombre = nombre;
        this.valor = valor;
    }

    public String MostrarInfo() {
        return "Nombre: " + nombre + ", Valor: " + valor;
    }
}
