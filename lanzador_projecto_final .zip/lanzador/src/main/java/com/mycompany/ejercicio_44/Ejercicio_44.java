/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio_44;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Nemesis
 */
public class Ejercicio_44 {
    static Scanner entrada = new Scanner(System.in);
    static ArrayList<metodo_44> lista = new ArrayList<>();
    
    public static void main(String[] args) {
        
        String respuesta = "si";
        
        do {
            try {
                System.out.println("===============");
                String nomb_estadio= texto("ingrese nombre del estadio ");
                String nomb_ciudad= texto("ingrese nombre de la ciudad ");
                int cap = numeros("ingrese la capcidad del estadio ");
                metodo_44 nombre = new metodo_44(nomb_estadio, nomb_ciudad, cap);
                lista.add(nombre);
                
                do {
                    respuesta = texto("¿Desea agregar otro? (si/no)");
                } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
                
            } catch (Exception e) {
                System.out.println("El dato está mal.");
                entrada.nextLine();                
            }
            
        } while (respuesta.equalsIgnoreCase("si"));
        for (metodo_44 string : lista) {
            System.out.println(string);
            
        }
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }
    
    public static int numeros(String mensaje) {
        System.out.println(mensaje + " :");
        int numero = entrada.nextInt();
        entrada.nextLine();
        return numero;
    }
}
