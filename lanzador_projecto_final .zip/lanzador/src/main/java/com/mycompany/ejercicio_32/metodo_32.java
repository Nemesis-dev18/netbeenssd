package com.mycompany.ejercicio_32;


public class metodo_32 {

    private String marca;
    private String modelo;
    private double combustible;
    private boolean encendido ;

    public metodo_32(String marca, String modelo, double combustible) {
        this.encendido = false;
        this.marca = marca;
        this.modelo = modelo;
        this.combustible = combustible;
        this.encendido = false;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public double getCombustible() {
        return combustible;
    }
    
    
public String arranque(int opcion) {

    switch (opcion) {

        case 1:
            if (encendido) {
                return "El coche ya está encendido";
            }
            encendido = true;
            return "Coche encendido";

        case 2:
            if (!encendido) {
                return "El coche ya está apagado";
            }
            encendido = false;
            return "Coche apagado";

        default:
            return "Opción incorrecta";
    }
}

    @Override
    public String toString() {
        return "el coche {" + "marca=" + marca + ", modelo=" + modelo + '}';
    }


}