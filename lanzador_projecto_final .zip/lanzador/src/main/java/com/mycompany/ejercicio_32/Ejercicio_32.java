package com.mycompany.ejercicio_32;
import java.util.Scanner;

public class Ejercicio_32 {

static Scanner entrada = new Scanner(System.in);

    
public static void main(String[] args) {

    metodo_32 carro = null;

    try {
        System.out.println("===============");

        String marca = texto("Ingrese la marca del coche");
        String modelo = texto("Ingrese el modelo del coche");
        double gasolina = numeros("Ingrese la cantidad de gasolina");

        carro = new metodo_32(marca, modelo, gasolina);

    } catch (Exception e) {
        System.out.println("El dato está mal.");
    }

    if (carro == null) {
        System.out.println("No se pudo crear el coche.");
        return;
    }

    String respuesta = "si" ;

    do {
        try {
            System.out.println("===============");
            System.out.println(
    "---------------\n" +
    "MENU\n" +
    "1. Encender coche\n" +
    "2. Apagar coche"
);
            int opcion = entrada.nextInt();
            entrada.nextLine();

           if (opcion == 1 || opcion == 2) {
    String resultado = carro.arranque(opcion);
    System.out.println(resultado);
} else {
    System.out.println("Opción inválida");
}
            System.out.println(carro.toString());
            String resultado = carro.arranque(opcion);
            System.out.println(resultado);

            respuesta = texto("¿Desea hacer otra acción? (si/no)");

        } catch (Exception e) {
            System.out.println("El dato está mal.");
            entrada.nextLine();
            respuesta = "si";
        }

    } while (respuesta.equalsIgnoreCase("si"));
}
    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }
    
    public static double numeros(String mensaje) {
        System.out.println(mensaje + " :");
        double numero = entrada.nextDouble();
        entrada.nextLine();
        return numero;
    }
}
