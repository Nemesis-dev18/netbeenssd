
package com.mycompany.ejercicio_159;

public class Ejercicio_159 {
    public static void main(String[] args) {
        SistemaBiblioteca b1 = new Estudiante();
        SistemaBiblioteca b2 = new Profesor();

        int dias = 5;

        System.out.println("Estudiante: " + b1.prestarLibro(dias));
        System.out.println("Profesor: " + b2.prestarLibro(dias));
    }
}
