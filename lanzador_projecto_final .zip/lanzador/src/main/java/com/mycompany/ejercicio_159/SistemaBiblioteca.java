
package com.mycompany.ejercicio_159;

public abstract class SistemaBiblioteca {
    public abstract int prestarLibro(int dias);
}
