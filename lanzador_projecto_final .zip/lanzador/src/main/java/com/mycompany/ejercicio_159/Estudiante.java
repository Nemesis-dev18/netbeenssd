
package com.mycompany.ejercicio_159;

public class Estudiante extends SistemaBiblioteca {
    @Override
    public int prestarLibro(int dias) {
        return dias;
    }
}
