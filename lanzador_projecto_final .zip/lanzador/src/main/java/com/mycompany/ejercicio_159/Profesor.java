
package com.mycompany.ejercicio_159;

public class Profesor extends SistemaBiblioteca {
    @Override
    public int prestarLibro(int dias) {
        return dias * 2;
    }
}
