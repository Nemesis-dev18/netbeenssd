
package com.mycompany.ejercicio_88;

public class Camion extends Vehiculo{

    private double carga;

    public Camion(String marca, double carga){
        super(marca);
        this.carga = carga;
    }

    @Override
    public void MostrarInfo(){
        super.MostrarInfo();
        System.out.println("Carga: " + carga);
    }
}
