
package com.mycompany.ejercicio_88;

public class Vehiculo {
    protected String marca;

    public Vehiculo(String marca){
        this.marca = marca;
    }

    public void MostrarInfo(){
        System.out.println("Marca: " + marca);
    }
}
