
package com.mycompany.ejercicio_88;

public class Ejercicio_88 {
    public static void main(String[] args){
        Moto m = new Moto("Yamaha", 150);
        Camion c = new Camion("Volvo", 5000);

        m.MostrarInfo();
        c.MostrarInfo();
    }
}
