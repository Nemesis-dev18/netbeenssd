
package com.mycompany.ejercicio_88;

public class Moto extends Vehiculo{

    private int cilindrada;

    public Moto(String marca, int cilindrada){
        super(marca);
        this.cilindrada = cilindrada;
    }

    @Override
    public void MostrarInfo(){
        super.MostrarInfo();
        System.out.println("Cilindrada: " + cilindrada);
    }
}
