package com.mycompany.ejercicio_121;

public class Figura {

    public double calcularArea() {
        return 0;
    }
}