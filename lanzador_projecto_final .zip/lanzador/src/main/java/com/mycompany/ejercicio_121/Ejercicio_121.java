package com.mycompany.ejercicio_121;

public class Ejercicio_121 {

    public static void main(String[] args) {

        Figura f1 = new Circulo(5);
        Figura f2 = new Rectangulo(4, 3);

        System.out.println("Área círculo: " + f1.calcularArea());
        System.out.println("Área rectángulo: " + f2.calcularArea());
    }
}