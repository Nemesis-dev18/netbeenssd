/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_25;

/**
 *
 * @author Nemesis
 */
public class metodo_25 {
    private String nombre_pedido;
    private String nombre_cliente;
    private double valor ;

    public metodo_25(String nombre_pedido, String nombre_cliente, double valor) {
        this.nombre_pedido = nombre_pedido;
        this.nombre_cliente = nombre_cliente;
        this.valor = valor;
    }

    public String getNombre_pedido() {
        return nombre_pedido;
    }

    public String getNombre_cliente() {
        return nombre_cliente;
    }

    public double getValor() {
        return valor;
    }

    @Override
    public String toString() {
        return "metodo_25{" + "nombre_pedido=" + nombre_pedido + ", nombre_cliente=" + nombre_cliente + ", valor=" + valor + '}';
    }
    
    
    
}
