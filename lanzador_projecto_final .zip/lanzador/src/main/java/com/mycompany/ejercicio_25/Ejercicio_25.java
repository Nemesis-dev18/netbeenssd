package com.mycompany.ejercicio_25;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio_25 {


      static Scanner entrada = new Scanner(System.in);
    static ArrayList<metodo_25> lista = new ArrayList<>();
    
    public static void main(String[] args) {
        
        String respuesta = "si";
        
        do {
            try {
                System.out.println("===============");
                
                String pedido = texto("ingrese el nombre del pedido");
                String nombre = texto("ingrese su nombre ");
                double valor = numeros("ingrese el valor del producto ");
                metodo_25 producto = new metodo_25(pedido, nombre, valor);
                lista.add(producto);
                
                
                do {
                    respuesta = texto("¿Desea agregar otro? (si/no)");
                } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
                
            } catch (Exception e) {
                System.out.println("El dato está mal.");
                entrada.nextLine();                
            }
            
        } while (respuesta.equalsIgnoreCase("si"));
        for (metodo_25 string : lista) {
            System.out.println(string);
            
        }
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }
    
    public static double  numeros(String mensaje) {
        System.out.println(mensaje + " :");
        double numero = entrada.nextDouble();
        entrada.nextLine();
        return numero;
    }
    
}
