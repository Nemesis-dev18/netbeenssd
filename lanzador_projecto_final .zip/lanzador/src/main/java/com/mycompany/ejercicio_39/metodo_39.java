/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_39;

/**
 *
 * @author Nemesis
 */
public class metodo_39 {
    private String nombre_estadio;
    private String nombre_ciudad;
    private int capacidad ;

    public metodo_39(String nombre_estadio, String nombre_ciudad, int capacidad) {
        this.nombre_estadio = nombre_estadio;
        this.nombre_ciudad = nombre_ciudad;
        this.capacidad = capacidad;
    }

    @Override
    public String toString() {
        return "metodo_39{" + "nombre_estadio=" + nombre_estadio + ", nombre_ciudad=" + nombre_ciudad + ", capacidad=" + capacidad + '}';
    }
    
    
    
}
