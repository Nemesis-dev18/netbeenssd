
package com.mycompany.ejercicio_164;

public class Ejercicio_164 {
    public static void main(String[] args) {
        CuentaBancaria c = new CuentaBancaria();
        c.depositar(1000);
        c.retirar(200);
        System.out.println(c.getSaldo());
    }
}
