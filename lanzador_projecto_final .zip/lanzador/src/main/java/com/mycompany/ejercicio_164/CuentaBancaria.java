
package com.mycompany.ejercicio_164;

public class CuentaBancaria {
    private double saldo;

    public void depositar(double monto){ saldo += monto; }
    public void retirar(double monto){ saldo -= monto; }
    public double getSaldo(){ return saldo; }
}
