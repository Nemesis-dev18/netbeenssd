package com.mycompany.ejercicio_141;
public class Ejercicio_141{
 public static void main(String[] args){
  Calculadora c=new Calculadora();
  System.out.println(c.operar(5,3,"+"));
  System.out.println(c.operar(5,3,"*"));
 }
}