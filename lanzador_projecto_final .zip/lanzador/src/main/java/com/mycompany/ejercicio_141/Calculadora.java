package com.mycompany.ejercicio_141;
public class Calculadora{
 public double operar(double a,double b,String op){
  if(op.equals("+")) return a+b;
  if(op.equals("-")) return a-b;
  if(op.equals("*")) return a*b;
  if(op.equals("/")) return a/b;
  return 0;
 }
}