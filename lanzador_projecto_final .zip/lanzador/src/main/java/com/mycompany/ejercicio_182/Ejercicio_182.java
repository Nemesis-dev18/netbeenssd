
package com.mycompany.ejercicio_182;

public class Ejercicio_182 {
    public static void main(String[] args) {
        Cuenta c1 = new Cuenta();
        Cuenta c2 = new Cuenta();

        c1.depositar(1000);
        c1.transferir(c2, 300);

        System.out.println(c1.getSaldo());
        System.out.println(c2.getSaldo());
    }
}
