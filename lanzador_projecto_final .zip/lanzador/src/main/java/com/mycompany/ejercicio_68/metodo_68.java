package com.mycompany.ejercicio_68;

public class metodo_68 {
    private String nombre;
    private int prendas;
    private double precioPromedio;

    public metodo_68(String nombre, int prendas, double precioPromedio) {

        if (nombre == null || nombre.trim().isEmpty()) {
            this.nombre = "Sin nombre";
        } else {
            this.nombre = nombre;
        }

        if (prendas >= 0) {
            this.prendas = prendas;
        } else {
            this.prendas = 0;
        }

        if (precioPromedio > 0) {
            this.precioPromedio = precioPromedio;
        } else {
            this.precioPromedio = 1;
        }
    }

    public double calcularInventario() {
        return prendas * precioPromedio;
    }

    public String MostrarInfo() {
        return "TiendaRopa{" +
                "nombre=" + nombre +
                ", prendas=" + prendas +
                ", precioPromedio=" + precioPromedio +
                ", totalInventario=" + calcularInventario() +
                '}';
    }
}