package com.mycompany.ejercicio_68;

import java.util.Scanner;

public class Ejercicio_68 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String nombre = texto("Ingrese el nombre de la tienda");
        int prendas = enteroNoNegativo("Ingrese número de prendas");
        double precio = decimalPositivo("Ingrese precio promedio");

        metodo_68 t1 = new metodo_68(nombre, prendas, precio);

        System.out.println(t1.MostrarInfo());
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }

    public static int enteroNoNegativo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                int num = entrada.nextInt();
                entrada.nextLine();

                if (num >= 0) return num;
                else System.out.println("No puede ser negativo");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }

    public static double decimalPositivo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                double num = entrada.nextDouble();
                entrada.nextLine();

                if (num > 0) return num;
                else System.out.println("Debe ser mayor a 0");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }
}