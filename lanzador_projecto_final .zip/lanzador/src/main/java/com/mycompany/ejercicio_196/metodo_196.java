package com.mycompany.ejercicio_196;

public class metodo_196 {
    private int numeroRuta;
    private String destino;

    public metodo_196(int numeroRuta, String destino) {

        if (numeroRuta > 0) {
            this.numeroRuta = numeroRuta;
        } else {
            this.numeroRuta = 1;
        }

        if (destino == null || destino.trim().isEmpty()) {
            this.destino = "Sin destino";
        } else {
            this.destino = destino;
        }
    }

    public void setDestino(String destino) {
        if (destino != null && !destino.trim().isEmpty()) {
            this.destino = destino;
        } else {
            System.out.println("Destino inválido");
        }
    }

    public int getNumeroRuta() {
        return numeroRuta;
    }

    public String getDestino() {
        return destino;
    }

    public String MostrarInfo() {
        return "RutaBus{" +
                "numeroRuta=" + numeroRuta +
                ", destino=" + destino +
                '}';
    }
}