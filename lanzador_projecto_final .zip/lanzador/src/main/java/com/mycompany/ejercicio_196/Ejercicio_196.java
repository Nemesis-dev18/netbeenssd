package com.mycompany.ejercicio_196;

import java.util.Scanner;

public class Ejercicio_196 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        int numero = enteroPositivo("Ingrese número de ruta");
        String destino = textoValido("Ingrese destino");

        metodo_196 r1 = new metodo_196(numero, destino);

        System.out.println(r1.MostrarInfo());

        String nuevoDestino = textoValido("Ingrese nuevo destino");
        r1.setDestino(nuevoDestino);

        System.out.println("Datos actualizados:");
        System.out.println(r1.MostrarInfo());
    }

    public static String textoValido(String mensaje) {
        while (true) {
            System.out.println(mensaje + ":");
            String dato = entrada.nextLine();

            if (!dato.trim().isEmpty()) return dato;
            else System.out.println("No puede estar vacío");
        }
    }

    public static int enteroPositivo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                int num = entrada.nextInt();
                entrada.nextLine();

                if (num > 0) return num;
                else System.out.println("Debe ser mayor a 0");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }
}