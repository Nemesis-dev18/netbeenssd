
package com.mycompany.ejercicio_181;

public class Usuario {
    private int intentos = 0;

    public boolean login(String pass){
        if(pass.equals("1234")){
            intentos = 0;
            return true;
        }else{
            intentos++;
            return false;
        }
    }

    public int getIntentos(){ return intentos; }
}
