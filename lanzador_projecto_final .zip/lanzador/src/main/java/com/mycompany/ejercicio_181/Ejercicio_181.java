
package com.mycompany.ejercicio_181;

public class Ejercicio_181 {
    public static void main(String[] args) {
        Usuario u = new Usuario();
        u.login("1111");
        u.login("2222");
        System.out.println(u.getIntentos());
    }
}
