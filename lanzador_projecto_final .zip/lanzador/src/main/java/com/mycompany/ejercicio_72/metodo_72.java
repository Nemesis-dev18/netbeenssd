package com.mycompany.ejercicio_72;

public class metodo_72 {

    private double num;
    private String titular;
    private double saldo;

    public metodo_72(double num, String titular, double saldo) {
        this.num = num;
        this.titular = titular;
        this.saldo = saldo;
    }

    public void retirar(double monto) {
        if (monto > 0 && monto <= saldo) {
            saldo -= monto;
        } else {
            System.out.println("No se puede retirar");
        }
    }

    public void consignar(double monto) {
        if (monto > 0) {
            saldo += monto;
        } else {
            System.out.println("Monto inválido");
        }
    }

    @Override
    public String toString() {
        return "metodo_72{" +
                "num=" + num +
                ", titular=" + titular +
                ", saldo=" + saldo +
                '}';
    }
}