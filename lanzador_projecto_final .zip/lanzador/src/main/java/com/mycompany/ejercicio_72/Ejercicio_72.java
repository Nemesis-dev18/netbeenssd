package com.mycompany.ejercicio_72;

import java.util.Scanner;

public class Ejercicio_72 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        System.out.println("===============");

        String dato1 = texto("Ingrese el nombre del titular");
        long dato2 = (long) numeros("Ingrese el numero de la cuenta");
        double dato3 = numeros("Ingrese el saldo de la cuenta");

        metodo_72 obj = new metodo_72(dato3, dato1, dato2);

        int opcion;

        do {
            System.out.println(
    "1. Ver cuenta\n" +
    "2. Aumentar saldo\n" +
    "3. Retirar saldo\n" +
    "4. Salir"
);

            opcion = (int) numeros("Seleccione una opción");

            switch (opcion) {

                case 1:
                    System.out.println(obj);
                    break;

                case 2:
                    double monto1 = numeros("Ingrese el monto a consignar");
                    obj.consignar(monto1);
                    break;

                case 3:
                    double monto2 = numeros("Ingrese el monto a retirar");
                    obj.retirar(monto2);
                    break;

                case 4:
                    System.out.println("Saliendo...");
                    break;

                default:
                    System.out.println("Opción inválida");
            }

        } while (opcion != 4);
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }

    public static double numeros(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                double numero = entrada.nextDouble();
                entrada.nextLine();
                return numero;
            } catch (Exception e) {
                System.out.println("Ingrese un número válido");
                entrada.nextLine();
            }
        }
    }
}