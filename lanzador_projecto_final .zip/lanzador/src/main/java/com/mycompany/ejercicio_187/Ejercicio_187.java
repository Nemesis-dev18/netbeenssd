
package com.mycompany.ejercicio_187;

public class Ejercicio_187 {
    public static void main(String[] args) {
        Carrito c = new Carrito();
        c.agregar(100);
        c.aplicarDescuento(0.1);
        System.out.println(c.getTotal());
    }
}
