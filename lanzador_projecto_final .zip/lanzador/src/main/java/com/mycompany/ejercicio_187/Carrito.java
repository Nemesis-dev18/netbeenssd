
package com.mycompany.ejercicio_187;

public class Carrito {
    private double total;

    public void agregar(double precio){
        if(precio > 0){
            total += precio;
        }
    }

    public void aplicarDescuento(double porcentaje){
        if(porcentaje > 0){
            total -= total * porcentaje;
        }
    }

    public double getTotal(){ return total; }
}
