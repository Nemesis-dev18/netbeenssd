package com.mycompany.ejercicio_36;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Ejercicio_36 {
    static Scanner entrada = new Scanner(System.in);
    static ArrayList<metodo_36> lista = new ArrayList<>();
    
    public static void main(String[] args) {
        
        String respuesta = "si";
        
        do {
            try {
                System.out.println("===============");
                int cant_prodcutos = numeros("ingrese la cantidad de productos actual a comprar ");
                double  valor = valor(" ingrese el valor de el prodcuto a comprar ");
                metodo_36 nombre = new metodo_36(cant_prodcutos, valor);
                lista.add(nombre);
                System.out.println(nombre.toString());
                System.out.println(" ");
                String opcion = texto(" quiere añadir mas prodcutos  ?  (si/no)");
                if (opcion.equalsIgnoreCase("si") ) {
                    int cantidad_nueva = numeros("ingrese la cantidad de nuevo producto ");
                    System.out.println(nombre.agregar(cantidad_nueva));  
                }
                
                do {
                    respuesta = texto("¿Desea agregar otro? (si/no)");
                } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
                
            } catch (InputMismatchException e) {
                System.out.println("El dato está mal.");
                entrada.nextLine();                
            }
            
            
        } while (respuesta.equalsIgnoreCase("si"));
        for (metodo_36 string : lista) {
            System.out.println(string);
            
        }
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }
    
    public static int numeros(String mensaje) {
        System.out.println(mensaje + " :");
        int numero = entrada.nextInt();
        entrada.nextLine();
        return numero;
    }
    public static double valor (String mensaje) {
        System.out.println(mensaje + " :");
        double numero = entrada.nextDouble ();
        entrada.nextLine();
        return numero;
    }
}
