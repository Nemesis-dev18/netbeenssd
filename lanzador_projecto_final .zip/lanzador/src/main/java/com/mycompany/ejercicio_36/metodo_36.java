/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_36;

/**
 *
 * @author Nemesis
 */
public class metodo_36 {
    private int  num_productos ;
    private double valor_del_producto ;

    public metodo_36(int num_productos, double valor_del_producto) {
        this.num_productos = num_productos;
        this.valor_del_producto = valor_del_producto;
    }

    public int getNum_productos() {
        return num_productos;
    }

    public double getValor_del_producto() {
        return valor_del_producto;
    }

    public String agregar ( int valor ){
        
        if (valor < 0) {
            return " no se pueden agregar porque esta mal la cantidad ";
        }else {
            num_productos += valor;
            return "la nueva cantidad de productos es "+ getNum_productos() ;
        }
        
    }
    public  double total (){
        double total = num_productos* valor_del_producto ;
        return total ;
    }
    
    @Override
    public String toString() {
        return "metodo_36{" + "num_productos=" + num_productos + ", valor_del_producto=" + valor_del_producto + ", valor total=" + total() + '}';
    }
    
    
    
}
