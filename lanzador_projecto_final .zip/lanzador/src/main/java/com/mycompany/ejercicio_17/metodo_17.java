package com.mycompany.ejercicio_17;
public class metodo_17 {
    private String color ; 
    private int cambios ;

    public metodo_17(String color, int cambios) {
        this.color = color;
        this.cambios = cambios;
    }

    public String getColor() {
        return color;
    }

    public int getCambios() {
        return cambios;
    }

    @Override
    public String toString() {
        return "metodo_23{" + "color=" + color + ", cambios=" + cambios + '}';
    }
    
    
}
