package com.mycompany.ejercicio_17;

import java.util.ArrayList;
import java.util.Scanner;

public class ejercicio_17 {
static Scanner entrada = new Scanner(System.in);
static ArrayList<metodo_17> lista = new ArrayList<>();
    public static void main(String[] args) {
        String respuesta ; 
        try {
            do {               
                System.out.println("===============");
                String color = texto("ingrese el color de la bici ");
                int numero_cambios = numeros("ingrese el numero de cambios de la bici ");
                
                metodo_17 bici = new metodo_17(color, numero_cambios);
                lista.add(bici);
                do {
                    respuesta = texto("¿Desea agregar otro ? (si/no)");
                } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
            } while (respuesta.equalsIgnoreCase("si"));
            for (metodo_17 st : lista) {
                System.out.println(st);
                
            }
        } catch (Exception e) {
            System.out.println("el dato esta mal no sea pendejo ");
        }
        
    }
    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();}
    public static int numeros(String mensaje) {
        System.out.println(mensaje + " :");
        int numero = entrada.nextInt();
        entrada.nextLine();
        return numero;
    }
}
