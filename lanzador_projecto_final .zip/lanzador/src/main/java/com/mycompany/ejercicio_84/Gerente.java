
package com.mycompany.ejercicio_84;

public class Gerente extends Empleado {

    private String departamento;

    public Gerente(String nombre, double salario, String departamento) {
        super(nombre, salario);
        this.departamento = departamento;
    }

    @Override
    public void MostrarInfo() {
        super.MostrarInfo();
        System.out.println("Departamento: " + departamento);
    }
}
