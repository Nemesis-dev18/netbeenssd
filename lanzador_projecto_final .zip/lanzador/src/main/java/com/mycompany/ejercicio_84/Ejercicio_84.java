
package com.mycompany.ejercicio_84;

import java.util.Scanner;

public class Ejercicio_84 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String nombre = texto("Ingrese nombre");
        double salario = numero("Ingrese salario");
        String depto = texto("Ingrese departamento");

        Gerente g = new Gerente(nombre, salario, depto);
        g.MostrarInfo();
    }

    public static String texto(String m) {
        System.out.println(m + ":");
        return entrada.nextLine();
    }

    public static double numero(String m) {
        while (true) {
            try {
                System.out.println(m + ":");
                double n = entrada.nextDouble();
                entrada.nextLine();
                return n;
            } catch (Exception e) {
                entrada.nextLine();
            }
        }
    }
}
