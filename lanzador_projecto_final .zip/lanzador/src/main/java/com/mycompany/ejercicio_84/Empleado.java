
package com.mycompany.ejercicio_84;

public class Empleado {
    protected String nombre;
    protected double salario;

    public Empleado(String nombre, double salario) {
        this.nombre = nombre;
        this.salario = salario;
    }

    public void MostrarInfo() {
        System.out.println("Nombre: " + nombre + ", Salario: " + salario);
    }
}
