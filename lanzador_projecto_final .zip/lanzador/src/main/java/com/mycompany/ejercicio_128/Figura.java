package com.mycompany.ejercicio_128;

public abstract class Figura {

    protected String nombre;

    public Figura(String nombre) {
        this.nombre = nombre;
    }

    public abstract double calcularPerimetro();

    public String MostrarInfo() {
        return "Figura: " + nombre;
    }
}