package com.mycompany.ejercicio_128;

public class Ejercicio_128 {

    public static void main(String[] args) {

        Figura f1 = new Cuadrado("Cuadrado", 5);
        Figura f2 = new Triangulo("Triángulo", 3, 4, 5);

        System.out.println(f1.MostrarInfo());
        System.out.println("Perímetro: " + f1.calcularPerimetro());

        System.out.println("----------------");

        System.out.println(f2.MostrarInfo());
        System.out.println("Perímetro: " + f2.calcularPerimetro());
    }
}