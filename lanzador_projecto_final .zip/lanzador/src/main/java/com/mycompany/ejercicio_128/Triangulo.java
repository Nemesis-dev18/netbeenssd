package com.mycompany.ejercicio_128;

public class Triangulo extends Figura {

    private double a, b, c;

    public Triangulo(String nombre, double a, double b, double c) {
        super(nombre);
        this.a = a;
        this.b = b;
        this.c = c;
    }

    @Override
    public double calcularPerimetro() {
        return a + b + c;
    }
}