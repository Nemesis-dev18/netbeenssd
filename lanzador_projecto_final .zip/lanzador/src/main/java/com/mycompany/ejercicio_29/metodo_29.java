/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_29;

/**
 *
 * @author Nemesis
 */
public class metodo_29 {
    private String nombre ; 
    private int num_libros ;

    public metodo_29(String nombre, int num_libros) {
        this.nombre = nombre;
        this.num_libros = num_libros;
    }

    public String getNombre() {
        return nombre;
    }

    public int getNum_libros() {
        return num_libros;
    }

    @Override
    public String toString() {
        return "metodo_29{" + "nombre=" + nombre + ", num_libros=" + num_libros + '}';
    }
    
    
    
}
