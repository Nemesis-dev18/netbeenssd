package com.mycompany.ejercicio_29;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio_29 {

    static Scanner entrada = new Scanner(System.in);
    static ArrayList<metodo_29> lista = new ArrayList<>();
    
    public static void main(String[] args) {
        
        String respuesta = "si";
        
        do {
            try {
                System.out.println("===============");
                String nombre_b = texto("ingrese el nombre de la biblioteca ");
                int num_libros = numeros("ingrese la cantidad de libros que hay ");
                metodo_29 nombre = new metodo_29(nombre_b, num_libros);
                lista.add(nombre);
                
                do {
                    respuesta = texto("¿Desea agregar otro? (si/no)");
                } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
                
            } catch (Exception e) {
                System.out.println("El dato está mal.");
                entrada.nextLine();                
            }
            
        } while (respuesta.equalsIgnoreCase("si"));
        for (metodo_29 string : lista) {
            System.out.println(string);
            
        }
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }
    
    public static int numeros(String mensaje) {
        System.out.println(mensaje + " :");
        int numero = entrada.nextInt();
        entrada.nextLine();
        return numero;
    }
}
