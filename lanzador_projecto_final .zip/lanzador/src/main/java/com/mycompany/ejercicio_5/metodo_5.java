package com.mycompany.ejercicio_5;

public class metodo_5 {
    private String nombre;
    private double valor;

    public metodo_5(String nombre, double valor) {
        this.nombre = nombre;
        this.valor = valor;
    }

    public String MostrarInfo() {
        return "Nombre: " + nombre + ", Valor: " + valor;
    }
}
