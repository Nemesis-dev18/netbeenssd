package com.mycompany.ejercicio_5;

import java.util.Scanner;

public class Ejercicio_5 {
    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        
        String nombre = texto("Ingrese nombre");
        double valor = numero("Ingrese valor");
        metodo_5 obj = new metodo_5(nombre, valor);
        System.out.println(obj.MostrarInfo());
    

    }

    public static String texto(String msg) {
        System.out.println(msg + ":");
        return entrada.nextLine();
    }

    public static double numero(String msg) {
        while(true){
            try{
                System.out.println(msg + ":");
                double n = entrada.nextDouble();
                entrada.nextLine();
                return n;
            }catch(Exception e){
                System.out.println("Error, ingrese número válido");
                entrada.nextLine();
            }
        }
    }
}
