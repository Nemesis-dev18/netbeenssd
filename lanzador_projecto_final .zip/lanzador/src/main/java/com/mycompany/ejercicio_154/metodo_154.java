package com.mycompany.ejercicio_154;

public class metodo_154 {

    // Autenticación por contraseña
    public String autenticar(String usuario, String contraseña) {

        if (contraseña.equals("1234")) {
            return "Acceso concedido por contraseña para " + usuario;
        } else {
            return "Acceso denegado";
        }
    }

    // Autenticación por huella
    public String autenticar(String usuario, int huella) {

        if (huella == 1111) {
            return "Acceso concedido por huella para " + usuario;
        } else {
            return "Acceso denegado";
        }
    }

    // Autenticación por reconocimiento facial
    public String autenticar(String usuario, boolean reconocimiento) {

        if (reconocimiento) {
            return "Acceso concedido por reconocimiento facial para " + usuario;
        } else {
            return "Acceso denegado";
        }
    }
}