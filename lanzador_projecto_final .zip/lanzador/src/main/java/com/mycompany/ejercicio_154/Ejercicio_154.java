package com.mycompany.ejercicio_154;

import java.util.Scanner;

public class Ejercicio_154 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        metodo_154 c1 = new metodo_154();

        String usuario = texto("Ingrese usuario");

        int opcion = enteroPositivo("Seleccione tipo de acceso:\n1. Contraseña\n2. Huella\n3. Reconocimiento facial");

        switch (opcion) {

            case 1:
                String pass = texto("Ingrese contraseña");
                System.out.println(c1.autenticar(usuario, pass));
                break;

            case 2:
                int huella = enteroPositivo("Ingrese código de huella");
                System.out.println(c1.autenticar(usuario, huella));
                break;

            case 3:
                boolean acceso = true; // simulación
                System.out.println(c1.autenticar(usuario, acceso));
                break;

            default:
                System.out.println("Opción inválida");
        }
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }

    public static int enteroPositivo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                int num = entrada.nextInt();
                entrada.nextLine();

                if (num > 0) return num;
                else System.out.println("Debe ser mayor a 0");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }
}