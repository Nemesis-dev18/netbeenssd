/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_34;

public class metodo_34 {
    private  String nombre;
    private int expe;

    public metodo_34(String nombre, int expe) {
        this.nombre = nombre;
        this.expe = expe;
    }

    public String getNombre() {
        return nombre;
    }

    public int getExpe() {
        return expe;
    }

    @Override
    public String toString() {
        return "metodo_34{" + "nombre=" + nombre + ", expe=" + expe + '}';
    }
    
    
}
