/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_24;

/**
 *
 * @author Nemesis
 */
public class metodo_24 {
    private String nombre;
    private String correo;
    private long numero;

    public metodo_24(String nombre, String correo, long numero) {
        this.nombre = nombre;
        this.correo = correo;
        this.numero = numero;
    }
    

    public String getNombre() {
        return nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public long getNumero() {
        return numero;
    }

    @Override
    public String toString() {
        return "metodo_24{" + "nombre=" + nombre + ", correo=" + correo + ", numero=" + numero + '}';
    }
    
    
    
    
}
