package com.mycompany.ejercicio_24;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio_24 {
    static Scanner entrada = new Scanner(System.in);
    static ArrayList<metodo_24> lista = new ArrayList<>();
    
    public static void main(String[] args) {
        
        String respuesta = "si";
        
        do {
            try {
                System.out.println("-----------------------");
                
                String cliente = texto("ingrese su nombre ");
                String correo = texto("ingrese su correo ");
                long telefono = numeros("ingrese su numero de telefono ");
                
                metodo_24 cliente1 = new metodo_24(cliente, correo, telefono);
                lista.add(cliente1);
                
                do {
                    respuesta = texto("¿Desea agregar otro? (si/no)");
                } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
                
            } catch (Exception e) {
                System.out.println("El dato está mal.");
                entrada.nextLine();                
            }
        } while (respuesta.equalsIgnoreCase("si"));
        for (metodo_24 string : lista) {
            System.out.println(string);
        }
    }
    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }
    
    public static long numeros(String mensaje) {
        System.out.println(mensaje + " :");
        long numero = entrada.nextLong();
        entrada.nextLine();
        return numero;
    }
}