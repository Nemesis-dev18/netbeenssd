/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejericicio_51;

/**
 *
 * @author Nemesis
 */
public class metodo_51 {
        private String usuario ;
        private String plan ;

    public metodo_51(String usuario, String plan) {
        this.usuario = usuario;
        this.plan = plan;
    }

    @Override
    public String toString() {
        return "metodo_51{" + "usuario=" + usuario + ", plan=" + plan + '}';
    }
        
        
    
}
