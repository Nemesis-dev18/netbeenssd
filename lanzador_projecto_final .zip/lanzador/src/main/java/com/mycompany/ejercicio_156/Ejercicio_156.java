
package com.mycompany.ejercicio_156;

public class Ejercicio_156 {
    public static void main(String[] args) {
        SistemaTransporte t1 = new Bus();
        SistemaTransporte t2 = new Tren();
        SistemaTransporte t3 = new Taxi();

        double d = 10;

        System.out.println("Bus: " + t1.calcularRuta(d));
        System.out.println("Tren: " + t2.calcularRuta(d));
        System.out.println("Taxi: " + t3.calcularRuta(d));
    }
}
