
package com.mycompany.ejercicio_156;

public class Tren extends SistemaTransporte {
    @Override
    public double calcularRuta(double distancia) {
        return distancia * 0.3;
    }
}
