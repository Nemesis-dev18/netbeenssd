
package com.mycompany.ejercicio_156;

public class Bus extends SistemaTransporte {
    @Override
    public double calcularRuta(double distancia) {
        return distancia * 0.5;
    }
}
