
package com.mycompany.ejercicio_156;

public class Taxi extends SistemaTransporte {
    @Override
    public double calcularRuta(double distancia) {
        return distancia * 1.2;
    }
}
