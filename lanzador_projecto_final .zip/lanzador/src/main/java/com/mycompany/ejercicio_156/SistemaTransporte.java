
package com.mycompany.ejercicio_156;

public abstract class SistemaTransporte {
    public abstract double calcularRuta(double distancia);
}
