package com.mycompany.ejercicio_118;

public interface GenerarFactura {
    public String generar(double valor);
}