package com.mycompany.ejercicio_118;

public class metodo_118 implements ProcesarPago, GenerarFactura {

    private String cliente;

    public metodo_118(String cliente) {

        if (cliente == null || cliente.trim().isEmpty()) {
            this.cliente = "Cliente";
        } else {
            this.cliente = cliente;
        }
    }

    @Override
    public String procesar(double valor) {
        if (valor > 0) {
            return "Pago procesado para " + cliente + " por valor de " + valor;
        } else {
            return "Valor inválido";
        }
    }

    @Override
    public String generar(double valor) {
        double impuesto = valor * 0.19;
        double total = valor + impuesto;

        return "Factura -> Cliente: " + cliente +
                ", subtotal: " + valor +
                ", total con impuesto: " + total;
    }

    public String MostrarInfo() {
        return "SistemaPago{" +
                "cliente=" + cliente +
                '}';
    }
}