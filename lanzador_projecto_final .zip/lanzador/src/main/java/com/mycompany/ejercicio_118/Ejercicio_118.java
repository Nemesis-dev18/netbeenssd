package com.mycompany.ejercicio_118;

import java.util.Scanner;

public class Ejercicio_118 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String cliente = textoValido("Ingrese nombre del cliente");
        double valor = decimalPositivo("Ingrese valor del pago");

        metodo_118 p1 = new metodo_118(cliente);

        System.out.println(p1.MostrarInfo());
        System.out.println(p1.procesar(valor));
        System.out.println(p1.generar(valor));
    }

    public static String textoValido(String mensaje) {
        while (true) {
            System.out.println(mensaje + ":");
            String dato = entrada.nextLine();

            if (!dato.trim().isEmpty()) return dato;
            else System.out.println("No puede estar vacío");
        }
    }

    public static double decimalPositivo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                double num = entrada.nextDouble();
                entrada.nextLine();

                if (num > 0) return num;
                else System.out.println("Debe ser mayor a 0");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }
}