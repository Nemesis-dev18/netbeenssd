package com.mycompany.ejercicio_118;

public interface ProcesarPago {
    public String procesar(double valor);
}