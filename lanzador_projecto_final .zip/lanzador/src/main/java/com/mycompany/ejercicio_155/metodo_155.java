package com.mycompany.ejercicio_155;

public class metodo_155 {


    public String generarFactura(String cliente, double valor) {
        return "Factura -> Cliente: " + cliente + ", total: " + valor;
    }


    public String generarFactura(String cliente, double valor, boolean vip) {

        if (vip) {
            double descuento = valor * 0.10;
            valor -= descuento;
        }

        return "Factura VIP -> Cliente: " + cliente + ", total: " + valor;
    }

    // Cliente con impuesto
    public String generarFactura(String cliente, double valor, double impuesto) {
        double total = valor + (valor * impuesto);
        return "Factura con impuesto -> Cliente: " + cliente + ", total: " + total;
    }
}