package com.mycompany.ejercicio_155;

import java.util.Scanner;

public class Ejercicio_155 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        metodo_155 s1 = new metodo_155();

        String cliente = texto("Ingrese nombre del cliente");
        double valor = decimalPositivo("Ingrese valor de compra");

        int opcion = enteroPositivo("Tipo de cliente:\n1. Normal\n2. VIP\n3. Con impuesto");

        switch (opcion) {

            case 1:
                System.out.println(s1.generarFactura(cliente, valor));
                break;

            case 2:
                System.out.println(s1.generarFactura(cliente, valor, true));
                break;

            case 3:
                double impuesto = decimalPositivo("Ingrese impuesto (ej: 0.19)");
                System.out.println(s1.generarFactura(cliente, valor, impuesto));
                break;

            default:
                System.out.println("Opción inválida");
        }
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }

    public static int enteroPositivo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                int num = entrada.nextInt();
                entrada.nextLine();

                if (num > 0) return num;
                else System.out.println("Debe ser mayor a 0");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }

    public static double decimalPositivo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                double num = entrada.nextDouble();
                entrada.nextLine();

                if (num > 0) return num;
                else System.out.println("Debe ser mayor a 0");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }
}