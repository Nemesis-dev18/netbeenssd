package com.mycompany.ejercicio_192;

import java.util.Scanner;

public class Ejercicio_192 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        metodo_192 s1 = new metodo_192();

        String respuesta = "si";

        do {
            double valor = decimalPositivo("Ingrese valor de la venta");

            s1.registrarVenta(valor);

            do {
                respuesta = texto("¿Desea registrar otra venta? (si/no)");
            } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));

        } while (respuesta.equalsIgnoreCase("si"));

        System.out.println(s1.MostrarInfo());
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }

    public static double decimalPositivo(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                double num = entrada.nextDouble();
                entrada.nextLine();

                if (num > 0) return num;
                else System.out.println("Debe ser mayor a 0");

            } catch (Exception e) {
                System.out.println("Número inválido");
                entrada.nextLine();
            }
        }
    }
}