package com.mycompany.ejercicio_192;

public class metodo_192 {
    private int numeroVentas;
    private double totalVentas;

    public metodo_192() {
        this.numeroVentas = 0;
        this.totalVentas = 0;
    }

    public void registrarVenta(double valor) {
        if (valor > 0) {
            numeroVentas++;
            totalVentas += valor;
        } else {
            System.out.println("Venta inválida");
        }
    }

    public int getNumeroVentas() {
        return numeroVentas;
    }

    public double getTotalVentas() {
        return totalVentas;
    }

    public String MostrarInfo() {
        return "SistemaVentas{" +
                "numeroVentas=" + numeroVentas +
                ", totalVentas=" + totalVentas +
                '}';
    }
}