/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio_64;

import java.util.Scanner;

/**
 *
 * @author Nemesis
 */
public class Ejercicio_64 {
    static Scanner entrada = new Scanner(System.in);
    
    public static void main(String[] args) {
        
        String respuesta = "si";
        
        do {
            try {
                System.out.println("===============");
                String marca = texto("ingrese la marca del pc ");
                int ram  =  numeros("ingrese la cantidad de ram ");
                int almacenamiento =  numeros("ingrese la cantidad de almacenamiento ");
                
                metodo_64 pc = new metodo_64(marca, ram, almacenamiento);
                
                System.out.println(pc);
                String opcion = texto(" quiere editar la ram (si/no) ? ");
                if (opcion.equalsIgnoreCase("si")) {
                    int nueva_ram = numeros("ingrese la nueva cantidad ");
                    pc.setRAM(nueva_ram);
                    
                }else 
                    break ;
                
                System.out.println(pc);
                
             
                do {
                    respuesta = texto("¿Desea agregar otro? (si/no)");
                } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
                
               
                
            } catch (Exception e) {
                System.out.println("El dato está mal.");
                entrada.nextLine();                
            }
            
        } while (respuesta.equalsIgnoreCase("si"));
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }
 public static int numeros(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                int numero = entrada.nextInt();
                entrada.nextLine();
                return numero;
            } catch (Exception e) {
                System.out.println("Ingrese un número válido");
                entrada.nextLine();
            }
        }
    }
}
