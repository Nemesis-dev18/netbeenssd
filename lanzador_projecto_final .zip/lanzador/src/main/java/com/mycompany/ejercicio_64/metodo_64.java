/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_64;

/**
 *
 * @author Nemesis
 */
public class metodo_64 {
    private String marca ;
    private int RAM ;
    private int almacenamiento ;

    public metodo_64(String marca, int RAM, int almacenamiento) {
        this.marca = marca;
        this.RAM = RAM;
        this.almacenamiento = almacenamiento;
    }
    

    public void setRAM(int RAM) {
        this.RAM = RAM;
    }
    
    

    @Override
    public String toString() {
        return "metodo_64{" + "marca=" + marca + ", RAM=" + RAM + ", almacenamiento=" + almacenamiento + '}';
    }
    
    
    
    
}
