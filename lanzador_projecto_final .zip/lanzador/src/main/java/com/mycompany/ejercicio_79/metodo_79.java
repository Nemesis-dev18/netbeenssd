
package com.mycompany.ejercicio_79;

public class metodo_79 {

    private String nombre;
    private int libros;
    private int estudiantes;

    public metodo_79(String nombre, int libros, int estudiantes) {
        this.nombre = nombre;
        this.libros = libros;
        this.estudiantes = estudiantes;
    }

    public void MostrarInfo() {
        System.out.println("Biblioteca: " + nombre +
                ", Libros: " + libros +
                ", Estudiantes: " + estudiantes);
    }
}
