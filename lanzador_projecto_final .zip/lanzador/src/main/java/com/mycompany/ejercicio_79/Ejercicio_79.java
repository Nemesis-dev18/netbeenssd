
package com.mycompany.ejercicio_79;

import java.util.Scanner;

public class Ejercicio_79 {
    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String nombre = texto("Ingrese nombre de la biblioteca");
        int libros = entero("Ingrese número de libros");
        int estudiantes = entero("Ingrese número de estudiantes");

        metodo_79 obj = new metodo_79(nombre, libros, estudiantes);
        obj.MostrarInfo();
    }

    public static String texto(String m) {
        System.out.println(m + ":");
        return entrada.nextLine();
    }

    public static int entero(String m) {
        while (true) {
            try {
                System.out.println(m + ":");
                int n = entrada.nextInt();
                entrada.nextLine();
                return n;
            } catch (Exception e) {
                entrada.nextLine();
            }
        }
    }
}
