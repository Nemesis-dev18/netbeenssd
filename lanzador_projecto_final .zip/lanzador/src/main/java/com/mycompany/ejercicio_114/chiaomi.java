/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_114;

/**
 *
 * @author Nemesis
 */
public class chiaomi implements llamar,foto,mensaje{
    private String marca ;

    public chiaomi(String marca) {
        this.marca = marca;
    }
    
@Override 
public void llamar (){
    System.out.println("se esta haciendo una llamada");
}

@Override
public void mensaje (){
    System.out.println("se esta enviando un mensaje xd ");
    
}
@Override
public void foto (){
    System.out.println("foto tomada desde un "+marca);
}
    
}
