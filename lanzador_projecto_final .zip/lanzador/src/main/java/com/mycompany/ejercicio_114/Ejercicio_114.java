/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio_114;

/**
 *
 * @author Nemesis
 */
public class Ejercicio_114 {

    public static void main(String[] args) {
     chiaomi t = new chiaomi("chochelel ");
     
     t.llamar();
     t.mensaje();
     t.foto ();
    }
}
