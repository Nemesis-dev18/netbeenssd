
package com.mycompany.ejercicio_92;

public class CuentaCorriente extends Cuenta{

    public CuentaCorriente(String numero){
        super(numero);
    }
}
