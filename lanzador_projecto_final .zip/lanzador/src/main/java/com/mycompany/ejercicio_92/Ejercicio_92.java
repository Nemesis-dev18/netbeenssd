
package com.mycompany.ejercicio_92;

public class Ejercicio_92 {
    public static void main(String[] args){
        CuentaCorriente c1 = new CuentaCorriente("123");
        CuentaEmpresarial c2 = new CuentaEmpresarial("456");

        c1.MostrarInfo();
        c2.MostrarInfo();
    }
}
