
package com.mycompany.ejercicio_92;

public class CuentaEmpresarial extends Cuenta{

    public CuentaEmpresarial(String numero){
        super(numero);
    }
}
