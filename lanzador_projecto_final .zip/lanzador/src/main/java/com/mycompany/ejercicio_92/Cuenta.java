
package com.mycompany.ejercicio_92;

public class Cuenta {
    protected String numero;

    public Cuenta(String numero){
        this.numero = numero;
    }

    public void MostrarInfo(){
        System.out.println("Cuenta: " + numero);
    }
}
