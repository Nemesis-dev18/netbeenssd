package com.mycompany.ejercicio_139;
public class Tienda{
 public double calcularDescuento(double valor){ return valor*0.9; }
 public double calcularDescuento(double valor,String tipo){
  if(tipo.equals("VIP")) return valor*0.8;
  return valor*0.9;
 }
}