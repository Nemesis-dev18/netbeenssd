package com.mycompany.ejercicio_139;
public class Ejercicio_139{
 public static void main(String[] args){
  Tienda t=new Tienda();
  System.out.println(t.calcularDescuento(100));
  System.out.println(t.calcularDescuento(100,"VIP"));
 }
}