
package com.mycompany.ejercicio_74;

import java.util.Scanner;

public class Ejercicio_74 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String numero = texto("Ingrese el numero de vuelo");
        String destino = texto("Ingrese el destino");
        int pasajeros = entero("Ingrese cantidad de pasajeros");

        metodo_74 obj = new metodo_74(numero, destino, pasajeros);

        obj.MostrarInfo();
        obj.agregarPasajeros(5);
        obj.MostrarInfo();
    }

    public static String texto(String m) {
        System.out.println(m + ":");
        return entrada.nextLine();
    }

    public static int entero(String m) {
        while (true) {
            try {
                System.out.println(m + ":");
                int n = entrada.nextInt();
                entrada.nextLine();
                return n;
            } catch (Exception e) {
                entrada.nextLine();
            }
        }
    }
}
