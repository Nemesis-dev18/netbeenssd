
package com.mycompany.ejercicio_74;

public class metodo_74 {

    private String numero;
    private String destino;
    private int pasajeros;

    public metodo_74(String numero, String destino, int pasajeros) {
        this.numero = numero;
        this.destino = destino;
        this.pasajeros = pasajeros;
    }

    public void MostrarInfo() {
        System.out.println("Vuelo: " + numero +
                ", Destino: " + destino +
                ", Pasajeros: " + pasajeros);
    }

    public void agregarPasajeros(int cantidad) {
        pasajeros += cantidad;
    }
}
