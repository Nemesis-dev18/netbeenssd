package com.mycompany.ejercicio_111;

public abstract class Dispositivo {
    protected String marca;

    public Dispositivo(String marca) {
        this.marca = marca;
    }

    public abstract void encender();
}