package com.mycompany.ejercicio_111;

public interface Bluetooth {
    void enlace();
}