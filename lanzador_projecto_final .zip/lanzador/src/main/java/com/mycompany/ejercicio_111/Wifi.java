package com.mycompany.ejercicio_111;

public interface Wifi {
    void conectar();
}