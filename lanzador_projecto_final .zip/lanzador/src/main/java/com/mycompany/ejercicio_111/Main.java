package com.mycompany.ejercicio_111;

public class Main {

    public static void main(String[] args) {
        Ejercicio_111 sistema = new Ejercicio_111("Linux");

        sistema.mostrar();
    }
}