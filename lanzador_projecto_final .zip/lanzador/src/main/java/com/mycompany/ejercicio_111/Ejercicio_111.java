package com.mycompany.ejercicio_111;

public class Ejercicio_111 extends Dispositivo implements Wifi, Bluetooth {

    public Ejercicio_111(String marca) {
        super(marca);
    }

    @Override
    public void encender() {
        System.out.println("Sistema " + marca + " encendido");
    }

    @Override
    public void conectar() {
        System.out.println("Conectado a WiFi");
    }

    @Override
    public void enlace() {
        System.out.println("Bluetooth activado");
    }

    public void mostrar() {
        encender();
        conectar();
        enlace();
    }
}