
package com.mycompany.ejercicio_166;

public class Ejercicio_166 {
    public static void main(String[] args) {
        Libro l = new Libro();
        l.setTitulo("Java");
        l.setPaginas(300);
        System.out.println(l.getTitulo()+" "+l.getPaginas());
    }
}
