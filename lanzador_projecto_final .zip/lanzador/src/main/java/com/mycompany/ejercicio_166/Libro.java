
package com.mycompany.ejercicio_166;

public class Libro {
    private String titulo;
    private int paginas;

    public void setTitulo(String titulo){ this.titulo = titulo; }
    public String getTitulo(){ return titulo; }

    public void setPaginas(int paginas){ this.paginas = paginas; }
    public int getPaginas(){ return paginas; }
}
