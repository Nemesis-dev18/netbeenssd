
package com.mycompany.ejercicio_33;

public class metodo_33 {
    private String nombre_jugador ;
    private String nombre_del_equipo;
    private int numero_de_camiseta_del_juagdor;

    public metodo_33(String nombre_jugador, String nombre_del_equipo, int numero_de_camiseta_del_juagdor) {
        this.nombre_jugador = nombre_jugador;
        this.nombre_del_equipo = nombre_del_equipo;
        this.numero_de_camiseta_del_juagdor = numero_de_camiseta_del_juagdor;
    }

    public String getNombre_jugador() {
        return nombre_jugador;
    }

    public String getNombre_del_equipo() {
        return nombre_del_equipo;
    }

    public int getNumero_de_camiseta_del_juagdor() {
        return numero_de_camiseta_del_juagdor;
    }

    @Override
    public String toString() {
        return "metodo_33{" + "nombre_jugador=" + nombre_jugador + ", nombre_del_equipo=" + nombre_del_equipo + ", numero_de_camiseta_del_juagdor=" + numero_de_camiseta_del_juagdor + '}';
    }
    
    
    
    
}
