
package com.mycompany.ejercicio_33;

import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio_33 {
    static Scanner entrada = new Scanner(System.in);
    static ArrayList<metodo_33> lista = new ArrayList<>();
    
    public static void main(String[] args) {
        
        String respuesta = "si";
        
        do {
            try {
                System.out.println("===============");
                
                String nombre = texto("ingrese su nombre ");
                String nombre_equipo = texto("ingrese el nombre del ecuipo");
                int numero = numeros(" ingrese el numero de equipo ");
                metodo_33 info = new metodo_33(nombre, nombre_equipo, numero);
                lista.add(info);
                do {
                    respuesta = texto("¿Desea agregar otro? (si/no)");
                } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
                
            } catch (Exception e) {
                System.out.println("El dato está mal.");
                entrada.nextLine();                
            }
            
        } while (respuesta.equalsIgnoreCase("si"));
        for (metodo_33 string : lista) {
            System.out.println(string);
            
        }
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }
    
    public static int numeros(String mensaje) {
        System.out.println(mensaje + " :");
        int numero = entrada.nextInt();
        entrada.nextLine();
        return numero;
    }
}
