
package com.mycompany.ejercicio_158;

public abstract class SistemaVentas {
    public abstract double registrarVenta(double valor);
}
