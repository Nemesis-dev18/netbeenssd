
package com.mycompany.ejercicio_158;

public class Ejercicio_158 {
    public static void main(String[] args) {
        SistemaVentas v1 = new VentaFisica();
        SistemaVentas v2 = new VentaOnline();

        double valor = 100;

        System.out.println("Venta física: " + v1.registrarVenta(valor));
        System.out.println("Venta online: " + v2.registrarVenta(valor));
    }
}
