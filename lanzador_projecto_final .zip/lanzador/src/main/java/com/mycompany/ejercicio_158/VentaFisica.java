
package com.mycompany.ejercicio_158;

public class VentaFisica extends SistemaVentas {
    @Override
    public double registrarVenta(double valor) {
        return valor;
    }
}
