
package com.mycompany.ejercicio_158;

public class VentaOnline extends SistemaVentas {
    @Override
    public double registrarVenta(double valor) {
        return valor + (valor * 0.05);
    }
}
