package com.mycompany.ejercicio_144;
public class Ejercicio_144{
 public static void main(String[] args){
  Conversor c=new Conversor();
  System.out.println(c.convertir(10));
  System.out.println(c.convertir(10,true));
 }
}