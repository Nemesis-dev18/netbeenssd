package com.mycompany.ejercicio_144;
public class Conversor{
 public double convertir(double km){
  return km*1000;
 }
 public double convertir(double km,boolean millas){
  if(millas) return km*0.621;
  return km*1000;
 }
}