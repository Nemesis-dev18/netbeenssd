/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_42;

/**
 *
 * @author Nemesis
 */
public class metodo_42 {
    private String nombre ;
    private int num_empleados ;

    public metodo_42(String nombre, int num_empleados) {
        this.nombre = nombre;
        this.num_empleados = num_empleados;
    }

    @Override
    public String toString() {
        return "metodo_42{" + "nombre=" + nombre + ", num_empleados=" + num_empleados + '}';
    }
    
    
    
}
