/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_53;

/**
 *
 * @author Nemesis
 */
public class metodo_53 {
    private String nombre ;
    private int nivel;

    public metodo_53(String nombre, int nivel) {
        this.nombre = nombre;
        this.nivel = nivel;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("metodo_53{");
        sb.append("nombre=").append(nombre);
        sb.append(", nivel=").append(nivel);
        sb.append('}');
        return sb.toString();
    }
    
    
    
}
