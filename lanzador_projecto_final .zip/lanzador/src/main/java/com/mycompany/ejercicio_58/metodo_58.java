/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_58;

/**
 *
 * @author Nemesis
 */
public class metodo_58 {
    private  double temp ;
    private  double humedad ;

    public metodo_58(double temp, double humedad) {
        this.temp = temp;
        this.humedad = humedad;
    }

    @Override
    public String toString() {
        return "metodo_58{" + "temp=" + temp + ", humedad=" + humedad + '}';
    }
    
    
    
}
