/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio_58;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Nemesis
 */
public class Ejercicio_58 {

    static Scanner entrada = new Scanner(System.in);
    static ArrayList<metodo_58> lista = new ArrayList<>();
    
    public static void main(String[] args) {
        
        String respuesta = "si";
        
        do {
            try {
                System.out.println("===============");
                double temp = numeros("ingrese la temperatura ambiente ");
                double humedad = numeros("ingrese la humedad ambiente ");
                
                lista.add(new metodo_58(temp, humedad));
                
                do {
                    respuesta = texto("¿Desea agregar otro? (si/no)");
                } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
                
            } catch (Exception e) {
                System.out.println("El dato está mal.");
                entrada.nextLine();                
            }
            
        } while (respuesta.equalsIgnoreCase("si"));
        for (metodo_58 string : lista) {
            System.out.println(string);
            
        }
    }

    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }
    
    public static double numeros(String mensaje) {
        System.out.println(mensaje + " :");
        double numero = entrada.nextDouble();
        entrada.nextLine();
        return numero;
    }
}
