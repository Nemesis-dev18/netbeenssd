package com.mycompany.ejercicio_150;
public class Operacion{
 public int calcular(int a,int b){
  return a+b;
 }
 public int calcular(int a,int b,int c){
  return a*b*c;
 }
}