package com.mycompany.ejercicio_150;
public class Ejercicio_150{
 public static void main(String[] args){
  Operacion o=new Operacion();
  System.out.println(o.calcular(2,3));
  System.out.println(o.calcular(2,3,4));
 }
}