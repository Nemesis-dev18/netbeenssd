
package com.mycompany.ejercicio_161;

public class Ejercicio_161 {
    public static void main(String[] args) {
        Persona p = new Persona();
        p.setNombre("Juan");
        p.setEdad(20);
        System.out.println(p.getNombre() + " " + p.getEdad());
    }
}
