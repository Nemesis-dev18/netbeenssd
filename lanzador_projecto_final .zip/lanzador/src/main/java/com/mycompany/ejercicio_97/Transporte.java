
package com.mycompany.ejercicio_97;
public class Transporte{
 protected String tipo;
 public Transporte(String tipo){this.tipo=tipo;}
 public void MostrarInfo(){System.out.println("Tipo: "+tipo);}
}
