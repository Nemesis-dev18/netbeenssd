/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_113;

/**
 *
 * @author Nemesis
 */
public class impresora  implements escanear,copiar,imprimir{
    private String marca ; 

    public impresora(String marca) {
        this.marca = marca;
    }
    
    @Override
    public void escanear() {
        System.out.println("la impresora " + marca + " está  escaneando un documento ");
    }
    @Override
    public void imprimir() {
        System.out.println("la impresora " + marca + " está imprimiendo el documentos");
    }
    
    @Override
    public void copiar (){
        System.out.println("la impresora " + marca + " está imprimiendo el documentos");
    }
    
}
