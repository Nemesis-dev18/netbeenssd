/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio_113;

/**
 *
 * @author Nemesis
 */
public class Ejercicio_113 {

    public static void main(String[] args) {
       impresora n = new impresora("epson");
       
       n.copiar();
       n.imprimir();
       n.escanear();
       
    }
}
