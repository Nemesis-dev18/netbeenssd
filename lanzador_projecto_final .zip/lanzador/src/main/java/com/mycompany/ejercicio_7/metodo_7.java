package com.mycompany.ejercicio_7;

public class metodo_7 {
    private String nombre;
    private double valor;

    public metodo_7(String nombre, double valor) {
        this.nombre = nombre;
        this.valor = valor;
    }

    public String MostrarInfo() {
        return "Nombre: " + nombre + ", Valor: " + valor;
    }
}
