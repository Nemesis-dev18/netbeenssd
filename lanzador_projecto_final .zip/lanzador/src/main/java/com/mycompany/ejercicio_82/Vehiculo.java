
package com.mycompany.ejercicio_82;

public class Vehiculo {

    protected String marca;
    protected double velocidad;

    public Vehiculo(String marca, double velocidad) {
        this.marca = marca;
        this.velocidad = velocidad;
    }

    public void MostrarInfo() {
        System.out.println("Marca: " + marca + ", Velocidad: " + velocidad);
    }
}
