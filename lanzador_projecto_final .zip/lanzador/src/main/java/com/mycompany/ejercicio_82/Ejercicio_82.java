
package com.mycompany.ejercicio_82;

import java.util.Scanner;

public class Ejercicio_82 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String marca = texto("Ingrese marca");
        double velocidad = numero("Ingrese velocidad");
        int puertas = entero("Ingrese numero de puertas");

        Carro c1 = new Carro(marca, velocidad, puertas);
        c1.MostrarInfo();
    }

    public static String texto(String m) {
        System.out.println(m + ":");
        return entrada.nextLine();
    }

    public static int entero(String m) {
        while (true) {
            try {
                System.out.println(m + ":");
                int n = entrada.nextInt();
                entrada.nextLine();
                return n;
            } catch (Exception e) {
                entrada.nextLine();
            }
        }
    }

    public static double numero(String m) {
        while (true) {
            try {
                System.out.println(m + ":");
                double n = entrada.nextDouble();
                entrada.nextLine();
                return n;
            } catch (Exception e) {
                entrada.nextLine();
            }
        }
    }
}
