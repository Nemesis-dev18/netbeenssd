
package com.mycompany.ejercicio_82;

public class Carro extends Vehiculo {

    private int puertas;

    public Carro(String marca, double velocidad, int puertas) {
        super(marca, velocidad);
        this.puertas = puertas;
    }

    @Override
    public void MostrarInfo() {
        super.MostrarInfo();
        System.out.println("Puertas: " + puertas);
    }
}
