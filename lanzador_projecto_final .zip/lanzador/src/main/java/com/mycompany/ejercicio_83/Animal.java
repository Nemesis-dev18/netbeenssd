
package com.mycompany.ejercicio_83;

public class Animal {
    protected String nombre;
    protected int edad;

    public Animal(String nombre, int edad) {
        this.nombre = nombre;
        this.edad = edad;
    }

    public void MostrarInfo() {
        System.out.println("Nombre: " + nombre + ", Edad: " + edad);
    }
}
