
package com.mycompany.ejercicio_83;

public class Perro extends Animal {

    private String raza;

    public Perro(String nombre, int edad, String raza) {
        super(nombre, edad);
        this.raza = raza;
    }

    @Override
    public void MostrarInfo() {
        super.MostrarInfo();
        System.out.println("Raza: " + raza);
    }
}
