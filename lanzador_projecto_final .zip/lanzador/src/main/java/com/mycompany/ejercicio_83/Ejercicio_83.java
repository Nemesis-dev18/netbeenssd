
package com.mycompany.ejercicio_83;

import java.util.Scanner;

public class Ejercicio_83 {

    static Scanner entrada = new Scanner(System.in);

    public static void main(String[] args) {

        String nombre = texto("Ingrese nombre");
        int edad = entero("Ingrese edad");
        String raza = texto("Ingrese raza");

        Perro p = new Perro(nombre, edad, raza);
        p.MostrarInfo();
    }

    public static String texto(String m) {
        System.out.println(m + ":");
        return entrada.nextLine();
    }

    public static int entero(String m) {
        while (true) {
            try {
                System.out.println(m + ":");
                int n = entrada.nextInt();
                entrada.nextLine();
                return n;
            } catch (Exception e) {
                entrada.nextLine();
            }
        }
    }
}
