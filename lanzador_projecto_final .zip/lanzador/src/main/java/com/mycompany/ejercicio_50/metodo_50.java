/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_50;

/**
 *
 * @author Nemesis
 */
public class metodo_50 {
    private int num_pedido;
    private String direccion ; 

    public metodo_50(int num_pedido, String direccion) {
        this.num_pedido = num_pedido;
        this.direccion = direccion;
    }

    @Override
    public String toString() {
        return "metodo_50{" + "num_pedido=" + num_pedido + ", direccion=" + direccion + '}';
    }
    
    
    
}
