package com.mycompany.ejercicio_10;

public class metodo_10 {
    private String nombre;
    private double valor;

    public metodo_10(String nombre, double valor) {
        this.nombre = nombre;
        this.valor = valor;
    }

    public String MostrarInfo() {
        return "Nombre: " + nombre + ", Valor: " + valor;
    }
}
