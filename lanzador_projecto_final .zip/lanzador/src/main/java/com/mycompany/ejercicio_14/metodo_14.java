package com.mycompany.ejercicio_14;

public class metodo_14 {
    private String nombre;
    private double valor;

    public metodo_14(String nombre, double valor) {
        this.nombre = nombre;
        this.valor = valor;
    }

    public String MostrarInfo() {
        return "Nombre: " + nombre + ", Valor: " + valor;
    }
}
