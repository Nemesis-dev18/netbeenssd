/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio_65;

import com.mycompany.ejercicio_65.metodo_65;
import java.util.Scanner;

/**
 *
 * @author Nemesis
 */
public class Ejercicio_65 {
    static Scanner entrada = new Scanner(System.in);
    
    public static void main(String[] args) {
        
        try {
            System.out.println("===============");
            
            String nombre = texto("Ingrese el nombre dle producto ");
            double num_habitacion = numeros("Ingrese el precio del producto ");
            double cant_noches  = numeros("Ingrese el la cantidad d eese producto ");
            
            metodo_65 obj = new metodo_65(nombre,num_habitacion, cant_noches);
            
           obj.datos();
            
        } catch (Exception e) {
            System.out.println("El dato está mal.");
        }
    }
    
    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();
    }
    
    public static double numeros(String mensaje) {
        while (true) {
            try {
                System.out.println(mensaje + ":");
                double numero = entrada.nextDouble();
                entrada.nextLine();
                return numero;
            } catch (Exception e) {
                System.out.println("Ingrese un número válido");
                entrada.nextLine();
            }
        }
    }
}
