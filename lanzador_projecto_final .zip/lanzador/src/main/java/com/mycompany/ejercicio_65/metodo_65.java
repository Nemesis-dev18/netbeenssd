/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejercicio_65;

/**
 *
 * @author Nemesis
 */
public class metodo_65 {
    private String nombre; 
    private double  habitacion ; 
    private double num_noches;

    public metodo_65(String nombre, double habitacion, double num_noches) {
        this.nombre = nombre;
        this.habitacion = habitacion;
        this.num_noches = num_noches;
    }
    
    
    
         
    public double total (){
        if (num_noches <= 0 || habitacion <= 0 ) {
            return 0 ;
            
        }else
            return num_noches*80000;
    }
    
    public void datos (){
        System.out.println("nombre del cliente :  "+nombre + " | precio x noche es de 80000  | cantidad de noches    :"+ num_noches+ " | total de la estadia  : " + total());
    }
    
    
    
}
