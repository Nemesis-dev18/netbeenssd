
package com.mycompany.ejercicio_22;

public class metodo_22 {
    private String nombre_cliente;
    private double numero_factura;
    private double valor ;

    public metodo_22(String nombre_cliente, double numero_factura, double valor) {
        this.nombre_cliente = nombre_cliente;
        this.numero_factura = numero_factura;
        this.valor = valor;
    }

    public String getNombre_cliente() {
        return nombre_cliente;
    }

    public double getNumero_factura() {
        return numero_factura;
    }

    public double getValor() {
        return valor;
    }
    
    public  double impuesto(){
        double total = valor * 1.19;
        return total;
    }

    @Override
    public String toString() {
        return "metodo_22{" + "nombre_cliente=" + nombre_cliente + ", numero_factura=" + numero_factura + ", valor=" + valor +" ,valor con impuesto : "+String.format("%.2f",impuesto())+ '}';
    }
    
}
