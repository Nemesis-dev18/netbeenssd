package com.mycompany.ejercicio_22;
import java.util.ArrayList;
import java.util.Scanner;
public class Ejercicio_22 {
static Scanner entrada = new Scanner(System.in);
static ArrayList<metodo_22> factura = new ArrayList<>();
    public static void main(String[] args) {
        String respuesta;
        do {            
            String nombre_c= texto("ingrese su nombre ");
            double numero_f =numeros("ingrese el numero de su factura");
            double valor = numeros("ingrese el valor normal");
            metodo_22 info = new metodo_22(nombre_c, numero_f, valor);
            factura.add(info);
            do {
                respuesta = texto("¿Desea agregar otro ? (si/no)");
            } while (!respuesta.equalsIgnoreCase("si") && !respuesta.equalsIgnoreCase("no"));
            
        } while (respuesta.equalsIgnoreCase("si"));
        for (metodo_22 st : factura) {
            System.out.println(st);     
        }
    }
    public static String texto(String mensaje) {
        System.out.println(mensaje + ":");
        return entrada.nextLine();}
    public static double numeros(String mensaje) {
        System.out.println(mensaje + " :");
        double numero = entrada.nextDouble();
        entrada.nextLine();
        return numero;
    }
}
