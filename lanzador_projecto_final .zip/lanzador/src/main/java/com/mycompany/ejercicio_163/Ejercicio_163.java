
package com.mycompany.ejercicio_163;

public class Ejercicio_163 {
    public static void main(String[] args) {
        Producto p = new Producto();
        p.setPrecio(100);
        p.setCantidad(5);
        System.out.println(p.getPrecio()*p.getCantidad());
    }
}
