
package com.mycompany.ejercicio_163;

public class Producto {
    private String nombre;
    private double precio;
    private int cantidad;

    public void setPrecio(double precio){ this.precio = precio; }
    public double getPrecio(){ return precio; }

    public void setCantidad(int cantidad){ this.cantidad = cantidad; }
    public int getCantidad(){ return cantidad; }
}
