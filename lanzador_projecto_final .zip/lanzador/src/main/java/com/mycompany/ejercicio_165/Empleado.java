
package com.mycompany.ejercicio_165;

public class Empleado {
    private String nombre;
    private double salario;

    public void setSalario(double salario){ this.salario = salario; }
    public double getSalario(){ return salario; }
}
