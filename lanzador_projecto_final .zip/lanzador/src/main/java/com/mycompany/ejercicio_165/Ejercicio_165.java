
package com.mycompany.ejercicio_165;

public class Ejercicio_165 {
    public static void main(String[] args) {
        Empleado e = new Empleado();
        e.setSalario(2000);
        System.out.println(e.getSalario());
    }
}
